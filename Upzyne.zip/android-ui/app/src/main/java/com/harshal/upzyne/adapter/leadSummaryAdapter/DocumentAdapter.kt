package com.harshal.upzyne.adapter.leadSummaryAdapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ItemDocumentSmallBinding
import com.harshal.upzyne.model.LeadsModel
import org.w3c.dom.Document

class DocumentSmallAdapter( private val context: Context,
    private val documents: List<LeadsModel.DocumentItem>
) : RecyclerView.Adapter<DocumentSmallAdapter.DocumentViewHolder>() {

    inner class DocumentViewHolder(val binding: ItemDocumentSmallBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DocumentViewHolder {
        val binding = ItemDocumentSmallBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DocumentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DocumentViewHolder, position: Int) {
        val doc = documents[position]
        holder.binding.tvDocumentName.text = doc.title
        setThemeBackground(context, holder.binding.setbackgroundThem)

    }

    override fun getItemCount() = documents.size
}
