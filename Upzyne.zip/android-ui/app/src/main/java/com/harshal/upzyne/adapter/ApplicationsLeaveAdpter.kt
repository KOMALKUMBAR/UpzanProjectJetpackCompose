package com.harshal.upzyne.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.model.LeaveApplication
import java.text.SimpleDateFormat
import java.util.Locale

class ApplicationsLeaveAdapter(private val leaveList: List<LeaveApplication>) :
    RecyclerView.Adapter<ApplicationsLeaveAdapter.LeaveViewHolder>() {

    inner class LeaveViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val leaveType: TextView = itemView.findViewById(R.id.leaveType)
        val leaveDate: TextView = itemView.findViewById(R.id.leaveDate)
        val leaveDescription: TextView = itemView.findViewById(R.id.leaveDescription)
        val status: TextView = itemView.findViewById(R.id.status)
        val rootLayout: View = itemView.findViewById(R.id.rootLayout)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LeaveViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_applications_leave, parent, false)
        return LeaveViewHolder(view)
    }

    override fun onBindViewHolder(holder: LeaveViewHolder, position: Int) {
        val item = leaveList[position]
        setThemeBackground(holder.itemView.context, holder.rootLayout)
        val date = "${formatDate(item.datefrom)} - ${formatDate(item.dateto)} (${item.leaveperiod})"

        holder.leaveType.text = item.leavetype.lowercase(Locale.ROOT)
        holder.leaveDate.text = date.lowercase(Locale.ROOT)
        holder.leaveDescription.text = item.remarks.lowercase(Locale.ROOT)
        holder.status.text = item.status.lowercase(Locale.ROOT)

        when (item.status.lowercase()) {
            "approved" -> holder.status.setBackgroundResource(R.drawable.shape_approved)
            "rejected" -> holder.status.setBackgroundResource(R.drawable.shape_color_btn)
            "pending" -> holder.status.setBackgroundResource(R.drawable.shape_pending)
        }
    }

    override fun getItemCount(): Int = leaveList.size

    private fun formatDate(inputDate: String): String {
        return try {
            val input = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val output = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
            val date = input.parse(inputDate)
            output.format(date!!)
        } catch (e: Exception) {
            inputDate
        }
    }
}
