package com.harshal.upzyne

import android.app.Application
import android.content.Context
import com.harshal.upzyne.CommonUtils.LanguageUtils

class initApiClient: Application() {
    override fun onCreate() {
        super.onCreate()
        ApiClient.init(this) // ✅ Correct place to initialize singleton
    }

    override fun attachBaseContext(base: Context) {
        val newContext = LanguageUtils.setLocale(base, LanguageUtils.getLanguage(base))
        super.attachBaseContext(newContext)
    }
}