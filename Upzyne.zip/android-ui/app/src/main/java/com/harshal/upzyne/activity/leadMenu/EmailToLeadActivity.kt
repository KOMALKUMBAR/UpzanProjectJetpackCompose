package com.harshal.upzyne.activity.leadMenu

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.PorterDuff
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.text.style.URLSpan
import android.os.Bundle
import android.text.InputType
import android.text.Spannable
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.core.view.WindowCompat
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.adapter.leadSummaryAdapter.EmailToLeadAdpter
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityEmailToLeadBinding
import com.harshal.upzyne.databinding.ItemLeadProfileLayoutBinding
import com.harshal.upzyne.model.LeadsModel
import com.harshal.upzyne.util.FileUtils
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class EmailToLeadActivity : AppCompatActivity() {

    // UI and data binding
    private lateinit var binding: ActivityEmailToLeadBinding

    // User details and token
    private lateinit var userFullName: String
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String

    // Constants and data lists
    private val PICK_FILE_REQUEST_CODE = 101
    private val attachmentList = mutableListOf<Uri>()
    private lateinit var adapter: EmailToLeadAdpter
    private var emailTemplateList: List<LeadsModel.EmailTemplate> = listOf()

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout and initialize binding
        binding = ActivityEmailToLeadBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        // Get shared preferences and user details
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "").toString()
        val token = sharedPref.getString("auth_token", "") ?: ""
        bearerToken = "Bearer $token"

        // Set title with user's name
        binding.titleText.text = "$userFullName - ${getString(R.string.email_to_lead)}"

        // Enable clickable links in email body
        binding.emailEditText.movementMethod = android.text.method.LinkMovementMethod.getInstance()

        // Add lead profile card to layout
        val itemLeadBinding = ItemLeadProfileLayoutBinding.inflate(LayoutInflater.from(this), binding.leadContainer, false)
        binding.leadContainer.addView(itemLeadBinding.root)

        // Set theme background
        setThemeBackground(this, binding.lay)

        // Get lead details from intent extras and populate views
        val leadStatusColor = intent.getStringExtra("lead_statuscolor") ?: "#3E4A59"
        val leadVerified = intent.getBooleanExtra("lead_verified", false)
        itemLeadBinding.userName.text = intent.getStringExtra("lead_name")
        itemLeadBinding.userEmail.text = intent.getStringExtra("lead_email")
        itemLeadBinding.userPhone.text = intent.getStringExtra("lead_phone")
        itemLeadBinding.engagedDate.text = "engaged: ${intent.getStringExtra("lead_timeago")}"
        itemLeadBinding.joinedDate.text = "joinedDate: ${intent.getStringExtra("lead_leaddate")}"
        itemLeadBinding.course.text = intent.getStringExtra("lead_programme")
        itemLeadBinding.statusIcon.text = intent.getStringExtra("lead_sourcebadge")
        itemLeadBinding.tvOtpVerification.visibility = if (leadVerified) View.VISIBLE else View.GONE

        // Apply dynamic color to lead label
        val labelDrawable = itemLeadBinding.labelNewLead.background?.mutate()
        val colorWithAlpha = (leadStatusColor.toColorInt() and 0x00FFFFFF) or (0x30 shl 24)
        labelDrawable?.setColorFilter(colorWithAlpha, PorterDuff.Mode.SRC_ATOP)
        itemLeadBinding.labelNewLead.background = labelDrawable
        itemLeadBinding.labelNewLead.setTextColor(leadStatusColor.toColorInt())
        itemLeadBinding.labelNewLead.text = intent.getStringExtra("lead_source") ?: ""

        // Set color to left border background
        val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.left_glass)
        if (backgroundDrawable is LayerDrawable) {
            val leftBorder = backgroundDrawable.findDrawableByLayerId(R.id.left_border)
            if (leftBorder is GradientDrawable) {
                leftBorder.setColor(leadStatusColor.toColorInt())
            }
            itemLeadBinding.itemLead.background = backgroundDrawable
        }

        // Setup email form events
        binding.btnSendEmail.setOnClickListener { sendEmailToLead() }
        binding.imgArrow.setOnClickListener { finish() }

        // Fetch email templates from API and populate the dropdown
        fetchEmailTemplates()

        // Setup RecyclerView for file attachments
        setupRecyclerView()

        // Launch file picker to attach a document
        binding.attachmentEditText.setOnClickListener {
            openFilePicker()
        }

        // Word count listener
        binding.emailEditText.addTextChangedListener {
            binding.wordCountText.text = "${it?.length ?: 0}/100"
        }

        // Bold text toggle
        binding.boldBtn.setOnClickListener {
            val start = binding.emailEditText.selectionStart
            val end = binding.emailEditText.selectionEnd
            if (start < end) {
                val spannable = binding.emailEditText.text as Spannable
                val boldSpans = spannable.getSpans(start, end, StyleSpan::class.java)

                var boldExists = false
                for (span in boldSpans) {
                    if (span.style == Typeface.BOLD) {
                        spannable.removeSpan(span)
                        boldExists = true
                    }
                }

                if (!boldExists) {
                    spannable.setSpan(StyleSpan(Typeface.BOLD), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
        }

        // Italic text toggle
        binding.italic.setOnClickListener {
            val start = binding.emailEditText.selectionStart
            val end = binding.emailEditText.selectionEnd
            if (start < end) {
                val spannable = binding.emailEditText.text as Spannable
                val italicSpans = spannable.getSpans(start, end, StyleSpan::class.java)

                var italicExists = false
                for (span in italicSpans) {
                    if (span.style == Typeface.ITALIC) {
                        spannable.removeSpan(span)
                        italicExists = true
                    }
                }

                if (!italicExists) {
                    spannable.setSpan(StyleSpan(Typeface.ITALIC), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
        }

        // Add clickable URL to selected text
        binding.linkBtn.setOnClickListener {
            val start = binding.emailEditText.selectionStart
            val end = binding.emailEditText.selectionEnd

            if (start < end) {
                val spannable = binding.emailEditText.text as Spannable
                val urlSpans = spannable.getSpans(start, end, URLSpan::class.java)

                var urlExists = false
                for (span in urlSpans) {
                    spannable.removeSpan(span)
                    urlExists = true
                }

                if (!urlExists) {
                    val input = EditText(this).apply {
                        inputType = InputType.TYPE_TEXT_VARIATION_URI
                        hint = ""
                    }

                    AlertDialog.Builder(this)
                        .setTitle("Enter Link URL")
                        .setView(input)
                        .setPositiveButton("OK") { _, _ ->
                            val url = input.text.toString()
                            if (url.isNotBlank()) {
                                spannable.setSpan(URLSpan(url), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                            }
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
        }

        // Apply multi-color gradient to AI writing label
        applyMultiColorGradient()
    }

    // Gradient effect for "Writing with AI" label
    private fun applyMultiColorGradient() {
        val textView = binding.writingAi
        val height = textView.textSize
        val shader = LinearGradient(
            0f, 15f, 0f, height,
            intArrayOf(
                getColor(R.color.ai_frst),
                getColor(R.color.ai_second),
                getColor(R.color.ai_three)
            ),
            null,
            Shader.TileMode.CLAMP
        )
        textView.paint.shader = shader
    }

    /**
     * Fetches email templates and populates the dropdown (spinner)
     * Selecting a template will autofill subject and body fields
     */
    private fun fetchEmailTemplates() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getEmailTemplates(bearerToken)
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@EmailToLeadActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        emailTemplateList = response
                        val templateNames = listOf("Select email template...") + emailTemplateList.map { it.templatename }

                        val adapter = ArrayAdapter(this@EmailToLeadActivity, R.layout.item_spinner, templateNames).apply {
                            setDropDownViewResource(R.layout.item_spinner)
                        }

                        binding.editTextTemplateName.adapter = adapter

                        // On selection, update subject and email body
                        binding.editTextTemplateName.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                                if (position > 0) {
                                    val selectedTemplate = emailTemplateList[position - 1]
                                    binding.editTextEmailSubject.setText(selectedTemplate.emailsubject)
                                    binding.emailEditText.setText(selectedTemplate.emailbody)
                                } else {
                                    binding.editTextEmailSubject.setText("")
                                    binding.emailEditText.setText("")
                                }
                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {}
                        }
                    },
                    onError = {
                        Toast.makeText(this@EmailToLeadActivity, "Failed to fetch templates", Toast.LENGTH_SHORT).show()
                    }
                )
            } catch (e: Exception) {
                Toast.makeText(this@EmailToLeadActivity, "Error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Opens Android file picker for selecting an attachment
    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "Select File"), PICK_FILE_REQUEST_CODE)
    }

    // Setup RecyclerView to display selected attachments
    private fun setupRecyclerView() {
        adapter = EmailToLeadAdpter(attachmentList)
        binding.emailRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.emailRecyclerView.adapter = adapter
    }

    // Handle file picker result and add selected file to list
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE_REQUEST_CODE && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                attachmentList.add(uri)
                adapter.notifyItemInserted(attachmentList.size - 1)
            }
        }
    }

    /**
     * Submit email to backend with optional attachment.
     * Uses multipart/form-data with email fields.
     */
    private fun sendEmailToLead() {
        if (!checkNetworkAndShowMessage(this)) return

        val leadId = intent.getLongExtra("lead_id", -1L)
        val email = intent.getStringExtra("lead_email") ?: ""
        val subject = binding.editTextEmailSubject.text.toString().trim()
        val body = binding.emailEditText.text.toString().trim()

        if (subject.isEmpty()) {
            Toast.makeText(this, "Please select email template.", Toast.LENGTH_SHORT).show()
            return
        }

        binding.emailSendingProgress.visibility = View.VISIBLE

        lifecycleScope.launch {
            try {
                // Prepare multipart request parts
                val leadIdPart = leadId.toString().toRequestBody("text/plain".toMediaTypeOrNull())
                val emailPart = email.toRequestBody("text/plain".toMediaTypeOrNull())
                val subjectPart = subject.toRequestBody("text/plain".toMediaTypeOrNull())
                val bodyPart = body.toRequestBody("text/plain".toMediaTypeOrNull())
                val communicationTypePart = "email".toRequestBody("text/plain".toMediaTypeOrNull())
                val channelPart = "email".toRequestBody("text/plain".toMediaTypeOrNull())
                val summaryPart = "email".toRequestBody("text/plain".toMediaTypeOrNull())
                val notesPart = "email".toRequestBody("text/plain".toMediaTypeOrNull())

                var attachmentPart: MultipartBody.Part? = null
                if (attachmentList.isNotEmpty()) {
                    val fileUri = attachmentList[0]
                    val filePath = FileUtils.getPath(this@EmailToLeadActivity, fileUri)
                    if (filePath != null) {
                        val file = File(filePath)
                        if (file.exists()) {
                            val requestFile = file.asRequestBody("application/octet-stream".toMediaTypeOrNull())
                            attachmentPart = MultipartBody.Part.createFormData("attachment", file.name, requestFile)
                        }
                    }
                }

                // API Call to send email
                val call = ApiClient.apiService.sendEmailToLead(
                    bearerToken,
                    leadIdPart,
                    emailPart,
                    subjectPart,
                    bodyPart,
                    communicationTypePart,
                    channelPart,
                    summaryPart,
                    notesPart,
                    attachmentPart
                )

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@EmailToLeadActivity,
                    showLoading = true,
                    loadingMessage = "sending",
                    apiCall = { call },
                    onSuccess = { response ->
                        binding.emailSendingProgress.visibility = View.GONE
                        if (response.emailSent) {
                            showMessageDialogAndClear(response.message ?: "Email sent successfully")
                        } else {
                            showMessageDialogAndClear(response.message ?: "Email sending failed")
                        }
                    },
                    onError = {
                        binding.emailSendingProgress.visibility = View.GONE
                        AppLogger.logAndToast(this@EmailToLeadActivity, "EC888", "EmailToLeadActivity", "sendEmailToLead", Exception(it))
                    }
                )

            } catch (e: Exception) {
                binding.emailSendingProgress.visibility = View.GONE
                AppLogger.logAndToast(this@EmailToLeadActivity, "EC999", "EmailToLeadActivity", "sendEmailToLead", e)
            }
        }
    }

    // Show dialog with success/failure message and reset form
    private fun showMessageDialogAndClear(message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Successfully")
        builder.setMessage(message)
        builder.setCancelable(false)
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
            clearEmailForm()
        }

        val dialog = builder.create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.BLACK)
    }

    // Clear all fields and reset the form after email is sent
    private fun clearEmailForm() {
        binding.editTextEmailSubject.setText("")
        binding.emailEditText.setText("")
        binding.editTextEmailSubject.setSelection(0)
        binding.wordCountText.text = ""

        // Clear file attachments
        attachmentList.clear()
        binding.emailRecyclerView.adapter?.notifyDataSetChanged()

        // Reset dropdown to default
        binding.editTextTemplateName.setSelection(0)
    }
}
