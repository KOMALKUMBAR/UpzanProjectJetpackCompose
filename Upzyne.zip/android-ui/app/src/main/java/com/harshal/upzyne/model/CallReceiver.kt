package com.harshal.upzyne.model

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresPermission
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class CallReceiver : BroadcastReceiver() {

    companion object {
        private var lastCallTime: Long = 0L
        private const val MIN_TIME_BETWEEN_CALLS_MS = 3000 // 3 seconds
    }

    @SuppressLint("ScheduleExactAlarm")
    @RequiresPermission(Manifest.permission.SCHEDULE_EXACT_ALARM)
    override fun onReceive(context: Context?, intent: Intent?) {
        try {
            if (intent?.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED || context == null) return

            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            val phoneNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

            Log.d("CallReceiver", "State: $state, Number: $phoneNumber")
            //Toast.makeText(context, "State: $state, Number: $phoneNumber", Toast.LENGTH_SHORT).show()

            if ((state == TelephonyManager.EXTRA_STATE_RINGING || state == TelephonyManager.EXTRA_STATE_OFFHOOK)
                && !phoneNumber.isNullOrBlank()) {
                val currentTime = System.currentTimeMillis()

                // Debounce multiple calls
                if (currentTime - lastCallTime < MIN_TIME_BETWEEN_CALLS_MS) return
                lastCallTime = currentTime

                if (Settings.canDrawOverlays(context)) {
                    val time = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())

                    val serviceIntent = Intent(context, FloatingWindowService::class.java).apply {
                        putExtra("phone", phoneNumber)
                        putExtra("time", time)
                        putExtra("is_incoming", true)
                    }

                    Log.d("CallReceiver", "Preparing to start service with number: $phoneNumber at $time")

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                        // Android 15 (API 35) and above: Use AlarmManager to defer the service start
                        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        val pendingIntent = PendingIntent.getService(
                            context,
                            0,
                            serviceIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )

                        alarmManager.setExact(
                            AlarmManager.RTC_WAKEUP,
                            System.currentTimeMillis() + 500, // delay 500ms
                            pendingIntent
                        )
                        Log.d("CallReceiver", "Service start deferred via AlarmManager")
                    } else {
                        // For Android 14 and below
                        ContextCompat.startForegroundService(context, serviceIntent)
                        Log.d("CallReceiver", "Service started via ContextCompat")
                    }
                } else {
                    Log.w("CallReceiver", "Overlay permission not granted")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}