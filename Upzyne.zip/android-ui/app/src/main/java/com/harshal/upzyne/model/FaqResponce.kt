package com.harshal.upzyne.model

data class FaqData(val question: String, val answer: String)

data class CompanyDetails(
    val name: String,
    val state: String,
    val city: String,
    val instagramlink: String,
    val facebooklink: String,
    val websitelink: String,
    val whatsappnumber: String,
    val postalcode: String,
    val address1: String,
    val supportemail: String,
    val address2: String,
    val supportphone: String,
    val logourl: String
)

