package com.harshal.upzyne

import android.content.Context
import android.util.Log
import com.harshal.upzyne.UtilsMethods.hideLoading
import com.harshal.upzyne.UtilsMethods.showLoading
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object ApiRequestHandler {
    suspend fun <Res> makeSuspendApiCall(
        context: Context,
        showLoading: Boolean = true,
        loadingMessage: String,
        apiCall: suspend () -> Res,
        onSuccess: (Res) -> Unit,
        onError: (String) -> Unit
    ) {
        if (showLoading) withContext(Dispatchers.Main) {
            showLoading(context, loadingMessage)
        }

        try {
            val response = apiCall()
            withContext(Dispatchers.Main) {
                onSuccess(response)
            }
        } catch (e: Exception) {
            val errorMessage = if (e is retrofit2.HttpException) {
                try {
                    val errorJson = e.response()?.errorBody()?.string()
                    JSONObject(errorJson ?: "").optString("error", "unknown error")
                } catch (ex: Exception) {
                    "unknown error"
                }
            } else {
                e.localizedMessage ?: "unknown error occurred"
            }

            Log.e("ApiRequestHandler", "API call failed: $errorMessage", e)

            withContext(Dispatchers.Main) {
                onError(errorMessage)
            }
        } finally {
            if (showLoading) withContext(Dispatchers.Main) {
                hideLoading()
            }
        }
    }
}
