package com.harshal.upzyne.model

class WorkPlaceResponce(
    val data: List<WorkPlace>
)

data class WorkPlace(
    val id: Int,
    val tenantid: Int,
    val workplacename: String
)
