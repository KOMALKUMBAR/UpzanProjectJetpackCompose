package com.harshal.upzyne.adapter.leadSummaryAdapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.CommunicationItemBinding
import com.harshal.upzyne.model.LeadsModel
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class CommunicationAdapter(
    private val context: Context,
    private val items: MutableList<LeadsModel.WhisperWire>
) : RecyclerView.Adapter<CommunicationAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: CommunicationItemBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = CommunicationItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        with(holder.binding) {
            action.text = item.actorname
            preview.text = item.preview
            time.text = formatDateTime(item.createdat ?: "")
            itemtype.text = item.itemtype
            setThemeBackground(context, setbackgroundThem)
        }
    }

    override fun getItemCount() = items.size

    fun updateData(newItems: List<LeadsModel.WhisperWire>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    private fun formatDateTime(dateTimeString: String): String {
        return try {
            val odt = OffsetDateTime.parse(dateTimeString)
            val formatter =
                DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a", Locale.getDefault())
            odt.format(formatter)
        } catch (e: Exception) {
            dateTimeString // fallback if parsing fails
        }
    }
}
