package com.harshal.upzyne.model

data class WhatsappResponseX(
    val message: String,
    val whatsappResponse: String
)