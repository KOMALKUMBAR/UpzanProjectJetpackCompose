package com.harshal.upzyne.fragment.leadfragment

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.activity.leadMenu.EmailToLeadActivity
import com.harshal.upzyne.adapter.leadSummaryAdapter.CommunicationAdapter
import com.harshal.upzyne.adapter.leadSummaryAdapter.CommunicationCallVibesAdapter
import com.harshal.upzyne.activity.leadMenu.WhisperWireActivity
import com.harshal.upzyne.databinding.FragmentCommunicationBinding
import com.harshal.upzyne.model.LeadsModel
import kotlinx.coroutines.launch

class CommunicationFragment : Fragment() {

    private var _binding: FragmentCommunicationBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: CommunicationAdapter
    private lateinit var callVibesAdapter: CommunicationCallVibesAdapter

    private var leadId: Int = -1
    private var allCommunications: List<LeadsModel.WhisperWire> = emptyList()
    private  var  allCallVibes:List<LeadsModel.CallVibe> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCommunicationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val backgroundDrawable = ContextCompat.getDrawable( requireContext(), R.drawable.left_glass_main)
      //  binding.emailCard.background = backgroundDrawable


            binding.viewAllWhisperWire.setOnClickListener {
                val intent = Intent(requireContext(), WhisperWireActivity::class.java)
                intent.putExtra("lead_id", leadId)
                intent.putExtra("lead_name", arguments?.getString("lead_name"))
                intent.putExtra("lead_email", arguments?.getString("lead_email"))
                intent.putExtra("lead_phone", arguments?.getString("lead_phone"))
                intent.putExtra("lead_timeago", arguments?.getString("lead_timeago"))
                intent.putExtra("lead_leaddate", arguments?.getString("lead_leaddate"))
                intent.putExtra("lead_statuscolor", arguments?.getString("lead_statuscolor"))
                intent.putExtra("lead_programme", arguments?.getString("lead_programme"))
                intent.putExtra("lead_sourcebadge", arguments?.getString("lead_sourcebadge"))
                intent.putExtra("lead_source", arguments?.getString("lead_source"))
                intent.putExtra("lead_verified", arguments?.getBoolean("lead_verified"))
                intent.putExtra("lead_score", arguments?.getInt("lead_score"))
                startActivity(intent)
            }



        leadId = arguments?.getInt("lead_id") ?: 0
        adapter = CommunicationAdapter(requireContext(),mutableListOf())
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        //Set teh call vibes adpter
        callVibesAdapter = CommunicationCallVibesAdapter(requireContext(), mutableListOf())
        binding.callviberecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.callviberecyclerView.adapter = callVibesAdapter

        if (leadId == 0) {
            Toast.makeText(requireContext(), "Lead ID not found", Toast.LENGTH_LONG).show()
            return
        }
        setThemeBackground(requireContext(), binding.recyclerView)
        setThemeBackground(requireContext(), binding.callviberecyclerView)



        fetchCommunication()
    }

    private fun fetchCommunication() {
        binding.progressBar.visibility = View.VISIBLE
        binding.emptyText.visibility = View.GONE

        val token = requireActivity()
            .getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            .getString("auth_token", "") ?: ""

        lifecycleScope.launch {
            try {
                val response = ApiClient.apiService.getCommunicationFeed(
                    token = "Bearer $token", // pass the Authorization header
                    leadId = leadId,
                    limit = 50,
                    offset = 0
                )

                if (!isAdded || _binding == null) return@launch

                binding.progressBar.visibility = View.GONE

                // Whisper Wire list
                allCommunications = response.whisper_wire

                if (allCommunications.isEmpty()) {
                    binding.emptyText.visibility = View.VISIBLE
                    adapter.updateData(emptyList())
                } else {
                    binding.emptyText.visibility = View.GONE

                    // show only first 3 in this screen
                    val previewList = if (allCommunications.size > 3) {
                        allCommunications.take(3)
                    } else {
                        allCommunications
                    }
                    adapter.updateData(previewList)

                    // Show/hide "View All" button
                    binding.viewAllWhisperWire.visibility =
                        if (allCommunications.size > 3) View.VISIBLE else View.GONE
                }

                // Call Vibes list
                allCallVibes = response.call_vibes
                if (allCallVibes.isEmpty()) {
                    binding.callvibeemptyText.visibility = View.VISIBLE
                    callVibesAdapter.updateData(emptyList())
                } else {
                    callVibesAdapter.updateData(allCallVibes)
                }

            } catch (e: Exception) {
                if (!isAdded || _binding == null) return@launch
                binding.progressBar.visibility = View.GONE
                binding.emptyText.visibility = View.VISIBLE
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
