package com.harshal.upzyne.adapter.leadSummaryAdapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.harshal.upzyne.R
import com.harshal.upzyne.activity.leadMenu.ReassignLeadActivity.Companion.baseUrl
import com.harshal.upzyne.activity.leadMenu.ReassignLeadActivity.Companion.selectedCounselor
import com.harshal.upzyne.databinding.ItemCounselorBinding
import com.harshal.upzyne.model.LeadsModel

class CounselorAdapter(
    private val counselorList: List<LeadsModel.counselorList>?
) : RecyclerView.Adapter<CounselorAdapter.CounselorViewHolder>() {

    private var selectedCounselorId: Int? = null

    inner class CounselorViewHolder(val binding: ItemCounselorBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CounselorViewHolder {
        val binding = ItemCounselorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CounselorViewHolder(binding)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: CounselorViewHolder, position: Int) {
        val counselor = counselorList?.get(position)

        holder.binding.apply {
            counselor?.let { counselor ->
                val imageUrl = "$baseUrl${counselor.profileurl}"    //?t=${System.currentTimeMillis()}
                Glide.with(holder.itemView.context)
                    .load(imageUrl)
                    .placeholder(R.drawable.profile)
                    .error(R.drawable.noimage)
                    .into(counselorCircluarImg)

                counselorName.text = counselor.name
                counselorRole.text = counselor.designation
                counelorStatus.text = counselor.availability
                counelorLeads.text = "${counselor.totalreallocations} ${holder.itemView.context.getString(R.string.leads)}"

                // Apply background based on selection
                if (counselor.userid == selectedCounselorId) {
                    counselorItem.setBackgroundResource(R.drawable.shape_blue_round)
                } else {
                    counselorItem.setBackgroundResource(R.drawable.white_rectangle_roundcr) // Replace with default bg
                }

                // Click to select or deselect
                counselorItem.setOnClickListener {
                    selectedCounselorId = if (selectedCounselorId == counselor.userid) {
                        null // Deselect if same item
                    } else {
                        counselor.userid
                    }

                    // Optional: update global selectedCounselor as well
                    selectedCounselor = (selectedCounselorId ?: 0)

                    notifyDataSetChanged()
                }

                // Set status dot
                val dotRes = if (counselor.availability.trim().equals("available", ignoreCase = true) == true) {
                    R.drawable.greendot
                } else {
                    R.drawable.reddot
                }
                statusDot.setImageResource(dotRes)
            }
        }
    }

    override fun getItemCount(): Int = counselorList?.size ?: 0
}
