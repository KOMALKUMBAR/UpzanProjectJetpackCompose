package com.harshal.upzyne.activity.leadMenu

import android.app.AlertDialog
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityLeadInformationBinding
import com.harshal.upzyne.model.LeadsModel
import kotlinx.coroutines.launch

class LeadInformationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLeadInformationBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String

    private var leadTypeList: List<LeadsModel.IdName> = emptyList()
    private var selectedLeadTypeId: Int? = null
    private var leadId: Int = -1
    private var selectedLeadTypeName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLeadInformationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        WindowCompat.setDecorFitsSystemWindows(window, true)
        setThemeBackground(this, binding.rootLayout)
        setThemeBackground(this, binding.rootLayout2)
        setThemeBackground(this, binding.rootLayout3)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val userFullName = sharedPref.getString("user_fname", "").toString()
        val token = sharedPref.getString("auth_token", "") ?: ""
        bearerToken = "Bearer $token"

        binding.titleText.text = "$userFullName - ${getString(R.string.lead_information)}"

        leadId = intent.getIntExtra("lead_id", -1)
/*
        if (leadId == -1) {
            Toast.makeText(this, "Invalid lead ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }*/
        binding.btnupdate.setOnClickListener {
            sendUpdateLeadInformation()
        }

        loadDropdowns()

        // Initially lock all fields
        UnchangingPersonalEditTexts()
        UnchangingAdditionalEditTexts()
        UnchangingAddressEditTexts()
       binding.imgArrow.setOnClickListener { finish() }
        // Enable sections on edit icon click
        binding.editPersonal.setOnClickListener {
            changingPersonalEditTexts(true)
        }
        binding.editAddress.setOnClickListener {
            changingAddressEditTexts(true)
        }
        binding.editAdditional.setOnClickListener {
            changingAdditionalEditTexts(true)
        }
    }

    private fun changingAdditionalEditTexts(enabled: Boolean) {
        binding.interestedField.isEnabled = enabled
        binding.btnupdate.isEnabled = enabled
        if (enabled) {
            binding.editAdditional.setColorFilter(ContextCompat.getColor(this, R.color.red))
            binding.btnupdate.setBackgroundResource(R.drawable.shape_color_btn)
            binding.btnupdate.setTextColor(ContextCompat.getColor(this, R.color.white))
        } else {
            binding.btnupdate.setBackgroundResource(R.drawable.shape_blank_btn)
            binding.btnupdate.setTextColor(ContextCompat.getColor(this, R.color.black))
        }
    }

    private fun changingAddressEditTexts(enabled: Boolean) {
        binding.add1Field.isEnabled = enabled
        binding.add2Field.isEnabled = enabled
        binding.countryField.isEnabled = enabled
        binding.stateField.isEnabled = enabled
        binding.cityField.isEnabled = enabled
        binding.pincodeField.isEnabled = enabled
        binding.btnupdate.isEnabled = enabled
        if (enabled) {
            binding.editAddress.setColorFilter(ContextCompat.getColor(this, R.color.red))
            binding.btnupdate.setBackgroundResource(R.drawable.shape_color_btn)
            binding.btnupdate.setTextColor(ContextCompat.getColor(this, R.color.white))
        } else {
            binding.btnupdate.setBackgroundResource(R.drawable.shape_blank_btn)
            binding.btnupdate.setTextColor(ContextCompat.getColor(this, R.color.black))
        }
    }

    private fun changingPersonalEditTexts(enabled: Boolean) {
        binding.nameField.isEnabled = enabled
        binding.lastnameField.isEnabled = enabled
        binding.mailField.isEnabled = enabled
        binding.numberField.isEnabled = enabled
        binding.altnumberField.isEnabled = enabled
        binding.btnupdate.isEnabled = enabled
        if (enabled) {
            binding.editPersonal.setColorFilter(ContextCompat.getColor(this, R.color.red))
            binding.btnupdate.setBackgroundResource(R.drawable.shape_color_btn)
            binding.btnupdate.setTextColor(ContextCompat.getColor(this, R.color.white))
        } else {
            binding.btnupdate.setBackgroundResource(R.drawable.shape_blank_btn)
            binding.btnupdate.setTextColor(ContextCompat.getColor(this, R.color.black))
        }
    }

    private fun UnchangingAdditionalEditTexts() {
        binding.interestedField.isEnabled = false
    }

    private fun UnchangingAddressEditTexts() {
        binding.add1Field.isEnabled = false
        binding.add2Field.isEnabled = false
        binding.countryField.isEnabled = false
        binding.stateField.isEnabled = false
        binding.cityField.isEnabled = false
        binding.pincodeField.isEnabled = false
    }

    private fun UnchangingPersonalEditTexts() {
        binding.nameField.isEnabled = false
        binding.lastnameField.isEnabled = false
        binding.mailField.isEnabled = false
        binding.numberField.isEnabled = false
        binding.altnumberField.isEnabled = false
    }

    private fun loadDropdowns() {
        lifecycleScope.launch {
            try {
                val response = ApiClient.apiService.getDropdowns(bearerToken)
                if (response.isSuccessful && response.body() != null) {
                    val data = response.body()!!
                    leadTypeList = data.lead_types ?: emptyList()
                    val names = leadTypeList.map { it.name }
                    val adapter = ArrayAdapter(
                        this@LeadInformationActivity,
                        android.R.layout.simple_spinner_item,
                        names
                    )
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    binding.spinnerThree.adapter = adapter

                    binding.spinnerThree.onItemSelectedListener = object :
                        AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(
                            parent: AdapterView<*>,
                            view: View?,
                            position: Int,
                            id: Long
                        ) {
                            selectedLeadTypeId = leadTypeList[position].id
                            selectedLeadTypeName = leadTypeList[position].name
                        }

                        override fun onNothingSelected(parent: AdapterView<*>) {}
                    }

                    loadLeadDetails()
                } else {
                    Toast.makeText(this@LeadInformationActivity, "Failed to load dropdowns", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@LeadInformationActivity, e.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadLeadDetails() {
        lifecycleScope.launch {
            try {
                val response = ApiClient.apiService.getLeadDetails(bearerToken, leadId)
                if (response.isSuccessful && response.body() != null) {
                    val lead = response.body()!!

                    binding.nameField.setText(lead.firstName ?: "")
                    binding.lastnameField.setText(lead.lastName ?: "")
                    binding.mailField.setText(lead.email ?: "")
                    binding.codeField.setText(lead.countryCode ?: "")
                    binding.numbarcodeField.setText(lead.countryCode ?: "")
                    binding.numberField.setText(lead.mobileNumber ?: "")
                    binding.altnumberField.setText(lead.altMobileNumber ?: "")
                    binding.add1Field.setText(lead.address1 ?: "")
                    binding.add2Field.setText(lead.address1 ?: "")
                    binding.countryField.setText(lead.country ?: "")
                    binding.stateField.setText(lead.state ?: "")
                    binding.cityField.setText(lead.city ?: "")
                    binding.pincodeField.setText(lead.postalCode ?: "")

                    lead.interestedProgram?.let { interestedProgram ->
                        (binding.spinnerThree as AutoCompleteTextView)
                            .setText(interestedProgram, false)

                        val position = leadTypeList.indexOfFirst { it.name == interestedProgram }
                        if (position >= 0) {
                            selectedLeadTypeId = leadTypeList[position].id
                            selectedLeadTypeName = leadTypeList[position].name
                        }
                    }
                } else {
                    Toast.makeText(this@LeadInformationActivity, "Failed to load lead details", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@LeadInformationActivity, e.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendUpdateLeadInformation() {
        if (!checkNetworkAndShowMessage(this)) return

        val request = LeadsModel.UpdateLeadDetailsRequest(
            leadId = leadId,
            firstName = binding.nameField.text.toString().trim(),
            lastName = binding.lastnameField.text.toString().trim(),
            email = binding.mailField.text.toString().trim(),
            mobileNumber = binding.numberField.text.toString().trim(),
            altMobileNumber = binding.altnumberField.text.toString().trim(),
            address1 = binding.add1Field.text.toString().trim(),
            city = binding.cityField.text.toString().trim(),
            state = binding.stateField.text.toString().trim(),
            postalCode = binding.pincodeField.text.toString().trim(),
            country = binding.countryField.text.toString().trim(),
            countryCode = binding.codeField.text.toString().trim(),
            leadTypeId = selectedLeadTypeId,
            leadTypeName = selectedLeadTypeName
        )

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.updateLeadDetails(bearerToken, request)
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@LeadInformationActivity,
                    showLoading = true,
                    loadingMessage = "Updating...",
                    apiCall = { call },
                    onSuccess = { response ->
                        val body = response.body()
                        if (body != null && body.success) {
                            showMessageDialogAndClear("Lead information updated successfully.")

                            // Lock all fields again
                            UnchangingPersonalEditTexts()
                            UnchangingAddressEditTexts()
                            UnchangingAdditionalEditTexts()
                            binding.btnupdate.isEnabled = false
                            binding.btnupdate.setBackgroundResource(R.drawable.shape_blank_btn)
                            binding.btnupdate.setTextColor(ContextCompat.getColor(this@LeadInformationActivity, R.color.black))

                            // Reload latest data
                            loadLeadDetails()
                        } else {
                            showMessageDialogAndClear("Update failed: ${body?.message ?: "Unknown error"}")
                        }
                    },
                    onError = {
                        AppLogger.logAndToast(this@LeadInformationActivity, "EC888", "LeadInformationActivity", "sendUpdateLeadInformation", Exception(it))
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(this@LeadInformationActivity, "EC999", "LeadInformationActivity", "sendUpdateLeadInformation", e)
            }
        }
    }

    private fun showMessageDialogAndClear(message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Message")
        builder.setMessage(message)
        builder.setCancelable(false)
        builder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        val dialog = builder.create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.BLACK)
    }
}
