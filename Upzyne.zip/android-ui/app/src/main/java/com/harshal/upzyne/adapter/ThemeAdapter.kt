package com.harshal.upzyne.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.saveGradientColors
import com.harshal.upzyne.UtilsMethods.setDynamicGradientBackground
import com.harshal.upzyne.databinding.ItemThemeBinding
import com.harshal.upzyne.model.Backgrounds

class ThemeAdapter(private val themeList: List<Backgrounds>) :
    RecyclerView.Adapter<ThemeAdapter.ThemeViewHolder>() {

    inner class ThemeViewHolder(val binding: ItemThemeBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ThemeAdapter.ThemeViewHolder {
        val binding = ItemThemeBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ThemeViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ThemeAdapter.ThemeViewHolder, position: Int) {
        val item = themeList[position]

        holder.binding.btnTheme.text = item.name
        holder.binding.btnTheme.setDynamicGradientBackground(
            startColor = item.startColor,
            centerColor = item.centerColor,
            endColor = item.endColor,
            cornerRadiusDp = 10f
        )
        holder.binding.btnTheme.setOnClickListener {
            saveTheme(holder.itemView.context, item)
        }
    }

    override fun getItemCount(): Int = themeList.size

    private fun saveTheme(context: Context, selectedBackground: Backgrounds) {
        // Save the gradient colors
        saveGradientColors(
            context,
            selectedBackground.startColor,
            selectedBackground.centerColor,
            selectedBackground.endColor
        )
        Toast.makeText(context, context.getString(R.string.theme_set_successfully), Toast.LENGTH_SHORT).show()
    }
}