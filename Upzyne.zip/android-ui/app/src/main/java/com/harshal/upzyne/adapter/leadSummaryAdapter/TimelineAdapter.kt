package com.harshal.upzyne.adapter.leadSummaryAdapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ItemTimelineBinding
import com.harshal.upzyne.model.LeadsModel
import java.text.SimpleDateFormat
import java.util.*

class TimelineAdapter(
    private val context: Context, private val leadId: Int, // Lead ID passed for potential future use (e.g., API calls, filtering)
    private var items: MutableList<LeadsModel.TimelineItem> // List of timeline items to display
) : RecyclerView.Adapter<TimelineAdapter.ViewHolder>() {

    /**
     * ViewHolder class to hold and bind the item view using ViewBinding
     */

    inner class ViewHolder(val binding: ItemTimelineBinding) :
        RecyclerView.ViewHolder(binding.root) {

        /**
         * Binds data from a TimelineItem object to UI elements in the layout
         */
        fun bind(item: LeadsModel.TimelineItem) {
            binding.tvTitle.text = item.title ?: "-"
            binding.tvtype.text = item.type ?: "-"
            binding.tvmessage.text = item.message ?: "-"
            binding.tvDate.text = formatDateTime(item.time)
            binding.bydata.text = if (!item.by.isNullOrBlank()) "by ${item.by}" else ""
            setThemeBackground(context, binding.setbackgroundThem)
        }
    }

    /**
     * Inflates the item layout and creates the ViewHolder
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(
            ItemTimelineBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )

    /**
     * Binds the data for each item in the list to the ViewHolder
     */
    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(items[position])

    /**
     * Returns total number of items in the list
     */
    override fun getItemCount(): Int = items.size

    /**
     * Updates the adapter's list with new data and refreshes the UI
     */
    fun updateList(newList: List<LeadsModel.TimelineItem>) {
        items.clear() // Remove old data
        items.addAll(newList) // Add new data
        notifyDataSetChanged() // Refresh the RecyclerView
    }

    /**
     * Converts API time string to a human-readable date format
     * Example: "2025-08-12T10:30:00" → "12 Aug, 10:30 AM"
     */
    private fun formatDateTime(apiTime: String?): String {
        if (apiTime.isNullOrBlank()) return ""
        return try {
            val input = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
            input.timeZone = TimeZone.getTimeZone("UTC") // API time is in UTC
            val date = input.parse(apiTime)
            if (date != null) {
                SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(date)
            } else apiTime
        } catch (e: Exception) {
            apiTime // In case of parsing error, return raw API string
        }
    }
}
