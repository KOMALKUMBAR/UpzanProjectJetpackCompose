package com.harshal.upzyne.activity.leadMenu

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.LayoutInflater
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ActivitySendMessageBinding
import com.harshal.upzyne.databinding.ItemLeadProfileLayoutBinding
import com.harshal.upzyne.model.LeadsModel
import kotlinx.coroutines.launch

class SendMessageActivity : AppCompatActivity() {

    // Global variables for user & lead info
    private lateinit var userFullName: String
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private lateinit var binding: ActivitySendMessageBinding
    private lateinit var phoneNumber: String
    private var smsTemplateList: List<LeadsModel.SmsTemplate> = emptyList()
    private var selectedTemplateBody: String = ""

    /**
     * Handle multi-language (called before onCreate)
     */
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    /**
     * onCreate → main entry point of activity
     *  - Setup layout
     *  - Load SharedPreferences
     *  - Fill lead details
     *  - Handle UI button selections
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySendMessageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        /** Load user details & auth token */
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "").toString()
        val token = sharedPref.getString("auth_token", "") ?: ""
        bearerToken = "Bearer $token"

        /** Set screen title */
        binding.titleText.text = "$userFullName - ${getString(R.string.send_message)}"
        setThemeBackground(this, binding.lay)

        /** Inflate lead profile layout dynamically */
        val itemLeadBinding = ItemLeadProfileLayoutBinding.inflate(
            LayoutInflater.from(this), binding.leadContainer, false
        )
        binding.leadContainer.addView(itemLeadBinding.root)

        /** Fill lead details from Intent extras */
        val leadStatusColor = intent.getStringExtra("lead_statuscolor") ?: "#3E4A59"
        val leadVerified = intent.getBooleanExtra("lead_verified", false)
        itemLeadBinding.userName.text = intent.getStringExtra("lead_name")
        itemLeadBinding.userEmail.text = intent.getStringExtra("lead_email")
        itemLeadBinding.userPhone.text = intent.getStringExtra("lead_phone")
        itemLeadBinding.engagedDate.text = "engaged: ${intent.getStringExtra("lead_timeago")}"
        itemLeadBinding.joinedDate.text = "joinedDate: ${intent.getStringExtra("lead_leaddate")}"
        itemLeadBinding.course.text = intent.getStringExtra("lead_programme")
        itemLeadBinding.statusIcon.text = intent.getStringExtra("lead_sourcebadge")
        itemLeadBinding.tvOtpVerification.visibility = if (leadVerified) View.VISIBLE else View.GONE

        /** Status label with dynamic color */
        val labelDrawable = itemLeadBinding.labelNewLead.background?.mutate()
        val colorWithAlpha = (leadStatusColor.toColorInt() and 0x00FFFFFF) or (0x30 shl 24)
        labelDrawable?.setColorFilter(colorWithAlpha, PorterDuff.Mode.SRC_ATOP)
        itemLeadBinding.labelNewLead.background = labelDrawable
        itemLeadBinding.labelNewLead.setTextColor(leadStatusColor.toColorInt())
        itemLeadBinding.labelNewLead.text = intent.getStringExtra("lead_source") ?: ""

        /** Add left border color */
        val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.left_glass)
        if (backgroundDrawable is LayerDrawable) {
            val leftBorder = backgroundDrawable.findDrawableByLayerId(R.id.left_border)
            if (leftBorder is GradientDrawable) {
                leftBorder.setColor(leadStatusColor.toColorInt())
            }
            itemLeadBinding.itemLead.background = backgroundDrawable
        }

        /** Back button */
        binding.imgArrow.setOnClickListener { finish() }

        /** Handle Message type selection (SMS, WhatsApp, Business WhatsApp) */
        val selectedDrawable = ContextCompat.getDrawable(this, R.drawable.shape_color_btn)
        val defaultDrawable = ContextCompat.getDrawable(this, R.drawable.white_rectangle_roundcr)

        binding.messageButton.setOnClickListener {
            binding.messageButton.background = selectedDrawable
            binding.whatsappButton.background = defaultDrawable
            binding.busswhatsappBtn.background = defaultDrawable
            binding.messageIcon.setImageResource(R.drawable.ic_white_massage)
        }
        binding.whatsappButton.setOnClickListener {
            binding.messageButton.background = defaultDrawable
            binding.whatsappButton.background = selectedDrawable
            binding.busswhatsappBtn.background = defaultDrawable
            binding.messageIcon.setImageResource(R.drawable.ic_black_massage_icon)
        }
        binding.busswhatsappBtn.setOnClickListener {
            binding.messageButton.background = defaultDrawable
            binding.whatsappButton.background = defaultDrawable
            binding.busswhatsappBtn.background = selectedDrawable
            binding.messageIcon.setImageResource(R.drawable.ic_black_massage_icon)
        }

        /** Toggle switch → change color */
        binding.toggleSwitch.setOnCheckedChangeListener { _, isChecked ->
            val color = if (isChecked) Color.BLUE else Color.GRAY
            binding.toggleSwitch.thumbTintList = ColorStateList.valueOf(color)
            binding.toggleSwitch.trackTintList = ColorStateList.valueOf(color)
        }

        /** Fetch SMS templates from API */
        fetchSmsTemplates()

        /** Send button action */
        binding.SendSms.setOnClickListener { sendSms() }
    }

    /**
     * Fetch list of SMS templates from API
     * - Fill spinner
     * - When user selects, set template text in EditText
     */
    private fun fetchSmsTemplates() {
        lifecycleScope.launch {
            try {
                val response = ApiClient.apiService.getSmsTemplates(bearerToken)
                smsTemplateList = response

                val templateTitles = mutableListOf("Select SMS template...")
                templateTitles.addAll(smsTemplateList.map { it.smstext })

                val adapter = object : ArrayAdapter<String>(
                    this@SendMessageActivity,
                    android.R.layout.simple_spinner_item,
                    templateTitles
                ) {
                    override fun isEnabled(position: Int): Boolean = position != 0
                    override fun getDropDownView(
                        position: Int, convertView: View?, parent: ViewGroup
                    ): View {
                        val view = super.getDropDownView(position, convertView, parent)
                        (view as TextView).setTextColor(
                            if (position == 0) Color.GRAY else Color.BLACK
                        )
                        return view
                    }
                }

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.smsTemplateSpinner.adapter = adapter

                // Template select → set text
                binding.smsTemplateSpinner.onItemSelectedListener =
                    object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(
                            parent: AdapterView<*>, view: View?, position: Int, id: Long
                        ) {
                            if (position > 0) {
                                selectedTemplateBody = smsTemplateList[position - 1].smstext
                                binding.emailEditText.setText(selectedTemplateBody)
                                // reset spinner
                                binding.smsTemplateSpinner.post {
                                    binding.smsTemplateSpinner.setSelection(0)
                                }
                            }
                        }

                        override fun onNothingSelected(parent: AdapterView<*>) {
                            selectedTemplateBody = ""
                            binding.emailEditText.setText("")
                        }
                    }

            } catch (e: Exception) {
                Toast.makeText(
                    this@SendMessageActivity,
                    "Failed to load SMS templates",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    /**
     * Send SMS/WhatsApp/Business WhatsApp
     * - Collect lead info & text
     * - Call API to log the message
     * - On success → show dialog
     */
    private fun sendSms() {
        val leadId = intent.getLongExtra("lead_id", -1L)
        phoneNumber = intent.getStringExtra("lead_phone") ?: ""
        val smsText = binding.emailEditText.text.toString().trim()

        if (smsText.isEmpty()) {
            Toast.makeText(this, "select the sms template ", Toast.LENGTH_SHORT).show()
            return
        }

        // Find which button is selected
        val selectedType = when {
            binding.messageButton.background.constantState ==
                    ContextCompat.getDrawable(this, R.drawable.shape_color_btn)?.constantState -> "sms"

            binding.whatsappButton.background.constantState ==
                    ContextCompat.getDrawable(this, R.drawable.shape_color_btn)?.constantState -> "whatsapp"

            else -> "business_whatsapp"
        }

        // Build request object
        val smsRequest = LeadsModel.SmsPostRequest(
            leadid = leadId,
            mobileno = phoneNumber,
            smstext = smsText,
            messagetype = selectedType,
            status = "sent"
        )

        // Call API
        lifecycleScope.launch {
            try {
                val response = ApiClient.apiService.sendSmsMessage(bearerToken, smsRequest)
                showMessageDialogAndProceed(response.message, selectedType, smsText)
            } catch (e: Exception) {
                showMessageDialogAndProceed("Failed to send message", selectedType, smsText)
            }
        }
    }

    /**
     * Show confirmation dialog after API success
     * On OK → open respective app (SMS, WhatsApp, WhatsApp Business)
     */
    private fun showMessageDialogAndProceed(message: String, selectedType: String, smsText: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Successfully")
        builder.setMessage(message)
        builder.setCancelable(false)
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
            openSelectedApp(selectedType, smsText)
            clearForm()
        }
        val dialog = builder.create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.BLACK)
    }

    /**
     * Open the chosen messaging app with prefilled text
     */
    private fun openSelectedApp(selectedType: String, smsText: String) {
        when (selectedType) {
            /** Normal SMS */
            "sms" -> {
                val smsIntent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("sms:$phoneNumber")
                    putExtra("sms_body", smsText)
                }
                startActivity(smsIntent)
            }

            /** WhatsApp */
            "whatsapp" -> {
                try {
                    val uri = Uri.parse("https://wa.me/$phoneNumber?text=${Uri.encode(smsText)}")
                    val waIntent = Intent(Intent.ACTION_VIEW, uri)
                    waIntent.setPackage("com.whatsapp")
                    startActivity(waIntent)
                } catch (e: Exception) {
                    Toast.makeText(this, "WhatsApp not found", Toast.LENGTH_SHORT).show()
                }
            }

            /** WhatsApp Business */
            "business_whatsapp" -> {
                try {
                    val uri = Uri.parse("https://wa.me/$phoneNumber?text=${Uri.encode(smsText)}")
                    val waBizIntent = Intent(Intent.ACTION_VIEW, uri)
                    waBizIntent.setPackage("com.whatsapp.w4b")
                    startActivity(waBizIntent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Business WhatsApp not found", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /**
     * Reset form inputs back to default state
     */
    private fun clearForm() {
        binding.emailEditText.setText("")
        binding.smsTemplateSpinner.setSelection(0)
        binding.toggleSwitch.isChecked = false
    }
}
