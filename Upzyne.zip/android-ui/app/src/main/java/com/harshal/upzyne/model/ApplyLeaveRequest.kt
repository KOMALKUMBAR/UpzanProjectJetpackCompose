package com.harshal.upzyne.model

/*data class ApplyLeaveRequest(
    val userId: Int,
    val dateFrom: String,
    val dateTo: String,
    val totalDays: Int,
    val leaveType: String,
    val leavePeriod: String,
    val remarks: String,
    val attachmentUrl: String,
    val workCoverBy: Int
)*/
data class ApplyLeaveRequestData(
    val dateFrom: String,
    val dateTo: String,
    val totalDays: Int,
    val leaveType: String,
    val leavePeriod: String,
    val remarks: String,
    val workCoverBy: Int
)

data class ApplyLeaveResponse(
    val status: Boolean,
    val message: String,
    val fileUrl: String? = null // If server returns the uploaded file URL
)
