package com.harshal.upzyne.adapter.leadsAdpter

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import android.util.Log
import android.util.TypedValue
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.maskPhoneNumber
import com.harshal.upzyne.model.LeadsModel
import androidx.core.graphics.drawable.toDrawable
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.getErrorAlertDialog
import com.harshal.upzyne.UtilsMethods.hideLoading
import com.harshal.upzyne.UtilsMethods.showLoading
import com.harshal.upzyne.activity.leadMenu.OwnedLeadsActivity
import com.harshal.upzyne.activity.leadMenu.OwnedLeadsActivity.Companion.bearerToken
import com.harshal.upzyne.activity.leadMenu.ReassignLeadActivity
import com.harshal.upzyne.activity.leadMenu.EmailToLeadActivity
import com.harshal.upzyne.activity.leadMenu.OwnedLeadsActivity.Companion.isCalled
import com.harshal.upzyne.activity.leadMenu.LeadSummaryActivity
import com.harshal.upzyne.activity.leadMenu.SendMessageActivity
import com.harshal.upzyne.activity.leadMenu.UpdateStatusActivity
import com.harshal.upzyne.activity.leadMenu.SetReminderActivity
import com.harshal.upzyne.adapter.leadSummaryAdapter.ItemClickInterface
import com.harshal.upzyne.databinding.DialogCallsummaryBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class OwnedLeadsAdapter(
    private val contextActivity: Context,
    private val coroutineScope: CoroutineScope,
    private val leads: List<LeadsModel.LeadsModelDataClasss.LeadData>,
    val itemClickInterface: ItemClickInterface
) : RecyclerView.Adapter<OwnedLeadsAdapter.ViewHolder>() {
    private var selectedLead: Long = 0

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name = view.findViewById<TextView>(R.id.user_name)
        val phone = view.findViewById<TextView>(R.id.user_phone)
        val score = view.findViewById<TextView>(R.id.progress)
        val status = view.findViewById<TextView>(R.id.label_new_lead)
        val course = view.findViewById<TextView>(R.id.course)
        val joined = view.findViewById<TextView>(R.id.joinedDate)
        val engaged = view.findViewById<TextView>(R.id.engagedDate)
        val viewLay = view.findViewById<LinearLayout>(R.id.itemLead)
        val status_icon = view.findViewById<TextView>(R.id.status_icon)
        val budge = view.findViewById<ImageView>(R.id.tv_otpVerification)
        val imgMenu = view.findViewById<ImageView>(R.id.more_btn)
        val btnCall = view.findViewById<ImageView>(R.id.call_btn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.item_owned_leads, parent, false)
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int = leads.size

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val lead = leads[position]
        val statusColor = lead.statuscolor
        val scoreColor = lead.leadscorecolor
        holder.name.text = lead.name
        holder.phone.text = maskPhoneNumber(lead.phonenumber)
        val drawable = ContextCompat.getDrawable(
            holder.itemView.context,
            R.drawable.shape_circle_red
        ) as GradientDrawable
        drawable.setStroke(3, scoreColor.toColorInt())
        holder.score.background = drawable
        holder.score.text = "${lead.percentage_score}%"

        val drawable1 = holder.status.background?.mutate()
        val colorWithAlpha = (statusColor.toColorInt() and 0x00FFFFFF) or (0x30 shl 24)
        drawable1?.setColorFilter(colorWithAlpha, PorterDuff.Mode.SRC_ATOP)
        holder.status.background = drawable1
        holder.status.setTextColor(statusColor.toColorInt())

        holder.status.text = lead.statuslabel
        holder.course.text = lead.programme
        holder.course.paintFlags = holder.course.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        holder.joined.text = "joined: ${lead.leaddate}"
        holder.engaged.text = "engaged: ${lead.timeago}"
        holder.status_icon.text = lead.sourcebadge
        holder.budge.visibility = if (lead.isotpverified) View.VISIBLE else View.GONE

        val backgroundDrawable =
            ContextCompat.getDrawable(holder.itemView.context, R.drawable.left_glass)
        if (backgroundDrawable is LayerDrawable) {
            val leftBorder = backgroundDrawable.findDrawableByLayerId(R.id.left_border)
            if (leftBorder is GradientDrawable) {
                leftBorder.setColor(statusColor.toColorInt())
            }
            holder.viewLay.background = backgroundDrawable
        }

        holder.imgMenu.setOnClickListener {
            showPopupMenu(holder.itemView.context, holder.imgMenu, lead)
        }

        holder.btnCall.setOnClickListener {
            selectedLead = lead.leadid.toLong()
            Log.d("selectedLead", "$selectedLead")
            showCallPopupMenu(
                holder.itemView.context,
                holder.btnCall,
                lead.phonenumber,
                lead.alternatephone
            )
        }

        holder.course.setOnClickListener {
            showCoursePopupMenu(holder.itemView.context, lead)
        }

        holder.score.setOnClickListener {
            itemClickInterface.onLeadScoreClick(lead.leadid)
        }

        holder.itemView.setOnClickListener {
            val intent = Intent(contextActivity, LeadSummaryActivity::class.java)
            // Example: pass lead ID and name (customize based on what you need)
            // Pass the lead ID (and other optional details)
            intent.putExtra("lead_id", lead.leadid)
            intent.putExtra("lead_name", lead.name)
            intent.putExtra("lead_email", lead.email)
            intent.putExtra("lead_phone", lead.phonenumber)
            intent.putExtra("lead_timeago", lead.timeago)
            intent.putExtra("lead_leaddate", lead.leaddate)
            intent.putExtra("lead_statuscolor", lead.statuscolor)
            intent.putExtra("lead_programme", lead.programme)
            intent.putExtra("lead_sourcebadge", lead.sourcebadge)
            intent.putExtra("lead_source", lead.statuslabel)
            intent.putExtra("lead_verified", lead.isotpverified)
            intent.putExtra("lead_score", lead.percentage_score)
            val drawable = ContextCompat.getDrawable(
                holder.itemView.context,
                R.drawable.shape_circle_red
            ) as GradientDrawable
            drawable.setStroke(3, scoreColor.toColorInt())
            holder.score.background = drawable
            holder.score.text = "${lead.percentage_score}%"
            contextActivity.startActivity(intent)
        }
    }

    // ======================== COMMON HELPERS ===========================

    private fun createPopupWindow(popupView: View): PopupWindow {
        return PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        ).apply {
            elevation = 10f
            isOutsideTouchable = true
            isFocusable = true
            setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
        }
    }

    private fun dimBackground(context: Context, popupWindow: PopupWindow): View {
        val parentView = (context as Activity).window.decorView.rootView
        val dimView = View(context).apply {
            setBackgroundColor("#80000000".toColorInt())
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        (parentView as ViewGroup).addView(dimView)
        popupWindow.setOnDismissListener { parentView.removeView(dimView) }
        return dimView
    }

    private fun positionPopup(
        anchor: View,
        popupWindow: PopupWindow,
        popupView: View,
        context: Context
    ) {
        val marginPx = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, 20f, context.resources.displayMetrics
        ).toInt()

        popupView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val popupWidth = popupView.measuredWidth
        val popupHeight = popupView.measuredHeight

        val displayMetrics = context.resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels

        val location = IntArray(2)
        anchor.getLocationOnScreen(location)
        val anchorX = location[0]
        val anchorY = location[1]

        val x = anchorX.coerceIn(marginPx, screenWidth - popupWidth - marginPx)
        val showBelow = anchorY + anchor.height + popupHeight + marginPx <= screenHeight

        if (showBelow) {
            popupWindow.showAsDropDown(anchor, x - anchorX, 0)
        } else {
            val y = (anchorY - popupHeight).coerceAtLeast(marginPx)
            popupWindow.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
        }
    }

    @SuppressLint("MissingInflatedId")
    private fun showPopupMenu(
        context: Context,
        imgMenu: ImageView,
        lead: LeadsModel.LeadsModelDataClasss.LeadData
    ) {
        val inflater = LayoutInflater.from(context)
        val popupView = inflater.inflate(R.layout.menu_leaditem_popup, null)
        val popupWindow = createPopupWindow(popupView)

        val clickListener = View.OnClickListener { view ->
            popupWindow.dismiss()
            when (view.id) {
                R.id.mnChangeOwner -> {
                    val intent = Intent(context, ReassignLeadActivity::class.java)
                    intent.putExtra("lead_name", lead.name)
                    intent.putExtra("lead_email", lead.email)
                    intent.putExtra("lead_phone", lead.phonenumber)
                    intent.putExtra("lead_timeago", lead.timeago)
                    intent.putExtra("lead_leaddate", lead.leaddate)
                    intent.putExtra("lead_statuscolor", lead.statuscolor)
                    intent.putExtra("lead_programme", lead.programme)
                    intent.putExtra("lead_id", lead.leadid)
                    intent.putExtra("lead_sourcebadge", lead.sourcebadge)
                    intent.putExtra("lead_source", lead.statuslabel)
                    intent.putExtra("lead_verified", lead.isotpverified)
                    context.startActivity(intent)
                }

                R.id.mnEmailLead -> {
                    val intent = Intent(context, EmailToLeadActivity::class.java)
                    intent.putExtra("lead_name", lead.name)
                    intent.putExtra("lead_email", lead.email)
                    intent.putExtra("lead_phone", lead.phonenumber)
                    intent.putExtra("lead_score", lead.leadscore)
                    intent.putExtra("lead_timeago", lead.timeago)
                    intent.putExtra("lead_leaddate", lead.leaddate)
                    intent.putExtra("lead_leadscorecolor", lead.leadscorecolor)
                    intent.putExtra("lead_statuscolor", lead.statuscolor)
                    intent.putExtra("lead_programme", lead.programme)
                    intent.putExtra("lead_id", lead.leadid)
                    intent.putExtra("lead_source", lead.statuslabel)
                    intent.putExtra("lead_sourcebadge", lead.sourcebadge)
                    context.startActivity(intent)
                }

                R.id.mnWhatsappChat -> {
                    val intent = Intent(context, SendMessageActivity::class.java)
                    intent.putExtra("lead_name", lead.name)
                    intent.putExtra("lead_email", lead.email)
                    intent.putExtra("lead_phone", lead.phonenumber)
                    intent.putExtra("lead_score", lead.leadscore)
                    intent.putExtra("lead_timeago", lead.timeago)
                    intent.putExtra("lead_leaddate", lead.leaddate)
                    intent.putExtra("lead_leadscorecolor", lead.leadscorecolor)
                    intent.putExtra("lead_statuscolor", lead.statuscolor)
                    intent.putExtra("lead_programme", lead.programme)
                    intent.putExtra("lead_id", lead.leadid)
                    intent.putExtra("lead_source", lead.statuslabel)
                    intent.putExtra("lead_sourcebadge", lead.sourcebadge)
                    intent.putExtra("lead_sourcebadge", lead.sourcebadge)

                    context.startActivity(intent)
                }

                R.id.mnSetReminder -> {
                    val intent = Intent(context, SetReminderActivity::class.java)
                    intent.putExtra("lead_name", lead.name)
                    intent.putExtra("lead_email", lead.email)
                    intent.putExtra("lead_phone", lead.phonenumber)
                    intent.putExtra("lead_score", lead.leadscore)
                    intent.putExtra("lead_timeago", lead.timeago)
                    intent.putExtra("lead_leaddate", lead.leaddate)
                    intent.putExtra("lead_leadscorecolor", lead.leadscorecolor)
                    intent.putExtra("lead_statuscolor", lead.statuscolor)
                    intent.putExtra("lead_programme", lead.programme)
                    intent.putExtra("lead_id", lead.leadid)
                    intent.putExtra("lead_sourcebadge", lead.sourcebadge)
                    intent.putExtra("lead_source", lead.statuslabel)
                    context.startActivity(intent)
                }

                R.id.mnChangeStatus -> {
                    val intent = Intent(context, UpdateStatusActivity::class.java)
                    intent.putExtra("lead_name", lead.name)
                    intent.putExtra("lead_email", lead.email)
                    intent.putExtra("lead_phone", lead.phonenumber)
                    intent.putExtra("lead_timeago", lead.timeago)
                    intent.putExtra("lead_leaddate", lead.leaddate)
                    intent.putExtra("lead_statuscolor", lead.statuscolor)
                    intent.putExtra("lead_programme", lead.programme)
                    intent.putExtra("lead_id", lead.leadid)
                    intent.putExtra("lead_sourcebadge", lead.sourcebadge)
                    intent.putExtra("lead_source", lead.statuslabel)
                    intent.putExtra("lead_verified", lead.isotpverified)
                    context.startActivity(intent)
                }

                else -> {
                    Toast.makeText(context, "clicked: ${view.id}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val menuItemIds = listOf(
            R.id.mnSmartInsights,
            R.id.mnChangeOwner,
            R.id.mnSetReminder,
            R.id.mnChangeStatus,
            R.id.mnEmailLead,
            R.id.mnWhatsappChat,
            R.id.mnLeadScore
        )

        menuItemIds.forEach { id ->
            popupView.findViewById<View>(id).setOnClickListener(clickListener)
        }

        dimBackground(context, popupWindow)
        positionPopup(imgMenu, popupWindow, popupView, context)
    }

    //============== PopupMenus ==============

    private fun showCoursePopupMenu(
        context: Context,
        lead: LeadsModel.LeadsModelDataClasss.LeadData
    ) {
        val inflater = LayoutInflater.from(context)
        val popupView = inflater.inflate(R.layout.menu_couseitem_popup, null)

        val salesText = popupView.findViewById<TextView>(R.id.salesText)
        salesText.text = lead.salespitch

        val upsellText = popupView.findViewById<TextView>(R.id.upsellpitch)
        upsellText.text = lead.upsellpitch

        val uspLayout = popupView.findViewById<LinearLayout>(R.id.uspText)
        uspLayout.removeAllViews()

        val uspItems = lead.usp.split("\\n", "\n") // support both escaped and real line breaks

        for (item in uspItems) {
            val itemLayout = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                val image = ImageView(context).apply {
                    setImageResource(R.drawable.ic_check_circle_green)
                    layoutParams = LinearLayout.LayoutParams(30, 30).apply {
                        setMargins(0, 0, 10, 10) // left, top, right, bottom
                    }
                }

                val text = TextView(ContextThemeWrapper(context, R.style.paragraph2)).apply {
                    text = item.trim().replace("•", "")
                    textSize = 14f
                    setTextColor(Color.BLACK)
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }

                addView(image)
                addView(text)
            }

            uspLayout.addView(itemLayout)
        }

        val popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        )

        popupWindow.elevation = 10f
        popupWindow.isOutsideTouchable = true

        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0)

        val gotItBtn = popupView.findViewById<Button>(R.id.gotit)
        gotItBtn.setOnClickListener {
            popupWindow.dismiss()
        }
    }

    private fun showCallPopupMenu(
        context: Context,
        btnCall: ImageView,
        contactNumber1: String,
        contactNumber2: String
    ) {
        val inflater = LayoutInflater.from(context)
        val popupView = inflater.inflate(R.layout.menu_call_popup, null)
        val popupWindow = createPopupWindow(popupView)

        val clickListener = View.OnClickListener { view ->
            popupWindow.dismiss()
            when (view.id) {
                R.id.mnPhone1 -> {
                    registerPhoneStateListener(context, contactNumber1)

                    // Example: make call after 0.5 seconds delay
                    Handler(Looper.getMainLooper()).postDelayed({
                        makePhoneCall(context, contactNumber1)
                    }, 500)
                }

                R.id.mnPhone2 -> {
                    registerPhoneStateListener(context, contactNumber2)

                    // Example: make call after 0.5 seconds delay
                    Handler(Looper.getMainLooper()).postDelayed({
                        makePhoneCall(context, contactNumber2)
                    }, 500)
                }
            }
        }

        popupView.findViewById<TextView>(R.id.mnPhone1).apply {
            text = contactNumber1
            setOnClickListener(clickListener)
        }
        popupView.findViewById<TextView>(R.id.mnPhone2).apply {
            text = contactNumber2
            setOnClickListener(clickListener)
        }

        dimBackground(context, popupWindow)
        positionPopup(btnCall, popupWindow, popupView, context)
    }

    private fun makePhoneCall(context: Context, phoneNumber: String) {
        val callIntent = Intent(Intent.ACTION_CALL)
        callIntent.data = Uri.parse("tel:$phoneNumber")
        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.CALL_PHONE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                context as Activity, arrayOf(Manifest.permission.CALL_PHONE), 200
            )
            return
        }
        context.startActivity(callIntent)
        isCalled = true
    }

    private var phoneStateListener: PhoneStateListener? = null
    private var hasCallStarted = false
    private var hasCallEnded = false
    private var isOutgoingCallInitiated = false

    fun registerPhoneStateListener(context: Context, contactNumber: String) {
        val telephonyManager =
            context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

        phoneStateListener = object : PhoneStateListener() {
            override fun onCallStateChanged(state: Int, incomingNumber: String?) {
                Log.d("PhoneState", "State: $state")

                when (state) {
                    TelephonyManager.CALL_STATE_RINGING -> {
                        Log.d("PhoneState", "Incoming call ringing")
                        // Not our use case
                    }

                    TelephonyManager.CALL_STATE_OFFHOOK -> {
                        hasCallStarted = true
                        hasCallEnded = false
                        isOutgoingCallInitiated = true
                        Log.d("PhoneState", "Call started (OFFHOOK)")
                    }

                    TelephonyManager.CALL_STATE_IDLE -> {
                        if (hasCallStarted && !hasCallEnded) {
                            // Normal call ended after starting
                            hasCallEnded = true
                            hasCallStarted = false
                            isOutgoingCallInitiated = false
                            Log.d("PhoneState", "Call ended after being off-hook")
                            onCallEnded(context, contactNumber)

                        } else if (isOutgoingCallInitiated && !hasCallStarted) {
                            // Outgoing call ended before going OFFHOOK (i.e., not picked up)
                            isOutgoingCallInitiated = false
                            Log.d("PhoneState", "Call ended before being picked up (cancelled)")
                            onCallEnded(context, contactNumber)
                        } else {
                            Log.d("PhoneState", "Idle state, no action needed")
                        }
                    }
                }
            }
        }

        telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE)
    }

    private fun onCallEnded(context: Context, phoneNumber: String) {
        showLoading(context, context.getString(R.string.loading))
        Handler(Looper.getMainLooper()).postDelayed({
            val logEntry = getLatestCallLog(context, phoneNumber.replace(Regex("\\D"), ""))

            if (logEntry != null) {
                //val endTime = Date(logEntry.date.time + logEntry.durationSeconds * 1000)
                val endTime = Date(System.currentTimeMillis())
                val recording = findCallRecording(phoneNumber, endTime)
                val inputString = logEntry.date.toString()
                Log.d("end_time", "$inputString - ${endTime} - ${recording}")

                // Step 1: Parse the input string into a Date object
                val inputFormat = SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH)
                val date: Date =
                    inputFormat.parse(inputString)
                        ?: throw IllegalArgumentException("Invalid date")

                // Step 2: Format it into your desired format
                val outputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ENGLISH)
                val formattedDate = outputFormat.format(date)

                println(formattedDate)

                Log.d(
                    "latestCallDetails",
                    "${recording?.absolutePath} - ${selectedLead} - $phoneNumber - ${logEntry.durationSeconds} - $formattedDate - ${logEntry.type}"
                )
                uploadCallRecording(
                    context,
                    recording?.absolutePath ?: "null",
                    selectedLead,
                    phoneNumber,
                    logEntry.durationSeconds.toString(),
                    formattedDate,
                    logEntry.type
                )
            } else {
                hideLoading()
                getErrorAlertDialog(context, "no call log found for $phoneNumber")
            }
        }, 3000)
    }

    private fun uploadCallRecording(
        context: Context,
        fileName: String,
        leadId: Long,
        mobileNo: String,
        callDuration: String,
        callDate: String,
        callType: String
    ) {
        coroutineScope.launch {
            try {
                val recordingFile = File(fileName)

                //val requestFile = recordingFile.asRequestBody("audio/*".toMediaTypeOrNull())
                //val file = MultipartBody.Part.createFormData("filename", recordingFile.name, requestFile)

                val filePart: MultipartBody.Part? = if (recordingFile.exists()) {
                    val requestFile = recordingFile.asRequestBody("audio/*".toMediaTypeOrNull())
                    MultipartBody.Part.createFormData(
                        "filename",
                        recordingFile.name,
                        requestFile
                    )
                } else {
                    Log.w("uploadstatus", "Recording file not found, proceeding without file.")
                    null
                }

                Log.d("requestFile", "$recordingFile - $filePart")

                val call = ApiClient.apiService.uploadCallRecording(
                    OwnedLeadsActivity.bearerToken,
                    filePart,
                    leadId,
                    mobileNo,
                    callDuration,
                    callDate,
                    callType
                )
                ApiRequestHandler.makeSuspendApiCall(
                    context = context,
                    showLoading = true,
                    loadingMessage = context.getString(R.string.uploading),
                    apiCall = {
                        call
                    },
                    onSuccess = { response ->
                        val recordId = response.recordId

                        if (!recordId.isNullOrEmpty()) {
                            Log.d("uploadCallDetails", "upload done $recordId")
                            getUploadedCallDetails(context, recordId)
                        } else {
                            getErrorAlertDialog(
                                context,
                                "upload succeeded but no record id found"
                            )
                        }
                    },
                    onError = { error ->
                        Log.e("uploadstatuserror", "Upload failed: $error")
                        getErrorAlertDialog(context, "file not uploaded")
                        AppLogger.logAndToast(
                            context,
                            "EC048",
                            "DocumentActivity",
                            "uploadDocument",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                Log.e("uploadstatuserror", "Exception: ${e.message}")
                AppLogger.logAndToast(
                    context,
                    "EC048",
                    "DocumentActivity",
                    "uploadDocument",
                    e
                )
            }
        }
    }

    private fun getUploadedCallDetails(context: Context, recordId: String) {
        coroutineScope.launch {
            try {
                ApiRequestHandler.makeSuspendApiCall(
                    context = context,
                    showLoading = true,
                    loadingMessage = context.getString(R.string.fetching_data),
                    apiCall = {
                        ApiClient.apiService.getUploadedCallDetails(
                            OwnedLeadsActivity.bearerToken,
                            recordId
                        )
                    },
                    onSuccess = { response ->
                        callDetailsBottomSheet(context, response)
                    },
                    onError = { error ->
                        getErrorAlertDialog(context, "Failed to fetch call details")
                        AppLogger.logAndToast(
                            context,
                            "EC048",
                            "DocumentActivity",
                            "getUploadedCallDetails",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    context,
                    "EC048",
                    "DocumentActivity",
                    "getUploadedCallDetails",
                    e
                )
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun callDetailsBottomSheet(
        context: Context,
        data: LeadsModel.LeadsModelGetCallDetails.callrecord?
    ) {
        hideLoading()   //hide progress dialog after call ends

        val bottomSheetView =
            LayoutInflater.from(context).inflate(R.layout.dialog_callsummary, null)
        val binding = DialogCallsummaryBinding.bind(bottomSheetView)

        val dialog = BottomSheetDialog(context)
        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)
        dialog.show()

        binding.userName.text = "${data?.firstname} ${data?.lastname}"

        val inputFormat =
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.getDefault())
        inputFormat.timeZone = java.util.TimeZone.getTimeZone("UTC")

        val outputFormat =
            SimpleDateFormat("MMM dd yyyy • hh:mm a", java.util.Locale.getDefault())
        outputFormat.timeZone = java.util.TimeZone.getDefault()

        binding.rootLayout.setOnClickListener {
            val imm =
                contextActivity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val view = dialog.findViewById<View>(android.R.id.content)
            view?.let {
                imm.hideSoftInputFromWindow(it.windowToken, 0)
                it.clearFocus()
            }
        }

        binding.callDateTimeDuration.text =
            "${outputFormat.format(inputFormat.parse(data?.calldate))} • ${data?.callduration}"
        if (!data?.filename.isNullOrBlank() || data?.filename?.isNotEmpty() == true) {
            binding.callRecordingStatus.apply {
                binding.callRecordingStatus.compoundDrawablePadding = 10
                text = context.getString(R.string.recording_available)
                setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.green
                    )
                ) // Replace with your actual green color resource
                setCompoundDrawablesWithIntrinsicBounds(
                    R.drawable.ic_greentick,
                    0,
                    0,
                    0
                ) // Replace with your drawable
            }
        } else {
            binding.callRecordingStatus.apply {
                binding.callRecordingStatus.compoundDrawablePadding = 10
                text = context.getString(R.string.recording_unavailable)
                setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.red
                    )
                ) // Replace with your actual green color resource
                setCompoundDrawablesWithIntrinsicBounds(
                    R.drawable.ic_closered,
                    0,
                    0,
                    0
                ) // Replace with your drawable
            }
        }

        // Fetch and set Spinner values
        coroutineScope.launch {
            val leadStatusList = fetchLeadStatus(context)
            leadStatusList?.let { list ->
                val adapter = object : ArrayAdapter<LeadsModel.getLeadStatus.leadStatus>(
                    context,
                    R.layout.item_spinner_color,
                    list
                ) {
                    override fun getView(
                        position: Int,
                        convertView: View?,
                        parent: ViewGroup
                    ): View {
                        return createCustomView(position, convertView, parent)
                    }

                    override fun getDropDownView(
                        position: Int,
                        convertView: View?,
                        parent: ViewGroup
                    ): View {
                        return createCustomView(position, convertView, parent)
                    }

                    private fun createCustomView(
                        position: Int,
                        convertView: View?,
                        parent: ViewGroup
                    ): View {
                        val inflater = LayoutInflater.from(context)
                        val view = convertView ?: inflater.inflate(
                            R.layout.item_spinner_color,
                            parent,
                            false
                        )

                        val statusItem = getItem(position)
                        val colorIndicator = view.findViewById<View>(R.id.colorDot)
                        val statusName = view.findViewById<TextView>(R.id.spinnerViewName)

                        statusName.text = statusItem?.leadstatusname

                        // Parse and apply hex color to shape background
                        statusItem?.hexcolor?.let { hex ->
                            try {
                                val drawable =
                                    colorIndicator.background.mutate() as GradientDrawable
                                drawable.setColor(Color.parseColor(hex))
                            } catch (e: Exception) {
                                // Fallback to gray if invalid hex or casting fails
                                val drawable =
                                    colorIndicator.background.mutate() as? GradientDrawable
                                drawable?.setColor(Color.GRAY)
                            }
                        }
                        return view
                    }
                }

                binding.spinnerCallStatus.adapter = adapter

                // Set selected item based on existing status
                val selectedStatus = data?.leadstatusname
                val indexToSelect = list.indexOfFirst {
                    it.leadstatusname.equals(selectedStatus, ignoreCase = true)
                }
                if (indexToSelect >= 0) {
                    binding.spinnerCallStatus.setSelection(indexToSelect)
                }
            }
        }

        binding.save.setOnClickListener {
            dialog.dismiss()

            val selectedItem =
                binding.spinnerCallStatus.selectedItem as LeadsModel.getLeadStatus.leadStatus
            val statusName = selectedItem.leadstatusname
            val statusId = selectedItem.leadstatusid
            val followUpNotes = binding.followUpNotes.text.toString()

            coroutineScope.launch {
                var isStatusUpdated = false
                var isRemarkUpdated = false

                if (statusName != data?.leadstatusname) {
                    isStatusUpdated = updateLeadStatus(context, data?.leadid, statusId)
                    Log.d("isStatusUpdated", "$isStatusUpdated")
                }

                if (followUpNotes.isNotEmpty()) {
                    isRemarkUpdated = updateLeadRemark(context, data?.leadid, statusName)
                    Log.d("isRemarkUpdated", "$isRemarkUpdated")
                }

                if (isStatusUpdated) {
                    Log.d("inRefreshCondition", "yes")
                    (contextActivity as? OwnedLeadsActivity)?.refresh()
                }
            }
        }
    }

    private suspend fun updateLeadRemark(
        context: Context,
        leadid: Long?,
        statusName: String
    ): Boolean {
        return try {
            val requestBody = LeadsModel.updateLeadRemarkRequest(
                leadid,
                statusName
            )

            val call = ApiClient.apiService.updateLeadRemark(bearerToken, requestBody)

            ApiRequestHandler.makeSuspendApiCall(
                context = context,
                showLoading = true,
                loadingMessage = context.getString(R.string.uploading),
                apiCall = { call },
                onSuccess = { response ->
                    val result = response.body()
                    Log.d("updateLeadRemark", "$result")
                },
                onError = { error ->
                    Log.d("eeee", error)
                }
            )
            true
        } catch (e: Exception) {
            getErrorAlertDialog(context, e.toString())
            false
        }
    }

    private suspend fun updateLeadStatus(
        context: Context,
        leadId: Long?,
        statusId: Int
    ): Boolean {
        return try {
            val call = ApiClient.apiService.updateLeadStatus(bearerToken, leadId, statusId)

            ApiRequestHandler.makeSuspendApiCall(
                context = context,
                showLoading = true,
                loadingMessage = context.getString(R.string.uploading),
                apiCall = { call },
                onSuccess = { response ->
                    val result = response.body()
                    Log.d("updateLeadStatus", "$result")
                    getErrorAlertDialog(context, result?.message ?: "NA")
                },
                onError = { error ->
                    Log.d("eeee", error)
                }
            )
            true
        } catch (e: Exception) {
            getErrorAlertDialog(context, e.toString())
            false
        }
    }

    //===================== Get Call Details =================

    private fun findCallRecording(phoneNumber: String, callEndTime: Date): File? {
        val paths = listOf(
            "/storage/emulated/0/Call/",
            "/storage/emulated/0/Sounds/Call/",
            "/storage/emulated/0/Recordings/Call/",
            "/storage/emulated/0/Music/Recordings/Call Recordings",
            "/storage/emulated/0/MIUI/sound_recorder/call_rec",
            "/storage/emulated/0/Record/Call"
        )

        val timeWindow = 2 * 60 * 1000L // ±2 minutes
        val validExtensions = listOf(
            "amr",
            "awb",
            "3gp",
            "mp3",
            "m4a",
            "aac",
            "wav",
            "ogg",
            "opus",
            "mp4",
            "flac",
            "pcm",
            "caf",
            "aiff",
            "ts",
            "rm",
            "ds2"
        )

        for (path in paths) {
            val dir = File(path)
            if (dir.exists() && dir.isDirectory) {
                // Filter files by time and type first (looser condition)
                val candidateFiles = dir.listFiles { file ->
                    val isAudioFile =
                        validExtensions.any { file.name.endsWith(it, ignoreCase = true) }
                    val withinTimeWindow = kotlin.runCatching {
                        abs(file.lastModified() - callEndTime.time) <= timeWindow
                    }.getOrDefault(false)
                    isAudioFile && withinTimeWindow
                }

                // Try exact phone number match first
                val numberMatch = candidateFiles?.firstOrNull { it.name.contains(phoneNumber) }
                if (numberMatch != null) return numberMatch

                // If no match by number, fallback to most recent file within time window
                val fallback =
                    candidateFiles?.minByOrNull { abs(it.lastModified() - callEndTime.time) }
                if (fallback != null) return fallback
            }
        }

        return null
    }

    private fun getLatestCallLog(context: Context, phoneNumber: String): CallLogEntry? {
        val projection = arrayOf(
            CallLog.Calls.NUMBER,
            CallLog.Calls.TYPE,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION
        )

        val cursor = context.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            projection,
            "${CallLog.Calls.NUMBER} LIKE ?",
            arrayOf("%$phoneNumber%"),
            "${CallLog.Calls.DATE} DESC"
        )

        Log.d("CALL_LOG_DEBUG", "Start:$context - $phoneNumber")
        cursor?.use {
            if (it.moveToFirst()) {
                val number = it.getString(0)
                val type = it.getInt(1)
                val startDate = Date(it.getLong(2))
                val duration = it.getLong(3)
                val endDate = Date(startDate.time + duration * 1000)

                Log.d(
                    "CALL_LOG_DEBUG",
                    "Start: $startDate, End: $endDate, Duration: $duration sec"
                )

                return CallLogEntry(number, getCallType(type), endDate, duration)
            }
        }
        return null
    }

    data class CallLogEntry(
        val number: String,
        val type: String,
        val date: Date,
        val durationSeconds: Long
    )

    private fun getCallType(type: Int): String = when (type) {
        CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
        CallLog.Calls.INCOMING_TYPE -> "Incoming"
        CallLog.Calls.MISSED_TYPE -> "Missed"
        else -> "Unknown"
    }

    //===================== Get Lead Status and Update ===================

    private suspend fun fetchLeadStatus(context: Context): List<LeadsModel.getLeadStatus.leadStatus>? {
        return try {
            val call = ApiClient.apiService.getLeadStatus(bearerToken)
            Log.d("inStatuslead", call.toString())
            var result: List<LeadsModel.getLeadStatus.leadStatus>? = null

            ApiRequestHandler.makeSuspendApiCall(
                context = context,
                showLoading = true,
                loadingMessage = context.getString(R.string.fetching_data),
                apiCall = { call },
                onSuccess = { response ->
                    result = response.body()
                    Log.d("Statusleadresponce", "$result")
                },
                onError = { error ->
                    Log.d("eeee", error)
                }
            )
            result
        } catch (e: Exception) {
            Log.d("rrrrr", e.toString())
            null
        }
    }
}