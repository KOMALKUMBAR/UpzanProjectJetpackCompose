package com.harshal.upzyne.activity.settingMenu

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.adapter.UploadedDocumentAdapter
import com.harshal.upzyne.databinding.ActivityDocumentBinding
import com.harshal.upzyne.model.SettingModel.DocumentData
import com.harshal.upzyne.model.SettingModel.DocumentHrTypesResponse
import com.harshal.upzyne.utils.ProgressRequestBody
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody

class DocumentActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDocumentBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private var selectedFileUri: Uri? = null
    private var selectedDocumentTypeName: String = ""
    private var documentList: List<DocumentHrTypesResponse.DocumentType> = listOf()
    private val uploadedDocumentList = mutableListOf<DocumentData>()
    private lateinit var adapter: UploadedDocumentAdapter
    private lateinit var userFullName: String

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDocumentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        bearerToken = "Bearer " + (sharedPref.getString("auth_token", "") ?: "")
        userFullName = sharedPref.getString("user_fname", "").toString()
        binding.titleBar.text = "$userFullName - ${getString(R.string.documents)}"

        adapter = UploadedDocumentAdapter(uploadedDocumentList) { document ->
            val intent = Intent(this, DocumentPreviewActivity::class.java)
            intent.putExtra("document_url", document.documenturl)
            intent.putExtra("document_type", document.documenttypename)
            startActivity(intent)
        }

        binding.recyclerUploadedDocs.layoutManager = LinearLayoutManager(this)
        binding.recyclerUploadedDocs.adapter = adapter

        binding.imgArrowBack.setOnClickListener { finish() }

        fetchDocumentTypes()
        fetchUploadedDocuments()
        setupSpinnerListener()

        binding.btnBrowseFile.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "*/*"
            startActivityForResult(intent, 1001)
        }

        binding.btnSave.setOnClickListener {
            val position = binding.selectDocumentListview.selectedItemPosition
            if (position <= 0) {
                Toast.makeText(this, getString(R.string.please_select_a_document_type), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (selectedFileUri == null) {
                Toast.makeText(this, getString(R.string.please_select_a_file_to_upload), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val documentTypeId = documentList[position - 1].documenttypeid

            // Show upload progress UI
            /*    binding.txtUploadStatus.text = getString(R.string.Uploadin_Data)
                binding.progressUpload.progress = 0
                binding.progressCardView.visibility = View.gone*/


            uploadDocument(documentTypeId)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                selectedFileUri = uri
                val fileName = getFileName(uri)
                binding.tvSelectedFileName.text = "Selected: $fileName"
                binding.btnSave.setBackgroundResource(R.drawable.shape_color_btn)
                binding.btnSave.setTextColor(getColor(R.color.white))
            }
        }
    }

    private fun fetchDocumentTypes() {
        lifecycleScope.launch {
            val call = ApiClient.apiService.getDocumentHrTypes(bearerToken)
            ApiRequestHandler.makeSuspendApiCall(
                context = this@DocumentActivity,
                showLoading = true,
                loadingMessage = getString(R.string.fetching_data),
                apiCall = { call },
                onSuccess = { response ->
                    documentList = response.data.filter { it.isactive }
                    val names = listOf(getString(R.string.Select_document)) + documentList.map { it.documenttypename }
                    val spinnerAdapter = ArrayAdapter(this@DocumentActivity, android.R.layout.simple_spinner_item, names)
                    spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    binding.selectDocumentListview.adapter = spinnerAdapter
                },
                onError = { error ->
                    AppLogger.logAndToast(this@DocumentActivity, "EC047", "DocumentActivity", "fetchDocumentTypes", Exception(error))
                }
            )
        }
    }

    private fun setupSpinnerListener() {
        binding.selectDocumentListview.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedDocumentTypeName = if (position > 0) documentList[position - 1].documenttypename else ""
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedDocumentTypeName = ""
            }
        }
    }

    private fun uploadDocument(documentTypeId: Int) {
        lifecycleScope.launch {
            val dialogView = layoutInflater.inflate(R.layout.dialog_upload_progress, null)
            val dialogBuilder = AlertDialog.Builder(this@DocumentActivity).setView(dialogView).setCancelable(false)
            val dialog = dialogBuilder.create()

            val txtUploadStatus = dialogView.findViewById<TextView>(R.id.txtUploadStatus)
            val progressUpload = dialogView.findViewById<ProgressBar>(R.id.progressUpload)

            try {
                dialog.show()

                val inputStream = contentResolver.openInputStream(selectedFileUri!!)
                val fileBytes = inputStream?.readBytes() ?: throw Exception("File read error")
                val fileName = getFileName(selectedFileUri!!)

                val fileBody = ProgressRequestBody(fileBytes, "application/octet-stream") { progress ->
                    runOnUiThread {
                        progressUpload.progress = progress
                        val displayName = if (selectedDocumentTypeName.isNotEmpty()) selectedDocumentTypeName else "Document"
                        txtUploadStatus.text = "$displayName uploading... $progress%"
                    }
                }

                val multipartFile = MultipartBody.Part.createFormData("file", fileName, fileBody)
                val typeBody = documentTypeId.toString().toRequestBody("text/plain".toMediaTypeOrNull())
                val remarksBody = "uploaded via app".toRequestBody("text/plain".toMediaTypeOrNull())

                val call = ApiClient.apiService.uploadDocument(bearerToken, multipartFile, typeBody, remarksBody)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@DocumentActivity,
                    showLoading = false,
                    loadingMessage = getString(R.string.loading),
                    apiCall = { call },
                    onSuccess = {
                        selectedFileUri = null
                        binding.tvSelectedFileName.text = getString(R.string.no_file_selected)
                        binding.btnSave.setBackgroundResource(R.drawable.shape_blank_btn)
                        binding.btnSave.setTextColor(getColor(R.color.black))
                        dialog.dismiss()
                        fetchUploadedDocuments()
                    },
                    onError = { error ->
                        dialog.dismiss()
                        AppLogger.logAndToast(this@DocumentActivity, "EC050", "DocumentActivity", "uploadDocument", Exception(error))
                    }
                )
            } catch (e: Exception) {
                dialog.dismiss()
                AppLogger.logAndToast(this@DocumentActivity, "EC048", "DocumentActivity", "uploadDocument", e)
            }
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = "file"
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst()) {
                name = it.getString(index)
            }
        }
        return name
    }

    private fun fetchUploadedDocuments() {
        lifecycleScope.launch {
            val call = ApiClient.apiService.getUploadedDocuments(bearerToken)
            ApiRequestHandler.makeSuspendApiCall(
                context = this@DocumentActivity,
                showLoading = false,
                loadingMessage = "",
                apiCall = { call },
                onSuccess = { response ->
                    val list = response.data
                    uploadedDocumentList.clear()
                    uploadedDocumentList.addAll(list.reversed())
                    adapter.notifyDataSetChanged()

                    binding.recyclerUploadedDocs.visibility = if (list.isNotEmpty()) View.VISIBLE else View.GONE
                    binding.recyclerUploadedDocs.scrollToPosition(0)
                },
                onError = {
                    Toast.makeText(this@DocumentActivity, getString(R.string.Failed_to_load_uploaded_documents), Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}