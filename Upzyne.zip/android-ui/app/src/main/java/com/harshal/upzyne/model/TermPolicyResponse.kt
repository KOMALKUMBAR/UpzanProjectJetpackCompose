package com.harshal.upzyne.model

data class TermPolicyResponse(
    val data: TermPolicyData
)

data class TermPolicyData(
    val title: String,
    val description: String,
    val lastupdated: String
)
