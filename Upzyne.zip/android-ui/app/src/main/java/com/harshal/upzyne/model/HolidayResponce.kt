package com.harshal.upzyne.model

data class HolidayResponce(val data: List<HolidayData>)

data class HolidayData(val weekday: String,
                       val holidaydate: String,
                       val holidayname: String)