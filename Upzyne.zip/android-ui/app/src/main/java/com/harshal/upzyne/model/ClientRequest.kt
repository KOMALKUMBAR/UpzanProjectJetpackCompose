package com.harshal.upzyne.model

data class ClientRequest(
    val clientId: String
)