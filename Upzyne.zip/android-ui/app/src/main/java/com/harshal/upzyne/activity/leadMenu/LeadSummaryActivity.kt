package com.harshal.upzyne.activity.leadMenu

import android.R.attr.data
import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayoutMediator
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.adapter.leadSummaryAdapter.ViewPagerAdapter
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityLeadSummaryBinding
import com.harshal.upzyne.databinding.ItemLeadSummaryProfileItemBinding
import com.harshal.upzyne.model.LeadsModel
import kotlinx.coroutines.launch

class LeadSummaryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLeadSummaryBinding
    private lateinit var profileBinding: ItemLeadSummaryProfileItemBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private lateinit var userFullName: String
    private val tabTitles = arrayOf("summary", "communication", "timeline", "notes")
    private val tabIcons = arrayOf(R.drawable.summary, R.drawable.communication, R.drawable.ic_timeline, R.drawable.notes)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLeadSummaryBinding.inflate(layoutInflater)    // <-- assign to field
        setContentView(binding.root)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "").toString()
        val token = sharedPref.getString("auth_token", "") ?: ""
        bearerToken = "Bearer $token"


        // Set title with user's name
        binding.titleText.text = "$userFullName - ${getString(R.string.lead_summary)}"
        binding.imgArrow.setOnClickListener { finish() }


        // inflate profile item and add to container (same as your code)
        profileBinding = ItemLeadSummaryProfileItemBinding.inflate(LayoutInflater.from(this), binding.leadContainer, false)
        binding.leadContainer.addView(profileBinding.root)

        setThemeBackground(this, binding.lay)
        setThemeBackground(this, binding.lltabLayout)
        setThemeBackground(this, binding.leadContainer)

        val leadId = intent.getIntExtra("lead_id", -1)
        val leadName = intent.getStringExtra("lead_name") ?: ""
        val leadEmail = intent.getStringExtra("lead_email") ?: ""
        val leadPhone = intent.getStringExtra("lead_phone") ?: ""
        val leadTimeAgo = intent.getStringExtra("lead_timeago") ?: ""
        val leadLeadDate = intent.getStringExtra("lead_leaddate") ?: ""
        val leadProgramme = intent.getStringExtra("lead_programme") ?: ""
        val leadSourceBadge = intent.getStringExtra("lead_sourcebadge") ?: ""
        val leadSource = intent.getStringExtra("lead_source") ?: ""
        val leadScore = intent.getStringExtra("lead_score") ?: "0"
        val leadStatusColor = intent.getStringExtra("lead_statuscolor") ?: "#3E4A59"
        val leadVerified = intent.getBooleanExtra("lead_verified", false)
        profileBinding.statusIcon.text = intent.getStringExtra("lead_sourcebadge")
        profileBinding.tvOtpVerification.visibility = if (leadVerified) View.VISIBLE else View.GONE
        // Apply dynamic color to lead label
        val labelDrawable = profileBinding.labelNewLead.background?.mutate()
        val colorWithAlpha = (leadStatusColor.toColorInt() and 0x00FFFFFF) or (0x30 shl 24)
        labelDrawable?.setColorFilter(colorWithAlpha, PorterDuff.Mode.SRC_ATOP)
        profileBinding.labelNewLead.background = labelDrawable
        profileBinding.labelNewLead.setTextColor(leadStatusColor.toColorInt())
        profileBinding.labelNewLead.text = intent.getStringExtra("lead_source") ?: ""
        // Set color to left border background

        val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.left_glass)
        if (backgroundDrawable is LayerDrawable) {
            val leftBorder = backgroundDrawable.findDrawableByLayerId(R.id.left_border)
            if (leftBorder is GradientDrawable) {
                leftBorder.setColor(leadStatusColor.toColorInt())
            }
            profileBinding.itemLead.background = backgroundDrawable
        }
        profileBinding.userName.text = leadName
        profileBinding.userEmail.text = leadEmail
        profileBinding.userPhone.text = leadPhone
        profileBinding.course.text = leadProgramme
        profileBinding.labelNewLead.text = leadSource
        profileBinding.statusIcon.text = leadSourceBadge
        profileBinding.tvOtpVerification.visibility = if (leadVerified) View.VISIBLE else View.GONE
        binding.leadStatus2.text = "$leadScore%"

        // fetch the lead summary then set up the ViewPager/Fragments with the returned data
        fetchLeadSummary(leadId)

        // leadInformation click (keeps behavior)
        binding.leadInformation.setOnClickListener {
            val intent = Intent(this, LeadInformationActivity::class.java)
            intent.putExtra("lead_id", leadId)
            startActivity(intent)
        }

    }

    private fun fetchLeadSummary(leadId: Int) {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getLeadSummary(bearerToken, leadId)
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@LeadSummaryActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val data: LeadsModel.LeadSummaryData? = response.body()?.data
                        if (data != null) {
                            populateTopProfile(data)
                            setupViewPagerWithData(data)
                        } else {
                            Log.w("LeadSummary", "No data returned")
                        }
                    },
                    onError = { error ->
                        Log.e("LeadSummary", error)
                        UtilsMethods.AppLogger.logAndToast(
                            this@LeadSummaryActivity,
                            "EC999",
                            "LeadSummaryActivity",
                            "fetchLeadSummary",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                Log.e("LeadSummary", e.message.toString())
                UtilsMethods.AppLogger.logAndToast(
                    this@LeadSummaryActivity,
                    "EC999",
                    "LeadSummaryActivity",
                    "fetchLeadSummary",
                    e
                )
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun populateTopProfile(data: LeadsModel.LeadSummaryData) {
        val phoneNumber = data.lead_info?.phone ?: ""
        val leadName = data.lead_info?.name ?: "-"
        // adapt these IDs to the ones in your item_lead_profile layout
        profileBinding.userName.text = leadName
        profileBinding.userEmail.text = data.lead_info?.email ?: "-"
        profileBinding.userPhone.text = phoneNumber
        profileBinding.course.text = data.lead_info?.product ?: "-"
        profileBinding.labelNewLead.text = data.lead_info?.status?:""
        profileBinding.joinedDate.text = "joined_on: ${data.lead_info?.joined_on ?: ""}"
        profileBinding.engagedDate.text ="engaged:${ data.lead_info?.engaged_hrs?:0.0.toInt()}"
        binding.leadStatus2.text = "${(data.response?.percentage ?: 0.0).toInt()}%"
        binding.totalInteractionsText.text = (data.response?.total_interactions ?: 0).toString()

        setupClickActions(phoneNumber, leadName )

    }
    private fun saveContactAndCall(phoneNumber: String, leadName: String) {
        val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            putExtra(ContactsContract.Intents.Insert.NAME, leadName)
            putExtra(ContactsContract.Intents.Insert.PHONE, phoneNumber)
        }
        startActivity(intent)

        // After saving, open dialer
        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
        startActivity(dialIntent)
    }
    private fun setupClickActions(phoneNumber: String, leadName: String) {

        // WhatsApp Click
        profileBinding.iconWhatsapp.setOnClickListener {
            if (phoneNumber.isNotEmpty()) {
                openWhatsApp(phoneNumber)
            } else {
                Toast.makeText(this, "No phone number available", Toast.LENGTH_SHORT).show()
            }
        }

        // save Call Click
        profileBinding.iconCallSave.setOnClickListener {
            if (phoneNumber.isNotEmpty()) {
                saveContactAndCall(phoneNumber, leadName)
            } else {
                Toast.makeText(this, "No phone number available", Toast.LENGTH_SHORT).show()
            }
        }
        profileBinding.iconCall.setOnClickListener {
            if (phoneNumber.isNotEmpty()) {
                saveContactAndCall(phoneNumber, leadName)
            } else {
                Toast.makeText(this, "No phone number available", Toast.LENGTH_SHORT).show()
            }
        }

        // Message Click
        profileBinding.iconMessage.setOnClickListener {
            if (phoneNumber.isNotEmpty()) {
                val smsIntent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("sms:$phoneNumber")
                }
                startActivity(smsIntent)
            } else {
                Toast.makeText(this, "No phone number available", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun openWhatsApp(phoneNumber: String) {
        try {
            val packageManager = packageManager
            val businessInstalled = isPackageInstalled("com.whatsapp.w4b", packageManager)
            val normalInstalled = isPackageInstalled("com.whatsapp", packageManager)

            when {
                businessInstalled -> {
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.data = Uri.parse("https://wa.me/$phoneNumber")
                    intent.setPackage("com.whatsapp.w4b")
                    startActivity(intent)
                }
                normalInstalled -> {
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.data = Uri.parse("https://wa.me/$phoneNumber")
                    intent.setPackage("com.whatsapp")
                    startActivity(intent)
                }
                else -> {
                    Toast.makeText(this, "WhatsApp not installed", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error opening WhatsApp", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isPackageInstalled(packageName: String, packageManager: android.content.pm.PackageManager): Boolean {
        return try {
            packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: android.content.pm.PackageManager.NameNotFoundException) {
            false
        }
    }
    private fun setupViewPagerWithData(data: LeadsModel.LeadSummaryData) {
        var leadId = intent.getIntExtra("lead_id", -1)
        if (leadId == -1) {
            leadId = data.lead_info?.leadId ?: -1
        }
        val leadName = data.lead_info?.name ?: "-"// still reading from intent
        val adapter = ViewPagerAdapter(this, data, leadId,leadName)
        binding.viewPager.adapter = adapter
        binding.viewPager.offscreenPageLimit = 3
        // attach tab layout (only now after adapter is set)
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.setIcon(tabIcons[position])
            tab.text = tabTitles[position]
        }.attach()
    }
}



