package com.harshal.upzyne.adapter.leadSummaryAdapter

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R


class EmailToLeadAdpter(private val files: List<Uri>) : RecyclerView.Adapter<EmailToLeadAdpter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fileName: TextView = itemView.findViewById(R.id.fileNameText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_email_lead_document_attachment, parent, false)
        return ViewHolder(view)
    }


    override fun getItemCount(): Int = files.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val uri = files[position]
        val fileName = getFileNameFromUri(holder.itemView.context, uri)
        holder.fileName.text = fileName
    }

    private fun getFileNameFromUri(context: Context, uri: Uri): String {
        var name = "Unknown"
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    name = it.getString(idx)
                }
            }
        }
        return name
    }
}
