// TimelineFragment.kt
package com.harshal.upzyne.fragment.leadfragment

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.FragmentTimelineBinding
import com.harshal.upzyne.model.LeadsModel
import com.harshal.upzyne.adapter.leadSummaryAdapter.TimelineAdapter
import kotlinx.coroutines.launch

class TimelineFragment : Fragment() {

    // View binding for accessing layout elements
    private var _binding: FragmentTimelineBinding? = null
    private val binding get() = _binding!!

    // RecyclerView adapter for showing timeline data
    private lateinit var adapter: TimelineAdapter

    // Lead ID passed from previous screen (needed for API call)
    private var leadId: Int = 0

    // Stores the full timeline list for filtering
    private var allTimeline: List<LeadsModel.TimelineItem> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTimelineBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /**
         * STEP 1: Retrieve lead data passed via arguments.
         * We get the 'lead_id' for API call, and lead summary if needed.
         */
        val summaryData = arguments?.getSerializable("lead_summary_data") as? LeadsModel.LeadSummaryData
        leadId = arguments?.getInt("lead_id") ?: 0

        /**
         * STEP 2: Initialize RecyclerView with empty list.
         * Later, data will be updated after API fetch.
         */
        adapter = TimelineAdapter(requireContext(),leadId = leadId, items = mutableListOf())
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        /**
         * STEP 3: Set click listeners for filter tabs (All, Messages, Calls, Contacts).
         * When clicked, the list is filtered and active tab UI is highlighted.
         */
        binding.tvAll.setOnClickListener {
            adapter.updateList(allTimeline)
            setActiveTab(binding.tvAll)
        }

        binding.tvMessages.setOnClickListener {
            adapter.updateList(allTimeline.filter { it.type.equals("message", true) })
            setActiveTab(binding.tvMessages)
        }

        binding.tvCalls.setOnClickListener {
            adapter.updateList(allTimeline.filter {
                it.type.contains("call", true) || it.type.equals("call", true)
            })
            setActiveTab(binding.tvCalls)
        }

        binding.tvContacts.setOnClickListener {
            adapter.updateList(allTimeline.filter { it.type.contains("contact", true) })
            setActiveTab(binding.tvContacts)
        }

        /**
         * STEP 4: If no valid leadId is found, stop the process.
         */
        if (leadId == 0) {
            Toast.makeText(requireContext(), "leadId not found. pass leadId via bundle.", Toast.LENGTH_LONG).show()
            return
        }

        /**
         * STEP 5: Fetch timeline data from API.
         */
        fetchTimeline()
    }

    /**
     * Fetch timeline data for the given leadId from server.
     * Displays loading spinner while fetching.
     */
    private fun fetchTimeline() {
        binding.progressBar.visibility = View.VISIBLE
        binding.emptyText.visibility = View.GONE

        val token = requireActivity().getSharedPreferences("app_prefs", Context.MODE_PRIVATE).getString("auth_token", "") ?: ""

        lifecycleScope.launch {
            try {
                val response = ApiClient.apiService.getTimeline("Bearer $token", leadId)
                binding.progressBar.visibility = View.GONE

                if (response.isSuccessful) {
                    allTimeline = response.body()?.data ?: emptyList()

                    // If no data, show empty state
                    if (allTimeline.isEmpty()) {
                        binding.emptyText.visibility = View.VISIBLE
                        adapter.updateList(emptyList())
                    } else {
                        binding.emptyText.visibility = View.GONE
                        adapter.updateList(allTimeline)
                    }
                } else {
                    // API returned error code
                    binding.emptyText.visibility = View.VISIBLE
                    Toast.makeText(requireContext(), "Server error: ${response.code()}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                // Network or parsing error
                binding.progressBar.visibility = View.GONE
                binding.emptyText.visibility = View.VISIBLE
                Toast.makeText(requireContext(), "Network error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Highlights the active tab and resets styles for inactive ones.
     */
    private fun setActiveTab(activeTab: View) {
        val defaultBg = R.drawable.white_rectangle_roundcr
        val defaultTextColor = requireContext().getColor(R.color.black)
        val activeTextColor = requireContext().getColor(R.color.white)
        val activeTint = requireContext().getColor(R.color.orange)

        // Reset all tabs to default
        listOf(binding.tvAll, binding.tvMessages, binding.tvCalls, binding.tvContacts).forEach { tab ->
            tab.backgroundTintList = null
            tab.setBackgroundResource(defaultBg)
            tab.setTextColor(defaultTextColor)
        }

        // Set active style for selected tab
        activeTab.backgroundTintList = android.content.res.ColorStateList.valueOf(activeTint)
        (activeTab as? android.widget.TextView)?.setTextColor(activeTextColor)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
