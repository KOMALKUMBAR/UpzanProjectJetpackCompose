package com.harshal.upzyne.activity.hrmsMenu

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.applyInsetPadding
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ActivitySalaryslipBinding
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.util.Log
import android.widget.Toast
import com.harshal.upzyne.model.CompanyDetails
import com.harshal.upzyne.model.SettingModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.math.max

import android.graphics.Canvas
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.model.SalarySlipResponseData
import java.net.HttpURLConnection
import java.net.URL

class SalarySlipActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySalaryslipBinding
    private lateinit var sharedPref: SharedPreferences
    lateinit var userFullName: String
    lateinit var bearerToken: String
    lateinit var baseUrl: String
    private lateinit var salaryDetails: SalarySlipResponseData
    private lateinit var companyDetails: CompanyDetails
    private lateinit var bankDetails: SettingModel.BankDetails

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySalaryslipBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        baseUrl = sharedPref.getString("base_url", "").toString()
        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.salary_slip)
        binding.titleBar.text = "$userFullName - $activityName"

        bearerToken = "Bearer ${sharedPref.getString("auth_token", "")}"

        applyInsetPadding(this, binding.rootLayout)
        setThemeBackground(this, binding.tvCounsNameCard)
        setThemeBackground(this, binding.layTotalAttendance)
        setThemeBackground(this, binding.laySalaryDetails)

        binding.imgArrow.setOnClickListener {
            finish()
        }

        binding.btnDownloadSlip.setOnClickListener {
            lifecycleScope.launch {
                try {
                    createSalarySlipPdf(this@SalarySlipActivity)
                } catch (e: Exception) {
                    Log.e("salarySlip", e.message.toString())
                }
            }
        }

        val getMonth = intent.getIntExtra("salaryMonth", 0)
        val getYear = intent.getIntExtra("salaryYear", 0)

        getSalarySlip(getMonth, getYear)
        fetchBankDetails()
        fetchCompanyDetails()
    }

    suspend fun createSalarySlipPdf(context: Context) {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 size
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        val typeface = ResourcesCompat.getFont(context, R.font.avenirnext_regular)
        val paint = TextPaint()
        paint.typeface = typeface
        paint.textAlign = Paint.Align.CENTER

        var y = 40f
        val leftMargin1 = 50f
        val lineSpacing = 25f
        val titleSpacing = 50f

        // Title with black background
        val headerHeight = 50f
        paint.color = Color.BLACK
        canvas.drawRect(0f, y - 30f, pageInfo.pageWidth.toFloat(), y - 30f + headerHeight, paint)

        paint.color = Color.WHITE
        paint.textSize = 22f
        paint.isFakeBoldText = true
        val title = companyDetails.name
        val textWidth = paint.measureText(title)
        val centerX = (pageInfo.pageWidth - textWidth) / 2f
        canvas.drawText(title, centerX, y, paint)
        y += lineSpacing

        // Company logo & address
        y = drawCompanyDetailsWithLogo(
            canvas,
            paint,
            context,
            baseUrl,
            companyDetails,
            leftMargin1,
            y + 10f,
            lineSpacing
        )

        // Subtitle: Salary Slip
        // Set center alignment
        paint.textAlign = Paint.Align.CENTER

        // Calculate center X
        val centerX1 = canvas.width / 2f

        // Title: "Salary Slip"
        paint.textSize = 18f
        paint.isFakeBoldText = true
        paint.isUnderlineText = true
        canvas.drawText("Salary Slip", centerX1, y, paint)

        // Subtitle: "Pay Slip for Month: ..."
        y += 20f // reduced spacing between title and subtitle
        paint.textSize = 14f
        paint.isFakeBoldText = false
        paint.isUnderlineText = true
        canvas.drawText("Pay Slip for Month- ${salaryDetails.data.paid_on.substringAfter(" ").trim()}", centerX1, y, paint)

        // Reset align if needed later
        paint.textAlign = Paint.Align.LEFT
        y += 20f // spacing after subtitle for next section

        // Employee Details (2-column layout)
        paint.isUnderlineText = false
        paint.textSize = 12f
        paint.isFakeBoldText = false
        paint.style = Paint.Style.FILL
        paint.color = Color.BLACK

        val empDetails: List<Pair<String, String>> = listOf(
            "Emp ID:" to salaryDetails.data.empno.toString(),
            "Designation:" to salaryDetails.data.designation.toString(),
            "Emp Name:" to salaryDetails.data.employeename.toString(),
            "Department:" to salaryDetails.data.department.toString(),
            "Bank:" to bankDetails.bankname.toString(),
            "Total Work Days:" to salaryDetails.data.totalworkdays.toString(),
            "Bank Acc No:" to bankDetails.accountnumber.toString(),
            "Attendance:" to salaryDetails.data.attendancedays.toString(),
            "PAN No:" to salaryDetails.data.pancard.toString(),
            "Month/Year:" to salaryDetails.data.paid_on.substringAfter(" ").trim()
        )

        val rowHeight = lineSpacing
        val cellPadding = 6f

        val tableWidth1 = 540f
        val pageWidth2 = 595f
        val leftMargin2 = (pageWidth2 - tableWidth1) / 2f

        // Define 4 column widths for a 2-pair row: label1, value1, label2, value2
        val colWidths1 = listOf(120f, 150f, 120f, 150f)
        val colStarts1 = listOf(
            leftMargin2,
            leftMargin2 + colWidths1[0],
            leftMargin2 + colWidths1[0] + colWidths1[1],
            leftMargin2 + colWidths1[0] + colWidths1[1] + colWidths1[2]
        )

        val col1LabelX = colStarts1[0]
        val col1ValueX = colStarts1[1]
        val col2LabelX = colStarts1[2]
        val col2ValueX = colStarts1[3]

        val borderPaint1 = Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 1f
            color = Color.LTGRAY
            isAntiAlias = true
        }

        var tableY = y
        val rows = empDetails.chunked(2) // each row will have 2 key-value pairs (4 cells)

        for (row in rows) {
            val (label1, value1) = row[0]

            // Draw 1st column label and value
            canvas.drawRect(col1LabelX, tableY, col1LabelX + colWidths1[0], tableY + rowHeight, borderPaint1)
            canvas.drawRect(col1ValueX, tableY, col1ValueX + colWidths1[1], tableY + rowHeight, borderPaint1)
            canvas.drawText(label1, col1LabelX + cellPadding, tableY + rowHeight - 6f, paint)
            canvas.drawText(value1, col1ValueX + cellPadding, tableY + rowHeight - 6f, paint)

            // Draw 2nd column label and value if exists
            if (row.size > 1) {
                val (label2, value2) = row[1]
                canvas.drawRect(col2LabelX, tableY, col2LabelX + colWidths1[2], tableY + rowHeight, borderPaint1)
                canvas.drawRect(col2ValueX, tableY, col2ValueX + colWidths1[3], tableY + rowHeight, borderPaint1)
                canvas.drawText(label2, col2LabelX + cellPadding, tableY + rowHeight - 6f, paint)
                canvas.drawText(value2, col2ValueX + cellPadding, tableY + rowHeight - 6f, paint)
            }
            tableY += rowHeight
        }

        y = tableY + 10f // Update y for next drawing section

        // Salary Breakdown Header
        val rowHeight1 = lineSpacing
        val tableWidth = 540f // Fits within A4 width
        val pageWidth = 595f
        val leftMargin = (pageWidth - tableWidth) / 2f
        val colWidths = listOf(180f, 90f, 150f, 90f)
        val colStarts = listOf(
            leftMargin,
            leftMargin + colWidths[0],
            leftMargin + colWidths[0] + colWidths[1],
            leftMargin + colWidths[0] + colWidths[1] + colWidths[2]
        )
        val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 1f
            color = Color.LTGRAY
        }

        // Header row with black background
        paint.color = Color.BLACK
        canvas.drawRect(leftMargin, y, leftMargin + tableWidth, y + rowHeight1, paint)

        paint.color = Color.WHITE
        paint.isFakeBoldText = true
        val textY1 = y + rowHeight1 * 0.75f
        canvas.drawText("Emoluments", colStarts[0] + 5f, textY1, paint)
        canvas.drawText("Amount (Rs.)", colStarts[1] + 5f, textY1, paint)
        canvas.drawText("Deductions", colStarts[2] + 5f, textY1, paint)
        canvas.drawText("Amount (Rs.)", colStarts[3] + 5f, textY1, paint)
        y += rowHeight1

        // Salary rows
        paint.color = Color.BLACK
        paint.isFakeBoldText = false
        val earnings = listOf(
            "Basic Pay" to salaryDetails.data.basicpay,
            "House Rent Allowance" to salaryDetails.data.house_rent_allowance,
            "Transport Allowance" to salaryDetails.data.transport_allowance,
            "Medical Allowance" to salaryDetails.data.medical_allowance,
            "Leave Travel Allowance" to salaryDetails.data.leave_travel_allowance,
            "Incentive" to salaryDetails.data.incentive,
            "Gross Pay" to salaryDetails.data.gross_salary
        )
        val deductions = listOf(
            "Profession Tax" to salaryDetails.data.professional_tax,
            "Income Tax" to salaryDetails.data.income_tax
        )
        val maxRows = max(earnings.size, deductions.size)

        // Draw earning and deduction rows
        for (i in 0 until maxRows) {
            val rowTop = y
            val rowBottom = y + rowHeight1

            // Draw border cells
            for (j in 0..3) {
                val left = colStarts[j]
                val right = if (j == 3) leftMargin + tableWidth else colStarts[j + 1]
                canvas.drawRect(left, rowTop, right, rowBottom, borderPaint)
            }

            earnings.getOrNull(i)?.let { (label, amount) ->
                // Left-aligned label
                paint.textAlign = Paint.Align.LEFT
                canvas.drawText(label, colStarts[0] + 5f, rowBottom - 6f, paint)

                // Right-aligned value
                paint.textAlign = Paint.Align.RIGHT
                canvas.drawText(amount.toString(), colStarts[1] + colWidths[1] - 5f, rowBottom - 6f, paint)
            }

            deductions.getOrNull(i)?.let { (label, amount) ->
                // Left-aligned label
                paint.textAlign = Paint.Align.LEFT
                canvas.drawText(label, colStarts[2] + 5f, rowBottom - 6f, paint)

                // Right-aligned value
                paint.textAlign = Paint.Align.RIGHT
                canvas.drawText(amount.toString(), colStarts[3] + colWidths[3] - 5f, rowBottom - 6f, paint)
            }

            // Reset text alignment for safety
            paint.textAlign = Paint.Align.LEFT

            y += rowHeight1
        }

        // Total Deductions (full-width right aligned)
        val totalText = "Total Deductions: ${salaryDetails.data.total_deductions}"
        val totalY = y + rowHeight1 * 0.75f
        canvas.drawRect(leftMargin, y, leftMargin + tableWidth, y + rowHeight1, borderPaint)
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText(totalText, leftMargin + tableWidth - 10f, totalY, paint)
        y += rowHeight1

        // Net Pay (full-width right aligned)
        val netPayText = "Net Pay: ${salaryDetails.data.net_salary}"
        canvas.drawRect(leftMargin, y, leftMargin + tableWidth, y + rowHeight1, borderPaint)
        canvas.drawText(netPayText, leftMargin + tableWidth - 10f, y + rowHeight1 * 0.75f, paint)
        paint.textAlign = Paint.Align.LEFT // Reset for future use
        y += rowHeight1 + 10f

        y += 20f
        paint.textSize = 12f
        paint.isFakeBoldText = false

        val noteText = "Note: This is an electronically generated statement hence does not require any signature."
        val textWidth1 = paint.measureText(noteText)
        val pageWidth1 = 595f // A4 page width in points
        val centerX2 = (pageWidth1 - textWidth1) / 2f

        canvas.drawText(noteText, centerX2, y, paint)

        pdfDocument.finishPage(page)

        val baseDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        val targetDir = File(baseDir, "Upzyne/Salaryslip")
        if (!targetDir.exists()) {
            targetDir.mkdirs() // Create folder if it doesn't exist
        }
        //val fileName = "${salaryDetails.data.employeename}_${salaryDetails.data.paid_on}.pdf"
        val fileName = "${salaryDetails.data.paid_on}.pdf"
        val file = File(targetDir, fileName)

        if (file.exists()) {
            if (file.isDirectory) {
                file.deleteRecursively() // delete directory with same name
            } else {
                file.delete() // remove existing file
            }
        }

        try {
            pdfDocument.writeTo(FileOutputStream(file))
            Toast.makeText(context, "PDF saved to ${file.absolutePath}", Toast.LENGTH_LONG).show()
        } catch (e: IOException) {
            Log.e("salarySlip", "Failed to save PDF: ${e.message}")
            Toast.makeText(context, "Failed to save PDF: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            pdfDocument.close()
        }
    }

    // Suspend function to load bitmap from URL
    suspend fun loadBitmapFromUrl(url: String): Bitmap? {
        return withContext(Dispatchers.IO) {
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.doInput = true
                connection.connect()
                val input = connection.inputStream
                BitmapFactory.decodeStream(input)
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

    suspend fun drawCompanyDetailsWithLogo(
        canvas: Canvas,
        paint: TextPaint,
        context: Context,
        baseUrl: String,
        companyDetails: CompanyDetails,
        leftMargin: Float,
        y: Float,
        lineSpacing: Float
    ): Float {
        var currentY = y
        paint.color = Color.BLACK
        paint.textSize = 12f
        paint.isFakeBoldText = false

        val logoUrl = baseUrl + companyDetails.logourl
        val logoBitmap = loadBitmapFromUrl(logoUrl)

        val logoWidth = 150f
        val logoHeight = 150f
        val logoTop = currentY
        val logoLeft = leftMargin

        val addressLines = listOf(companyDetails.address1, companyDetails.address2, companyDetails.postalcode)

        // Calculate total height of the address block
        val addressBlockHeight = addressLines.size * lineSpacing

        // Vertically center the address block within the logo height
        val textStartY = currentY + (logoHeight - addressBlockHeight) / 2f

        // Set paint to draw text aligned to the right
        paint.textAlign = Paint.Align.RIGHT
        val rightMargin = canvas.width.toFloat() - leftMargin

        // Draw logo on the left
        if (logoBitmap != null) {
            val scaledBitmap = Bitmap.createScaledBitmap(logoBitmap, logoWidth.toInt(), logoHeight.toInt(), false)
            canvas.drawBitmap(scaledBitmap, logoLeft, logoTop, null)
        } else {
            canvas.drawText("Logo not found", logoLeft, currentY + 20f, paint)
        }

        // Draw each address line on the right, vertically centered with logo
        var textY = textStartY
        for (line in addressLines) {
            canvas.drawText(line, rightMargin, textY, paint)
            textY += lineSpacing
        }

        // Reset alignment back to left (optional for future drawing)
        paint.textAlign = Paint.Align.LEFT

        // Return height for continued drawing
        return maxOf(currentY + logoHeight, textY) + 10f
    }

    private fun getSalarySlip(month: Int, year: Int) {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getSalarySlip(
                    bearerToken,
                    month, year
                )

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@SalarySlipActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        salaryDetails = response
                        updateUI(salaryDetails.data)
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@SalarySlipActivity,
                            "EC026",
                            "SalarySlipActivity",
                            "getSalarySlip",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@SalarySlipActivity,
                    "EC026",
                    "SalarySlipActivity",
                    "getSalarySlip",
                    e
                )
            }
        }
    }

    private fun fetchBankDetails() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            val call = ApiClient.apiService.getBankDetails(bearerToken)

            ApiRequestHandler.makeSuspendApiCall(
                context = this@SalarySlipActivity,
                showLoading = false,
                loadingMessage = "",
                apiCall = { call },
                onSuccess = { response ->
                    bankDetails = response.data
                },
                onError = {
                    Toast.makeText(
                        this@SalarySlipActivity,
                        "Failed to load bank details",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            )
        }
    }


    private fun fetchCompanyDetails() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getCompanyDetails(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@SalarySlipActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        companyDetails = response
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@SalarySlipActivity,
                            "EC036",
                            "SalarySlipActivity",
                            "fetchCompanyDetails",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                Log.d("faqerror", e.message.toString())
                AppLogger.logAndToast(
                    this@SalarySlipActivity,
                    "EC036",
                    "SalarySlipActivity",
                    "fetchCompanyDetails",
                    e
                )
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateUI(data: com.harshal.upzyne.model.SalarySlipData) {
        try {
            binding.apply {
                tvCounsName.text = data.employeename
                tvEmplNo.text = " (${data.empno})"
                tvMonth.text = data.paid_on.substringAfter(" ").trim()
                tvEmplDept.text = "${data.department}  ||  ${data.designation}"
                tvPAN.text = data.pancard
                tvPaidOn.text = data.paid_on
                tvNetPay.text = "₹${data.net_salary}"
                tvBasicPay.text = "₹${data.basicpay}"
                tvMedicalAllowance.text = "₹${data.medical_allowance}+"
                tvTransportAllowance.text = "₹${data.transport_allowance}+"
                tvPersonalAllowance.text = "₹${data.personal_allowance}+"
                tvLeaveDeduction.text = "₹${data.leave_deduction}-"
                tvTotalDeduction.text = "₹${data.total_deductions}"
                tvAccountNo.text = data.bankaccountno
                tvISFC.text = data.ifsccode
                tvAttendance.text = "${data.attendancedays}/${data.totalworkdays}"
                tvLeaves.text = data.leave_deduction.toString()
            }
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC027", "SalarySlipActivity", "updateUI", e)
        }
    }
}