package com.harshal.upzyne.activity.leadMenu

import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.adapter.leadSummaryAdapter.CommunicationAdapter
import com.harshal.upzyne.databinding.ActivityWhisperWireBinding
import com.harshal.upzyne.databinding.ItemLeadSummaryProfileItemBinding
import kotlinx.coroutines.launch

class WhisperWireActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWhisperWireBinding
    private lateinit var adapter: CommunicationAdapter
    private lateinit var profileBinding: ItemLeadSummaryProfileItemBinding

    private var leadId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWhisperWireBinding.inflate(layoutInflater)
        setContentView(binding.root)

        leadId = intent.getIntExtra("lead_id", 0)

        adapter = CommunicationAdapter(this, mutableListOf())
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
        // inflate profile item and add to container (same as your code)
        profileBinding = ItemLeadSummaryProfileItemBinding.inflate(LayoutInflater.from(this), binding.leadContainer, false)
        binding.leadContainer.addView(profileBinding.root)

        setThemeBackground(this, binding.recyclerView)
        setThemeBackground(this, binding.leadContainer)

        val leadId = intent.getIntExtra("lead_id", -1)
        val leadName = intent.getStringExtra("lead_name") ?: ""
        val leadEmail = intent.getStringExtra("lead_email") ?: ""
        val leadPhone = intent.getStringExtra("lead_phone") ?: ""
        val leadTimeAgo = intent.getStringExtra("lead_timeago") ?: ""
        val leadLeadDate = intent.getStringExtra("lead_leaddate") ?: ""
        val leadProgramme = intent.getStringExtra("lead_programme") ?: ""
        val leadSourceBadge = intent.getStringExtra("lead_sourcebadge") ?: ""
        val leadSource = intent.getStringExtra("lead_source") ?: ""
        val leadScore = intent.getStringExtra("lead_score") ?: "0"
        val leadStatusColor = intent.getStringExtra("lead_statuscolor") ?: "#3E4A59"
        val leadVerified = intent.getBooleanExtra("lead_verified", false)
        profileBinding.statusIcon.text = intent.getStringExtra("lead_sourcebadge")
        profileBinding.tvOtpVerification.visibility = if (leadVerified) View.VISIBLE else View.GONE
        // Apply dynamic color to lead label
        val labelDrawable = profileBinding.labelNewLead.background?.mutate()
        val colorWithAlpha = (leadStatusColor.toColorInt() and 0x00FFFFFF) or (0x30 shl 24)
        labelDrawable?.setColorFilter(colorWithAlpha, PorterDuff.Mode.SRC_ATOP)
        profileBinding.labelNewLead.background = labelDrawable
        profileBinding.labelNewLead.setTextColor(leadStatusColor.toColorInt())
        profileBinding.labelNewLead.text = intent.getStringExtra("lead_source") ?: ""
        // Set color to left border background

        val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.left_glass)
        if (backgroundDrawable is LayerDrawable) {
            val leftBorder = backgroundDrawable.findDrawableByLayerId(R.id.left_border)
            if (leftBorder is GradientDrawable) {
                leftBorder.setColor(leadStatusColor.toColorInt())
            }
            profileBinding.itemLead.background = backgroundDrawable
        }
        profileBinding.userName.text = leadName
        profileBinding.userEmail.text = leadEmail
        profileBinding.userPhone.text = leadPhone
        profileBinding.course.text = leadProgramme
        profileBinding.labelNewLead.text = leadSource
        profileBinding.statusIcon.text = leadSourceBadge
        profileBinding.tvOtpVerification.visibility = if (leadVerified) View.VISIBLE else View.GONE
      //  binding.leadStatus2.text = "$leadScore%"


        fetchAllCommunications()
    }

    private fun fetchAllCommunications() {
        val token = getSharedPreferences("app_prefs", MODE_PRIVATE)
            .getString("auth_token", "") ?: ""

        lifecycleScope.launch {
            try {
                val response = ApiClient.apiService.getCommunicationFeed(
                    token = "Bearer $token",
                    leadId = leadId,
                    limit = 100, // fetch all
                    offset = 0
                )
                adapter.updateData(response.whisper_wire)
            } catch (e: Exception) {
                Toast.makeText(this@WhisperWireActivity,
                    "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}