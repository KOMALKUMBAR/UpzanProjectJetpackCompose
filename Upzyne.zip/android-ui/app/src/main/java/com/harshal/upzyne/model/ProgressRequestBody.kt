package com.harshal.upzyne.utils

import android.os.Handler
import android.os.Looper
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MediaType
import okhttp3.RequestBody
import okio.BufferedSink
import java.io.File
import java.io.FileInputStream

class ProgressRequestBody(
    private val data: ByteArray,
    private val contentType: String,
    private val onProgress: (progress: Int) -> Unit
) : RequestBody() {

    override fun contentType(): MediaType? {
        return contentType.toMediaTypeOrNull()
    }

    override fun contentLength(): Long {
        return data.size.toLong()
    }

    override fun writeTo(sink: BufferedSink) {
        val bufferSize = 2048
        var uploaded = 0
        val handler = Handler(Looper.getMainLooper())

        while (uploaded < data.size) {
            val chunkSize = minOf(bufferSize, data.size - uploaded)
            sink.write(data, uploaded, chunkSize)
            uploaded += chunkSize

            val progress = (100 * uploaded / data.size.toFloat()).toInt()
            handler.post {
                onProgress(progress)
            }
        }
    }
}
