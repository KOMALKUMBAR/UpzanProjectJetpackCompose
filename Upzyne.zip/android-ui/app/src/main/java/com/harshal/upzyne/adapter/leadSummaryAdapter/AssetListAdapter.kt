package com.harshal.upzyne.adapter.leadSummaryAdapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ItemAssetSmallBinding
import com.harshal.upzyne.model.LeadsModel

class AssetListAdapter(private val context: Context,private val items: List<LeadsModel.Assets>) :
    RecyclerView.Adapter<AssetListAdapter.VH>() {

    inner class VH(val binding: ItemAssetSmallBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemAssetSmallBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val asset = items[position]
        // Example: if you want to display call recording count
        holder.binding.assetTitle.text = "Call recordings: ${asset.call_recordings ?: 0}"
        setThemeBackground(context, holder.binding.setbackgroundThem)

    }

    override fun getItemCount(): Int = items.size
}
