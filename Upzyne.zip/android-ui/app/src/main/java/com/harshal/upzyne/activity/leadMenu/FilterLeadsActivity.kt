package com.harshal.upzyne.activity.leadMenu

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.databinding.ActivityFilterLeadsBinding
import com.harshal.upzyne.model.LeadsModel
import kotlinx.coroutines.launch

class FilterLeadsActivity : AppCompatActivity() {
        private lateinit var binding: ActivityFilterLeadsBinding
        private lateinit var bearerToken: String
        private lateinit var sharedPref: SharedPreferences

        private var selectedCountryId: Int? = null
        private var selectedCourseId: Int? = null
        private var selectedFollowUpDue: String? = null
        private var selectedCreatedDate: String? = null
        private var selectedLeadScore: String? = null

        private var tagNewSelected = false
        private var tagFollowUpSelected = false
        private var tagConvertedSelected = false
        private var tagHotLeadSelected = false

        private var countryList: List<LeadsModel.Country> = emptyList()
        private var courseList: List<LeadsModel.CourseType> = emptyList()

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityFilterLeadsBinding.inflate(layoutInflater)
            setContentView(binding.root)
            sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
            bearerToken = "Bearer ${sharedPref.getString("auth_token", "") ?: ""}"

            fetchLeadFilters()
            setupListeners()

            binding.btnApplyFilter.setOnClickListener {
                applySelectedFilters()
            }
        }

        private fun fetchLeadFilters() {
            lifecycleScope.launch {
                val call = ApiClient.apiService.getLeadFilters(bearerToken)
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@FilterLeadsActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.loading_filters),
                    apiCall = { call },
                    onSuccess = { response: LeadsModel.FilterResponse? ->
                        response?.let {
                            countryList = it.country
                            courseList = it.course_type
                            setupCountryDropdown()
                            setupCourseDropdown()
                        }
                    },
                    onError = {
                        Toast.makeText(
                            this@FilterLeadsActivity,
                            getString(R.string.failed_to_load_filters),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )
            }
        }

        private fun setupCountryDropdown() {
            val names = countryList.map { it.countryname }
            binding.nameField.setOnClickListener {
                showSingleChoiceDialog(getString(R.string.select_country), names) { index ->
                    binding.nameField.setText(names[index])
                    selectedCountryId = countryList[index].countryid
                }
            }
        }

        private fun setupCourseDropdown() {
            val names = courseList.map { it.productname }
            binding.counselorField.setOnClickListener {
                showSingleChoiceDialog(getString(R.string.select_course), names) { index ->
                    binding.counselorField.setText(names[index])
                    selectedCourseId = courseList[index].productid
                }
            }
        }

        private fun setupListeners() {
            binding.radioButton1.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) selectedFollowUpDue = ""
            }
            binding.radioButton2.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) selectedFollowUpDue = "this_week"
            }
            binding.radioButton3.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) selectedFollowUpDue = "overdue"
            }

            binding.todayTextView.setOnClickListener {
                selectedCreatedDate = "today"
            }
            binding.last7TextView.setOnClickListener {
                selectedCreatedDate = "last_7_days"
            }
            binding.last30TextView.setOnClickListener {
                selectedCreatedDate = "last_30_days"
            }
            binding.customRangeTextView.setOnClickListener {
                selectedCreatedDate = "custom_range"
            }

            // Placeholder tag logic — can be connected to chip selection or tag views
            tagNewSelected = true
            tagFollowUpSelected = true
            tagConvertedSelected = false
            tagHotLeadSelected = false

            selectedLeadScore = "high" // Simulate static selection
        }

        private fun showSingleChoiceDialog(title: String, items: List<String>, onItemSelected: (Int) -> Unit) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle(title)
            builder.setItems(items.toTypedArray()) { _, which ->
                onItemSelected(which)
            }
            builder.show()
        }

        private fun applySelectedFilters() {
            val selectedStatuses = mutableListOf<String>()
            if (binding.customCheckBox.isChecked) selectedStatuses.add("New")
            if (binding.customCheckBox2.isChecked) selectedStatuses.add("Follow-up")
            if (binding.customCheckBox3.isChecked) selectedStatuses.add("Re-engagement")
            if (binding.customCheckBox4.isChecked) selectedStatuses.add("Converted")
            if (binding.customCheckBox5.isChecked) selectedStatuses.add("Dropped")

            val selectedTags = mutableListOf<String>()
            if (tagNewSelected) selectedTags.add("new")
            if (tagFollowUpSelected) selectedTags.add("follow-up")
            if (tagConvertedSelected) selectedTags.add("converted")
            if (tagHotLeadSelected) selectedTags.add("hot lead")

            val resultIntent = Intent().apply {
                putExtra("countryId", selectedCountryId)
                putExtra("courseId", selectedCourseId)
                putExtra("followupDue", selectedFollowUpDue)
                putExtra("createdDate", selectedCreatedDate)
                putExtra("leadScore", selectedLeadScore)
                putStringArrayListExtra("statusList", ArrayList(selectedStatuses))
                putStringArrayListExtra("tagsList", ArrayList(selectedTags))
            }
            setResult(RESULT_OK, resultIntent)
            finish()
        }
    }
