package com.harshal.upzyne.model

data class WhatsappResponse(
    val companyName: String,
    val feedbackCode: String,
    val leadName: String,
    val mobileNo: String,
    val whatsappResponse: WhatsappResponseX,
    val whatsappStatus: String
)