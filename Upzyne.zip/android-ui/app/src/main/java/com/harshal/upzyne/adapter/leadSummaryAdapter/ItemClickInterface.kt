package com.harshal.upzyne.adapter.leadSummaryAdapter

interface ItemClickInterface {
    fun onLeadScoreClick(leadId: Int)
}