package com.harshal.upzyne.activity.settingMenu

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.databinding.ActivityLanguageBinding

class LanguageActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLanguageBinding
    private lateinit var userFullName: String
    private lateinit var sharedPref: SharedPreferences
    private lateinit var currentLanguage: String

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentLanguage = LanguageUtils.getLanguage(this)
        binding = ActivityLanguageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "") ?: ""
        binding.titleText.text = "$userFullName - ${getString(R.string.language)}"

        binding.imgArrow.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.btnEnglish.setOnClickListener {
            setlanguage("en")
        }

        binding.btnHindi.setOnClickListener {
            setlanguage("hi")
        }

        binding.btnMarathi.setOnClickListener {
            setlanguage("mr")
        }

        binding.btnMalayalam.setOnClickListener {
            setlanguage("ml")
        }

        binding.btnKannada.setOnClickListener {
            setlanguage("kn")
        }

        binding.btnTelagu.setOnClickListener {
            setlanguage("te")
        }

        binding.btnArabic.setOnClickListener {
            setlanguage("ar")
        }
    }

    private fun setlanguage(language: String) {
        LanguageUtils.setLanguage(this@LanguageActivity, language)
        recreate()
    }
}