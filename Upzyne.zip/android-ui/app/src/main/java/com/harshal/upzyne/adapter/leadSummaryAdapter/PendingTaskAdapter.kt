package com.harshal.upzyne.adapter.leadSummaryAdapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.databinding.ItemPendingTaskBinding
import com.harshal.upzyne.model.LeadsModel

class PendingTaskAdapter(
    private val tasks: List<LeadsModel.PendingTask>
) : RecyclerView.Adapter<PendingTaskAdapter.TaskViewHolder>() {

    inner class TaskViewHolder(val binding: ItemPendingTaskBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemPendingTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        holder.binding.tvTaskTitle.text = task.text
        holder.binding.tvTaskDueDate.text = "Due: ${task.type}"
    }

    override fun getItemCount() = tasks.size
}
