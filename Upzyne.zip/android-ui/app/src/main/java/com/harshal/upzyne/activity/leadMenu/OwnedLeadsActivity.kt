package com.harshal.upzyne.activity.leadMenu

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ImageSpan
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.adapter.leadSummaryAdapter.ItemClickInterface
import com.harshal.upzyne.adapter.leadsAdpter.OwnedLeadsAdapter
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityOwnedLeadsBinding
import com.harshal.upzyne.model.LeadsModel
import kotlinx.coroutines.launch

class OwnedLeadsActivity : AppCompatActivity(), ItemClickInterface {
    private lateinit var binding: ActivityOwnedLeadsBinding
    private lateinit var ownedLeadsAdpter: OwnedLeadsAdapter
    companion object {
        lateinit var bearerToken: String
        var isCalled: Boolean = false
    }
    private lateinit var userFullName: String
    private lateinit var activityName: String
    private lateinit var sharedPref: SharedPreferences
    private val leadList = mutableListOf<LeadsModel.LeadsModelDataClasss.LeadData>()
    private val loadedLeadIds = mutableSetOf<Long>()
    private var isSearchMode = false

    private var offset = 0
    private val limit = 20
    private var isLoading = false
    private var isLastPage = false
    private var _totalCount: String = "0"
    private var totalLeadsAvailable = 0

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOwnedLeadsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "") ?: ""
        activityName = getString(R.string.owned_leads)
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "") ?: ""}"
        binding.titleText.text = "$userFullName - $activityName [$_totalCount]"
        binding.recyclerviewOwnLeads.layoutManager = LinearLayoutManager(this)
        ownedLeadsAdpter = OwnedLeadsAdapter(this, lifecycleScope, leadList, this)
        binding.recyclerviewOwnLeads.adapter = ownedLeadsAdpter
        binding.btnApplyFilter.setOnClickListener(){
             val intent  = Intent(this, FilterLeadsActivity::class.java)
             startActivity(intent)
        }
        setThemeBackground(this, binding.contentFrame)

        binding.imgArrow.setOnClickListener { finish() }
        binding.recyclerviewOwnLeads.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (!recyclerView.canScrollVertically(1) && !isLoading && !isLastPage) {
                    fetchAssignedLeads(limit, offset)
                }
            }
        })

        binding.searchEditText.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString().trim()
                if (query.isNotEmpty()) {
                    isSearchMode = true
                    searchLeads(query)
                } else {
                    isSearchMode = false
                    resetAndFetch()
                }
            }

            override fun afterTextChanged(s: android.text.Editable?){}
        })

        fetchAssignedLeads(limit, offset)
    }

    private fun searchLeads(query: String) {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.searchAssignedLeads(
                    bearerToken,
                    query,
                    limit = 20,
                    offset = 0
                )

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@OwnedLeadsActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val leads = response.body() ?: emptyList()
                        leadList.clear()
                        loadedLeadIds.clear()
                        leadList.addAll(leads)
                        ownedLeadsAdpter.notifyDataSetChanged()

                        binding.titleText.text = "$userFullName - $activityName [${leads.size}]"

                        if (leads.isEmpty()) {
                            binding.emptyState.visibility = View.VISIBLE
                            binding.recyclerviewOwnLeads.visibility = View.GONE

                        } else {
                            binding.emptyState.visibility = View.GONE
                            binding.recyclerviewOwnLeads.visibility = View.VISIBLE
                        }
                    },
                    onError = {
                        Log.e("LEAD_SEARCH", "Error: $it")
                        binding.emptyState.visibility = View.VISIBLE
                        binding.recyclerviewOwnLeads.visibility = View.GONE
                    }
                )
            } catch (e: Exception) {
                Log.e("LEAD_SEARCH", "Exception: ${e.message}")
                binding.emptyState.visibility = View.VISIBLE
                binding.recyclerviewOwnLeads.visibility = View.GONE
            }
        }
    }

    private fun resetAndFetch() {
        offset = 0
        isLastPage = false
        leadList.clear()
        loadedLeadIds.clear()
        ownedLeadsAdpter.notifyDataSetChanged()
        fetchAssignedLeads(limit,offset)
        }

    fun refresh() {
        // Your logic to refresh data or views
        resetAndFetch()
        //binding.recyclerviewOwnLeads.adapter?.notifyDataSetChanged()
    }

    private fun fetchAssignedLeads(limit: Int, offset: Int) {
        if (!checkNetworkAndShowMessage(this)) return
        isLoading = true

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getAssignedLeads(bearerToken, limit, offset)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@OwnedLeadsActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val newLeads = response.body() ?: emptyList()
                        Log.d("LEAD_DEBUG", "Fetched: ${newLeads} leads at offset $offset")

                        if (offset == 0 && newLeads.isEmpty()) {
                            // Empty data on first load
                            binding.emptyState.visibility = View.VISIBLE
                            binding.recyclerviewOwnLeads.visibility = View.GONE
                            isLastPage = true
                        } else {
                            // Update total count and title
                            if (offset == 0 && newLeads.isNotEmpty()) {
                                totalLeadsAvailable = newLeads.first().totalcount
                                _totalCount = totalLeadsAvailable.toString()
                                binding.titleText.text = "$userFullName - $activityName [$_totalCount]"
                            }

                            // Filter out duplicates
                            val filteredNewLeads = newLeads.filter { loadedLeadIds.add(it.leadid.toLong()) }

                            if (filteredNewLeads.isNotEmpty()) {
                                leadList.addAll(filteredNewLeads)
                                ownedLeadsAdpter.notifyItemRangeInserted(
                                    leadList.size - filteredNewLeads.size,
                                    filteredNewLeads.size
                                )

                                binding.emptyState.visibility = View.GONE
                                binding.recyclerviewOwnLeads.visibility = View.VISIBLE

                                Toast.makeText(
                                    this@OwnedLeadsActivity,
                                    "${leadList.size} out of $totalLeadsAvailable leads loaded",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }

                            // Final check if there's nothing to show at all
                            if (leadList.isEmpty()) {
                                binding.emptyState.visibility = View.VISIBLE
                                binding.recyclerviewOwnLeads.visibility = View.GONE
                            }

                            // Stop pagination if all leads loaded or no more data
                            if (leadList.size >= totalLeadsAvailable || newLeads.size < limit) {
                                isLastPage = true
                            } else {
                                this@OwnedLeadsActivity.offset += limit
                            }
                            ownedLeadsAdpter.notifyDataSetChanged()
                        }
                        isLoading = false
                    },
                    onError = { error ->
                        isLoading = false
                        UtilsMethods.AppLogger.logAndToast(
                            this@OwnedLeadsActivity,
                            "EC999",
                            "OwnedLeadsActivity",
                            "fetchAssignedLeads",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                isLoading = false
                UtilsMethods.AppLogger.logAndToast(
                    this@OwnedLeadsActivity,
                    "EC999",
                    "OwnedLeadsActivity",
                    "fetchAssignedLeads",
                    e
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!isCalled) {
            resetAndFetch()
        }
    }

    // =================== Couse Popup Menu Implementations komal ===================
    override fun onLeadScoreClick(leadId: Int) {
        isLoading = true

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getLeadScore(bearerToken, leadId)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@OwnedLeadsActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        isLoading = false
                        val leadsScore = response.body()?.data ?: emptyList()
                        showScorePopup(this@OwnedLeadsActivity,leadsScore)
                    },
                    onError = { error ->
                        isLoading = false
                        UtilsMethods.AppLogger.logAndToast(
                            this@OwnedLeadsActivity,
                            "EC999",
                            "OwnedLeadsActivity",
                            "fetchAssignedLeads",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                isLoading = false
                UtilsMethods.AppLogger.logAndToast(
                    this@OwnedLeadsActivity,
                    "EC999",
                    "OwnedLeadsActivity",
                    "fetchAssignedLeads",
                    e
                )
            }
        }
    }

    private fun showScorePopup(context: Context, leadsScore: List<LeadsModel.LeadsScoreResponse.LeadScoreData>) {
        val leadScoreData = leadsScore.firstOrNull() ?: return
        val inflater = LayoutInflater.from(context)
        val popupView = inflater.inflate(R.layout.menu_leadscore_popup, null)

        // Set score %
        val tvScore = popupView.findViewById<TextView>(R.id.tvScore)
        tvScore.text = "${leadScoreData.percentage_score}%"

        // Set lead ID
        val tvScoreleadId = popupView.findViewById<TextView>(R.id.LeadScoreId)
        tvScoreleadId.text = "[id: ${leadScoreData.leadid.toString()}]"

        // Set raw score
        val tvRawScore = popupView.findViewById<TextView>(R.id.tvRawScore)
        tvRawScore.text = "[Raw Score: ${leadScoreData.raw_score}]"

        // Format breakdown
        val tvScoreBreakDown = popupView.findViewById<TextView>(R.id.scoreBreakDown)
        tvScoreBreakDown.text = formatListWithIcon(popupView.context, leadScoreData.breakdown.split("|"), R.drawable.gray_pin)

        val tvDescription = popupView.findViewById<TextView>(R.id.tvDescription)
        tvDescription.text = formatListWithIcon(popupView.context, leadScoreData.suggestions.split(","), R.drawable.gray_hand)

        // Setup popup window
        val popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        )
        popupWindow.elevation = 10f
        popupWindow.isOutsideTouchable = true

        // Show at center of screen
        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0)

        // Close on button click
        val closeButton = popupView.findViewById<Button>(R.id.closeButton)
        closeButton.setOnClickListener {
            popupWindow.dismiss()
        }

    }
    fun formatListWithIcon(context: Context, list: List<String>, drawableRes: Int): SpannableStringBuilder {
        val result = SpannableStringBuilder()

        val drawable = ContextCompat.getDrawable(context, drawableRes)
        drawable?.setBounds(0, 0, 40, 40)

        list.forEachIndexed { index, item ->
            val span = ImageSpan(drawable!!, ImageSpan.ALIGN_BOTTOM)
            val start = result.length
            result.append("  ${item.trim()}") // prepend space for icon span
            result.setSpan(span, start, start + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (index != list.size - 1) result.append("\n")
        }

        return result
    }
}