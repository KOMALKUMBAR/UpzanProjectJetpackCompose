package com.harshal.upzyne.model

data class TeamContactsResponse(
    val data: List<TeamContactsResponseData>
)

data class TeamContactsResponseData(
    val name: String,
    val contactnumber: String,
    val designation: String,
    val email: String
)
