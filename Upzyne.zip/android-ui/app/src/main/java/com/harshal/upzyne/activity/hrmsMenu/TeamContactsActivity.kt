package com.harshal.upzyne.activity.hrmsMenu

import TeamContactsAdapter
import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.databinding.ActivityTeamcontactBinding
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch

class TeamContactsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTeamcontactBinding
    private lateinit var adapter: TeamContactsAdapter
    private lateinit var bearerToken: String
    private var searchRunnable: Runnable? = null
    lateinit var userFullName: String

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeamcontactBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        binding.recyclerTeamContact.layoutManager = LinearLayoutManager(this)

        val sharedPref = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val token = sharedPref.getString("auth_token", "") ?: ""
        bearerToken = "Bearer $token"

        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.team_contact)
        binding.titleBar.text = "$userFullName - $activityName"

        binding.imgArrow.setOnClickListener {
            finish()
        }

        fetchTeamContacts()

        binding.edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                try {
                    searchRunnable?.let { binding.edtSearch.removeCallbacks(it) }

                    searchRunnable = Runnable {
                        val searchTerm = s.toString().trim()
                        if (searchTerm.isNotEmpty()) {
                            searchContacts(searchTerm)
                        } else {
                            fetchTeamContacts()
                        }
                    }

                    binding.edtSearch.postDelayed(searchRunnable!!, 500)
                } catch (e: Exception) {
                    AppLogger.logAndToast(this@TeamContactsActivity, "EC038", "TeamContactsActivity", "onTextChanged", e)
                }
            }
        })
    }

    private fun fetchTeamContacts() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {

                val call = ApiClient.apiService.getTeamContacts(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@TeamContactsActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val contactList = response.data

                        if (contactList.isNotEmpty()) {
                            adapter = TeamContactsAdapter(contactList)
                            binding.recyclerTeamContact.adapter = adapter
                            binding.tvContacts.text = "Showing ${contactList.size} contacts"
                        } else {
                            binding.tvContacts.text = getString(R.string.data_not_found)
                            Toast.makeText(this@TeamContactsActivity, "No contacts found", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@TeamContactsActivity,
                            "EC036",
                            "TeamContactsActivity",
                            "fetchTeamContacts",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(this@TeamContactsActivity, "EC036", "TeamContactsActivity", "fetchTeamContacts", e)
            }
        }
    }

    private fun searchContacts(term: String) {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.searchTeamContacts(bearerToken, term)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@TeamContactsActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val searchResults = response.data
                        adapter = TeamContactsAdapter(searchResults)
                        binding.recyclerTeamContact.adapter = adapter
                        binding.tvContacts.text = "Showing ${searchResults.size} contacts"
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@TeamContactsActivity,
                            "EC037",
                            "TeamContactsActivity",
                            "searchContacts",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@TeamContactsActivity,
                    "EC037",
                    "TeamContactsActivity",
                    "searchContacts",
                    e
                )
            }
        }
    }
}