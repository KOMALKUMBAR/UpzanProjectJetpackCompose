package com.harshal.upzyne.activity.hrmsMenu

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.adapter.HolidayAdapter
import com.harshal.upzyne.databinding.ActivityHolidayBinding
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch

class HolidayActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHolidayBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var userFullName: String

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHolidayBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.holidays)
        binding.titleBar.text = "$userFullName - $activityName"
        setThemeBackground(this, binding.rootLayout)

        binding.imgArrow.setOnClickListener {
            finish()
        }

        binding.recyclerviewHoliday.layoutManager = LinearLayoutManager(this)
        fetchHolidayData()
    }

    private fun fetchHolidayData() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@HolidayActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { ApiClient.apiService.getHoliday("Bearer ${sharedPref.getString("auth_token", "")}") },
                    onSuccess = { response ->
                        val holidayList = response.data
                        Log.d("HolidaySuccess", holidayList.toString())

                        // Initialize adapter and set to RecyclerView
                        val holidayAdapter = HolidayAdapter(holidayList)
                        binding.recyclerviewHoliday.adapter = holidayAdapter
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@HolidayActivity,
                            "EC040",
                            "HolidayActivity",
                            "fetchHolidayData",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@HolidayActivity,
                    "EC040",
                    "HolidayActivity",
                    "fetchHolidayData",
                    e
                )
            }
        }
    }
}