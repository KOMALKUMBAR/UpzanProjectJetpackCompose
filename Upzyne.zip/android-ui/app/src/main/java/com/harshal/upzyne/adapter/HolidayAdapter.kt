package com.harshal.upzyne.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.databinding.ItemHolidayBinding
import com.harshal.upzyne.model.HolidayData
import androidx.core.graphics.toColorInt

class HolidayAdapter(private val holidayList: List<HolidayData>) :
    RecyclerView.Adapter<HolidayAdapter.HolidayViewHolder>() {
    private val colorList = listOf(
        "#7E4EEA".toColorInt(),
        "#E14531".toColorInt(),
        "#F0A666".toColorInt(), // Removed space
        "#8DC518".toColorInt(),
        "#1CAEB2".toColorInt(),
        "#1F639D".toColorInt(),
        "#6640BD".toColorInt())

    inner class HolidayViewHolder(val binding: ItemHolidayBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolidayViewHolder {
        val binding = ItemHolidayBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return HolidayViewHolder(binding)
    }

    override fun onBindViewHolder(holder: HolidayViewHolder, position: Int) {
        val item = holidayList[position]
        holder.binding.tvDate.text = item.holidaydate
        holder.binding.tvDay.text = item.weekday.lowercase()
        holder.binding.tvHolidayName.text = item.holidayname.lowercase()

        val randomColor = colorList.random()
        holder.binding.tvHolidayName.setTextColor(randomColor)
    }

    override fun getItemCount(): Int = holidayList.size
}