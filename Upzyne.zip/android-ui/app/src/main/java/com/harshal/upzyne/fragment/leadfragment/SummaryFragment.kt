package com.harshal.upzyne.fragment.leadfragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.adapter.leadSummaryAdapter.AssetListAdapter
import com.harshal.upzyne.adapter.leadSummaryAdapter.DocumentSmallAdapter
import com.harshal.upzyne.adapter.leadSummaryAdapter.PendingTaskAdapter
import com.harshal.upzyne.databinding.FragmentSummaryBinding
import com.harshal.upzyne.model.LeadsModel
import java.text.SimpleDateFormat
import java.util.Locale

class SummaryFragment : Fragment() {

    private var _binding: FragmentSummaryBinding? = null
    private val binding get() = _binding!!
    private var leadData: LeadsModel.LeadSummaryData? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        leadData = arguments?.getSerializable("lead_summary_data") as? LeadsModel.LeadSummaryData
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSummaryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (leadData == null) {
            // Show error message if data is missing
            binding.errorMessage.visibility = View.VISIBLE

            // Try to get error text from arguments if provided
            val errorText = arguments?.getString("error_message")
                ?: "No lead summary available for this lead."

            binding.errorMessage.text = errorText
            return
        }

        // Hide error if data is valid
        binding.errorMessage.visibility = View.GONE
        leadData?.let { data ->

            // Next followup
            binding.nextFollowup.text = formatIsoDateTime(data.follow_up?.next_followup)

            // AI suggestion and reminder
            binding.aiSuggestionText.text = data.follow_up?.ai_suggestion ?: "-"
            binding.reminderSet.text = data.follow_up?.reminder_set_by ?: "-"

            // Pending tasks adapter (keep empty first)
            val tasks = data.follow_up?.pending_tasks ?: emptyList()
            val pendingAdapter = PendingTaskAdapter(tasks)
            binding.pendingTasksRecyclerView.layoutManager = LinearLayoutManager(requireContext())
            binding.pendingTasksRecyclerView.adapter = pendingAdapter

            // Toggle show/hide when label clicked
            binding.pendingTaskLabel.setOnClickListener {
                if (binding.pendingTasksRecyclerView.visibility == View.VISIBLE) {
                    binding.pendingTasksRecyclerView.visibility = View.GONE
                } else {
                    // Optionally refresh from API before showing
                    // fetchPendingTasksFromApi()
                    binding.pendingTasksRecyclerView.visibility = View.VISIBLE

                }
            }
            // Documents horizontal list
            val documents = data.documents ?: emptyList()
            binding.documentRecyclerView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            binding.documentRecyclerView.adapter = DocumentSmallAdapter(requireContext(),documents)

            // Assets (example: create list to show call recording count)
            val assetItems: List<LeadsModel.Assets> =
                if (data.assets != null) listOf(data.assets) else emptyList()

            binding.assetRecyclerView.layoutManager =
                LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            binding.assetRecyclerView.adapter = AssetListAdapter(requireContext(),assetItems)
            setThemeBackground(requireContext(), binding.setybackgroundThem)


        }
    }

    private fun formatIsoDateTime(iso: String?): String {
        if (iso.isNullOrBlank()) return "-"
        return try {
            val src = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
            val dest = SimpleDateFormat("dd MMM, yyyy @hh:mm a", Locale.getDefault())
            val dt = src.parse(iso)
            if (dt != null) dest.format(dt) else "-"
        } catch (e: Exception) {
            iso
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
