package com.harshal.upzyne.model

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Log
import android.view.*
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.DialogFloatingwindowBinding
import androidx.core.net.toUri

class FloatingWindowService : Service() {
    private var windowManager: WindowManager? = null
    private var binding: DialogFloatingwindowBinding? = null

    companion object {
        private var isFloatingWindowShowing = false
    }

    override fun onCreate() {
        super.onCreate()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channelId = "FloatingWindowServiceChannel"
                val channelName = "Floating Window Overlay"

                val channel = NotificationChannel(
                    channelId,
                    channelName,
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Required for showing floating window while app is in background"
                    setShowBadge(false)
                    enableVibration(false)
                    enableLights(false)
                }

                val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.createNotificationChannel(channel)

                val notification = NotificationCompat.Builder(this, channelId)
                    .setContentTitle("Floating Window Active")
                    .setContentText("Call overlay is running")
                    .setSmallIcon(R.drawable.ic_launcher_foreground) // Replace with your own icon
                    .setOngoing(true)
                    .build()

                startForeground(1, notification)
            }
        } catch (e: Exception) {
            Log.e("floatingWindowError", e.message.toString())
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val phone = intent?.getStringExtra("phone") ?: "Unknown"
            val time = intent?.getStringExtra("time") ?: "--:--"
            val name = getContactName(phone)

            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }

            removeFloatingWindow()
            showFloatingWindow(phone, time, name)

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error in onStartCommand: ${e.message}", Toast.LENGTH_LONG).show()
        }

        return START_NOT_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showFloatingWindow(phone: String, time: String, name: String) {
        if (isFloatingWindowShowing) return
        isFloatingWindowShowing = true

        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            binding = DialogFloatingwindowBinding.inflate(LayoutInflater.from(this))

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 0
                y = 100
            }

            val view = binding?.root ?: return
            setThemeBackground(this, binding!!.layFloat)

            binding?.tvPhone?.text = phone
            binding?.tvTime?.text = time
            binding?.tvName?.text = name

            val number = phone.trim()

            binding?.ivClose?.setOnClickListener { stopSelf() }

            binding!!.txtReplyvideo.setOnClickListener {
                initiateWhatsAppVideoCall(this, number)
            }

            binding?.txtReplywhatsapp?.setOnClickListener {
                openWhatsAppChat(number, isBusiness = false)
            }

            binding?.txtReplywhatsappbisuness?.setOnClickListener {
                openWhatsAppChat(number, isBusiness = true)
            }

            binding?.txtMobilesms?.setOnClickListener {
                try {
                    val smsIntent = Intent(Intent.ACTION_VIEW).apply {
                        data = Uri.parse("sms:$number")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    startActivity(smsIntent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Cannot send SMS", Toast.LENGTH_SHORT).show()
                }
            }

            binding?.txtMobilecall?.setOnClickListener {
                try {
                    val callIntent = Intent(Intent.ACTION_DIAL).apply {
                        data = Uri.parse("tel:$number")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    startActivity(callIntent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Cannot make call", Toast.LENGTH_SHORT).show()
                }
            }

            view.setOnTouchListener(object : View.OnTouchListener {
                private var initialX = 0
                private var initialY = 0
                private var initialTouchX = 0f
                private var initialTouchY = 0f

                override fun onTouch(v: View?, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            initialX = params.x
                            initialY = params.y
                            initialTouchX = event.rawX
                            initialTouchY = event.rawY
                            return true
                        }

                        MotionEvent.ACTION_MOVE -> {
                            params.x = initialX + (event.rawX - initialTouchX).toInt()
                            params.y = initialY + (event.rawY - initialTouchY).toInt()
                            windowManager?.updateViewLayout(view, params)
                            return true
                        }
                    }
                    return false
                }
            })

            windowManager?.addView(view, params)
            Log.d("FloatingWindowService", "Floating window shown for $phone")

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error showing floating window: ${e.message}", Toast.LENGTH_LONG).show()
            isFloatingWindowShowing = false
        }
    }

    fun initiateWhatsAppVideoCall(context: Context, rawPhone: String) {
        val packageName = when {
            isAppInstalled(context, "com.whatsapp") -> "com.whatsapp"
            isAppInstalled(context, "com.whatsapp.w4b") -> "com.whatsapp.w4b"
            else -> {
                Toast.makeText(context, "WhatsApp or WhatsApp Business is not installed.", Toast.LENGTH_LONG).show()
                return
            }
        }

        val phoneNumber = rawPhone.filter { it.isDigit() }.takeLast(10)
        val packageManager = context.packageManager

        try {
            val cursor = context.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(ContactsContract.Data._ID),
                "${ContactsContract.Data.MIMETYPE} = ? AND ${ContactsContract.CommonDataKinds.Phone.NUMBER} LIKE ?",
                arrayOf("vnd.android.cursor.item/vnd.com.whatsapp.video.call", "%$phoneNumber%"),
                null
            )

            cursor?.use {
                if (it.moveToFirst()) {
                    val id = it.getLong(it.getColumnIndexOrThrow(ContactsContract.Data._ID))
                    val videoIntent = Intent(Intent.ACTION_VIEW).apply {
                        setPackage(packageName)
                        setDataAndType(
                            Uri.parse("content://com.android.contacts/data/$id"),
                            "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
                        )
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }

                    if (videoIntent.resolveActivity(packageManager) != null) {
                        context.startActivity(videoIntent)
                        return
                    }
                }
            }

            val url = "https://api.whatsapp.com/send?phone=+91$phoneNumber"
            val chatIntent = Intent(Intent.ACTION_VIEW).apply {
                setPackage(packageName)
                data = Uri.parse(url)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            if (chatIntent.resolveActivity(packageManager) != null) {
                context.startActivity(chatIntent)
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun isAppInstalled(context: Context, packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun openWhatsAppChat(phoneNumber: String, isBusiness: Boolean) {
        try {
            val number = phoneNumber.replace("+", "").replace(" ", "").trim()
            val packageName = if (isBusiness) "com.whatsapp.w4b" else "com.whatsapp"

            val uri = Uri.parse("https://wa.me/$number")
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = uri
                setPackage(packageName)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "WhatsApp not installed or number invalid", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getContactName(phoneNumber: String): String {
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(phoneNumber)
            )
            val projection = arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME)
            val cursor = contentResolver.query(uri, projection, null, null, null)

            cursor?.use {
                if (it.moveToFirst()) {
                    return it.getString(0)
                }
            }
            "Unknown Number"
        } catch (e: Exception) {
            e.printStackTrace()
            "Unknown Number"
        }
    }

    private fun removeFloatingWindow() {
        try {
            if (windowManager != null && binding?.root?.isAttachedToWindow == true) {
                windowManager?.removeView(binding?.root)
            }
            binding = null
            isFloatingWindowShowing = false
        } catch (e: Exception) {
            e.printStackTrace()
            isFloatingWindowShowing = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        removeFloatingWindow()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}