package com.harshal.upzyne.fragment.leadfragment

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.activity.leadMenu.EmailToLeadActivity
import com.harshal.upzyne.activity.leadMenu.LeadSummaryActivity
import com.harshal.upzyne.activity.leadMenu.SendMessageActivity
import com.harshal.upzyne.activity.leadMenu.SetReminderActivity
import com.harshal.upzyne.databinding.FragmentNotesBinding
import com.harshal.upzyne.model.LeadsModel
import kotlinx.coroutines.launch

class NotesFragment : Fragment() {

    private var _binding: FragmentNotesBinding? = null
    private val binding get() = _binding!!
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private var leadType: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentNotesBinding.inflate(inflater, container, false)
        setThemeBackground(requireContext(), binding.setbackgroundThem)

        sharedPref = requireActivity().getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "") ?: ""}"

        // Get lead type from arguments if passed
        leadType = arguments?.getString("lead_source")

        val leadName = arguments?.getString("lead_name") ?: "-"
        binding.tvLeadName.text = leadName

        binding.viewLead.setOnClickListener{
            val viewLead = startActivity(Intent(requireContext(), LeadSummaryActivity::class.java))
        }
        binding.setReminder.setOnClickListener{
            val setReminder = startActivity(Intent(requireContext() , SetReminderActivity::class.java))
        }
        binding.sendEmail.setOnClickListener{
            val sendEmail = startActivity(Intent(requireContext() , EmailToLeadActivity::class.java))
        }
        binding.whatsapp.setOnClickListener{
            val whatsapp = startActivity(Intent(requireContext() , SendMessageActivity::class.java))
        }



        fetchAndBindLeadStatus()

        return binding.root
    }

    private fun fetchAndBindLeadStatus() {
        lifecycleScope.launch {
            val leadStatusList = fetchLeadStatus()
            leadStatusList?.let { list ->
                val adapter = object : ArrayAdapter<LeadsModel.getLeadStatus.leadStatus>(
                    requireContext(),
                    R.layout.item_spinner_color,
                    list
                ) {
                    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                        return createCustomView(position, convertView, parent)
                    }

                    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                        return createCustomView(position, convertView, parent)
                    }

                    private fun createCustomView(position: Int, convertView: View?, parent: ViewGroup): View {
                        val view = convertView ?: LayoutInflater.from(context)
                            .inflate(R.layout.item_spinner_color, parent, false)
                        val statusItem = getItem(position)
                        val colorIndicator = view.findViewById<View>(R.id.colorDot)
                        val statusName = view.findViewById<TextView>(R.id.spinnerViewName)

                        statusName.text = statusItem?.leadstatusname

                        statusItem?.hexcolor?.let { hex ->
                            try {
                                val drawable = colorIndicator.background.mutate() as GradientDrawable
                                drawable.setColor(Color.parseColor(hex))
                            } catch (e: Exception) {
                                val drawable = colorIndicator.background.mutate() as? GradientDrawable
                                drawable?.setColor(Color.GRAY)
                            }
                        }
                        return view
                    }
                }

                binding.spinnerCallStatus.adapter = adapter

                // Pre-select lead type if available
                leadType?.let { type ->
                    val indexToSelect = list.indexOfFirst {
                        it.leadstatusname.equals(type, ignoreCase = true)
                    }
                    if (indexToSelect >= 0) {
                        binding.spinnerCallStatus.setSelection(indexToSelect)
                    }
                }
            }
        }
    }

    private suspend fun fetchLeadStatus(): List<LeadsModel.getLeadStatus.leadStatus>? {
        return try {
            val call = ApiClient.apiService.getLeadStatus(bearerToken)
            var result: List<LeadsModel.getLeadStatus.leadStatus>? = null

            ApiRequestHandler.makeSuspendApiCall(
                context = requireContext(),
                showLoading = true,
                loadingMessage = getString(R.string.fetching_data),
                apiCall = { call },
                onSuccess = { response ->
                    result = response.body()
                },
                onError = { error ->
                    // handle error here
                }
            )
            result
        } catch (e: Exception) {
            null
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
