package com.harshal.upzyne.activity.leadMenu

import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.maskPhoneNumber
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.adapter.leadSummaryAdapter.CounselorAdapter
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityReassignLeadBinding
import com.harshal.upzyne.databinding.LayoutErrorAlertBinding
import com.harshal.upzyne.model.LeadsModel
import kotlinx.coroutines.launch

class ReassignLeadActivity : AppCompatActivity() {
    private lateinit var binding: ActivityReassignLeadBinding
    companion object {
        lateinit var baseUrl: String
        var selectedCounselor: Int = 0
    }
    lateinit var bearerToken: String
    private var searchRunnable: Runnable? = null
    private lateinit var userFullName: String
    private lateinit var sharedPref: SharedPreferences
    private lateinit var counselorAdapter: CounselorAdapter

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReassignLeadBinding.inflate(layoutInflater)
        setContentView(binding.root)
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "") ?: ""
        baseUrl = sharedPref.getString("base_url", "") ?: ""
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "") ?: ""}"
        binding.titleText.text = "$userFullName - ${getString(R.string.re_assign_lead)}"

        setThemeBackground(this, binding.scrollbar)
        fetchCounselors()

        val _leadStatusColor = intent.getStringExtra("lead_statuscolor")
        val drawable1 = binding.labelNewLead.background?.mutate()
        val colorWithAlpha = (_leadStatusColor!!.toColorInt() and 0x00FFFFFF) or (0x30 shl 24)
        drawable1?.setColorFilter(colorWithAlpha, PorterDuff.Mode.SRC_ATOP)
        binding.labelNewLead.background = drawable1
        binding.labelNewLead.setTextColor(_leadStatusColor.toColorInt())

        val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.left_glass)
        if (backgroundDrawable is LayerDrawable) {
            val leftBorder = backgroundDrawable.findDrawableByLayerId(R.id.left_border)
            if (leftBorder is GradientDrawable) {
                leftBorder.setColor(_leadStatusColor.toColorInt())
            }
            binding.itemLead.background = backgroundDrawable
        }

        val _leadId = intent.getLongExtra("lead_id", 0)
        val _leadSourceBadge = intent.getBooleanExtra("lead_verified", false)
        binding.tvOtpVerification.visibility = if (_leadSourceBadge) View.VISIBLE else View.GONE

        binding.userName.text = intent.getStringExtra("lead_name")
        binding.userEmail.text = intent.getStringExtra("lead_email")
        binding.userPhone.text = maskPhoneNumber(intent.getStringExtra("lead_phone")!!)
        binding.engagedDate.text = intent.getStringExtra("lead_timeago")
        binding.joinedDate.text = intent.getStringExtra("lead_leaddate")
        binding.course.text = intent.getStringExtra("lead_programme")
        binding.statusIcon.text = intent.getStringExtra("lead_sourcebadge")
        binding.labelNewLead.text = intent.getStringExtra("lead_source")

        binding.lay.setOnClickListener {
            currentFocus?.let { view ->
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(view.windowToken, 0)
                view.clearFocus()
            }
        }

        binding.imgArrow.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                try {
                    searchRunnable?.let { binding.edtSearch.removeCallbacks(it) }

                    searchRunnable = Runnable {
                        val searchTerm = s.toString().trim()
                        if (searchTerm.isNotEmpty()) {
                            searchCounselors(searchTerm)
                        } else {
                            fetchCounselors()
                        }
                    }

                    binding.edtSearch.postDelayed(searchRunnable!!, 500)
                } catch (e: Exception) {
                    AppLogger.logAndToast(this@ReassignLeadActivity, "EC038", "TeamContactsActivity", "onTextChanged", e)
                }
            }
        })

        binding.confirmReassignBtn.setOnClickListener {
            if (!checkNetworkAndShowMessage(this)) return@setOnClickListener

            val assignReason = binding.etAssignReason.text.toString()
            val isReminder = binding.reminderSwitch.isChecked
            val isLeadNotify = binding.notifyCheckbox.isChecked
            if (selectedCounselor == 0){
                Toast.makeText(
                    this,
                    getString(R.string.please_select_counselor_first),
                    Toast.LENGTH_SHORT
                ).show()
            } else if (binding.etAssignReason.text.toString().isNullOrEmpty()){
                binding.etAssignReason.error = getString(R.string.reason_for_re_assigning)
            } else {
                lifecycleScope.launch {
                    reassignLead(
                        _leadId,
                        selectedCounselor,
                        assignReason,
                        isReminder,
                        isLeadNotify
                    )
                }
            }
        }
    }

    private fun fetchCounselors() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getCounselorList(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ReassignLeadActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val counselorList = response.body()?.data?.users
                        if (counselorList?.size == 0){
                            binding.layNoData.root.visibility = View.VISIBLE
                        } else {
                            binding.layNoData.root.visibility = View.GONE
                            counselorAdapter = CounselorAdapter(counselorList)
                            binding.counselorRecyclerView.layoutManager = LinearLayoutManager(
                                this@ReassignLeadActivity,
                                LinearLayoutManager.HORIZONTAL,
                                false
                            )
                            binding.counselorRecyclerView.adapter = counselorAdapter
                        }
                    },
                    onError = { error ->
                        Log.e("tagError", error)
                        UtilsMethods.AppLogger.logAndToast(
                            this@ReassignLeadActivity,
                            "EC999",
                            "OwnedLeadsActivity",
                            "fetchAssignedLeads",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                Log.e("tagErr", e.message.toString())
                UtilsMethods.AppLogger.logAndToast(
                    this@ReassignLeadActivity,
                    "EC999",
                    "OwnedLeadsActivity",
                    "fetchAssignedLeads",
                    e
                )
            }
        }
    }

    private fun searchCounselors(term: String) {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.searchCounselor(bearerToken, term)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ReassignLeadActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val searchResults = response.body()?.data?.users
                        Log.d("searchCounselors", "${searchResults?.size}")

                        if (searchResults?.size == 0){
                            binding.counselorRecyclerView.visibility = View.GONE
                            binding.layNoData.root.visibility = View.VISIBLE
                        } else {
                            binding.counselorRecyclerView.visibility = View.VISIBLE
                            binding.layNoData.root.visibility = View.GONE
                            Log.d("searchCounselors", searchResults.toString())
                            counselorAdapter = CounselorAdapter(searchResults)
                            binding.counselorRecyclerView.adapter = counselorAdapter
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@ReassignLeadActivity,
                            "EC037",
                            "TeamContactsActivity",
                            "searchContacts",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@ReassignLeadActivity,
                    "EC037",
                    "TeamContactsActivity",
                    "searchContacts",
                    e
                )
            }
        }
    }

    private suspend fun reassignLead(leadId: Long, newUserId: Int, reason: String, notifyLead: Boolean, repeatReminder: Boolean) {
        try {
            val requestBody = LeadsModel.ReassignLeadRequest(
                leadId,
                newUserId,
                reason,
                notifyLead,
                repeatReminder
            )

            val call = ApiClient.apiService.reassignLead(bearerToken, requestBody)

            ApiRequestHandler.makeSuspendApiCall(
                context = this,
                showLoading = true,
                loadingMessage = getString(R.string.uploading),
                apiCall = { call },
                onSuccess = { response ->
                    val result = response.body()
                    Log.d("reassignLeadSuccess", "$result")

                    val binding = LayoutErrorAlertBinding.inflate(LayoutInflater.from(this))
                    val dialog = AlertDialog.Builder(this)
                        .setView(binding.root)
                        .setCancelable(false)
                        .create()
                    binding.tvError.text = result?.data?.message.toString()
                    binding.btnok.setOnClickListener {
                        dialog.dismiss()
                        onBackPressedDispatcher.onBackPressed()
                    }
                    dialog.show()
                },
                onError = { error ->
                    Log.d("reassignLeadFailed", error)
                }
            )
        } catch (e: Exception) {
            Log.e("leadAssignException", e.message.toString())
        }
    }
}