package com.harshal.upzyne.activity.settingMenu

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.AppLogger.logAndToast
import com.harshal.upzyne.UtilsMethods.applyInsetPadding
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ActivityPersonInfoPageBinding
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch

class PersonInfoPageActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPersonInfoPageBinding
    private lateinit var sharedPref: SharedPreferences
    lateinit var userFullName: String

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPersonInfoPageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.personal_information)
        binding.titleBar.text = "$userFullName - $activityName"
        val userEmail = sharedPref.getString("user_email", "NA")
        val userPhone = sharedPref.getString("user_contact", "NA")
        binding.textemail.text = userEmail
        binding.textMobileNumbar.text = userPhone
        applyInsetPadding(this, binding.root)
        setThemeBackground(this, binding.llBasicInformation)
        setThemeBackground(this, binding.llContact)

        // Initially disable EditTexts
        disableEditTexts()
        binding.btnSubmit.visibility = View.GONE

        binding.imgArrow.setOnClickListener { finish() }

        // Enable on edit icon click
        binding.imageViewEdit.setOnClickListener {
            enableEditTexts()
            binding.btnSubmit.visibility = View.VISIBLE
        }

        // Handle submit click
        binding.btnSubmit.setOnClickListener {
            val address = binding.textAddress.text.toString().trim()
            val city = binding.textCity.text.toString().trim()
            val state = binding.textState.text.toString().trim()
            val pincode = binding.textPinCode.text.toString().trim()

            var hasError = false
            if (address.isEmpty()) {
                binding.textAddress.error = "address is required"
                hasError = true
            }

            if (city.isEmpty()) {
                binding.textCity.error = "city is required"
                hasError = true
            }

            if (state.isEmpty()) {
                binding.textState.error = "state is required"
                hasError = true
            }

            if (pincode.isEmpty()) {
                binding.textPinCode.error = "pin-code is required"
                hasError = true
            }

            if (!hasError) {
                updateProfileDetails(address, city, state, pincode)
            }
        }

        fetchProfileDetails()
    }

    private fun updateProfileDetails(address: String, city: String, state: String, pincode: String) {
        val addressMap = mapOf(
            "address" to address,
            "city" to city,
            "state" to state,
            "pincode" to pincode
        )

        val token = sharedPref.getString("auth_token", "") ?: ""
        val bearerToken = "Bearer $token"

        lifecycleScope.launch {
            try {
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@PersonInfoPageActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.uploading),
                    apiCall = {
                        ApiClient.apiService.updateAddress(bearerToken, addressMap)
                    },
                    onSuccess = { response ->
                        Toast.makeText(this@PersonInfoPageActivity, response.message ?: "Address updated successfully", Toast.LENGTH_SHORT).show()
                        disableEditTexts()
                        binding.btnSubmit.visibility = View.GONE
                    },
                    onError = { error ->
                        logAndToast(
                            this@PersonInfoPageActivity,
                            "EC025",
                            "PersonInfoPageActivity",
                            "updateAddress",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                logAndToast(
                    this@PersonInfoPageActivity,
                    "EC025",
                    "PersonInfoPageActivity",
                    "updateAddress",
                    e
                )
            }
        }
    }

    private fun fetchProfileDetails() {
        if (!checkNetworkAndShowMessage(this)) return

        val token = sharedPref.getString("auth_token", "") ?: ""
        val bearerToken = "Bearer $token"

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getProfileDetails(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@PersonInfoPageActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val data = response.data

                        binding.textJoiningDate.setText(data.joiningDate.takeIf { it.isNotBlank() } ?: "NA")
                        binding.textDob.setText(data.dateOfBirth.takeIf { it.isNotEmpty() } ?: "NA")
                        binding.textAddress.setText(data.address.takeIf { it.isNotEmpty() } ?: "NA")
                        binding.textCity.setText(data.city.takeIf { it.isNotBlank() } ?: "NA")
                        binding.textState.setText(data.state.takeIf { it.isNotBlank() } ?: "NA")
                        binding.textPinCode.setText(data.pincode.takeIf { it.isNotBlank() } ?: "NA")
                        binding.textGender.setText(data.gender.takeIf { it.isNotBlank() } ?: "NA")
                        binding.textLeaveBalance.setText(data.leaveBalance.toString())
                    },
                    onError = { error ->
                        UtilsMethods.AppLogger.logAndToast(
                            this@PersonInfoPageActivity,
                            "EC041",
                            "PersonInfoPageActivity",
                            "fetchProfileDetails",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                UtilsMethods.AppLogger.logAndToast(
                    this@PersonInfoPageActivity,
                    "EC042",
                    "PersonInfoPageActivity",
                    "fetchProfileDetails",
                    e
                )
            }
        }
    }


    private fun disableEditTexts() {
        binding.textAddress.isEnabled = false
        binding.textCity.isEnabled = false
        binding.textState.isEnabled = false
        binding.textPinCode.isEnabled = false
    }

    private fun enableEditTexts() {
        binding.textAddress.isEnabled = true
        binding.textCity.isEnabled = true
        binding.textState.isEnabled = true
        binding.textPinCode.isEnabled=true
        }
}