package com.harshal.upzyne.activity.settingMenu

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityOfficeAssetsBinding
import com.harshal.upzyne.model.SettingModel
import kotlinx.coroutines.launch

class OfficeAssetsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOfficeAssetsBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private lateinit var userFullName: String

    private var assetList: List<SettingModel.AssetItem> = emptyList()
    private var currentIndex = 0

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOfficeAssetsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "")}"
        userFullName = sharedPref.getString("user_fname", "").toString()

        setThemeBackground(this, binding.llCard)
        binding.titleBar.text = "$userFullName - ${getString(R.string.office_assets)}"
        binding.imgArrow.setOnClickListener { finish() }

        fetchAllAssets()

        binding.btnNext.setOnClickListener {
            if (currentIndex < assetList.size - 1) {
                currentIndex++
                showAssetInfo(currentIndex)
                highlightButton(binding.btnNext)
            }
        }

        binding.btndone.setOnClickListener {
            if (currentIndex > 0) {
                currentIndex--
                showAssetInfo(currentIndex)
                highlightButton(binding.btndone)
            }
        }
    }

    private fun fetchAllAssets() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getTeamAssets(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@OfficeAssetsActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.loading),
                    apiCall = { call },
                    onSuccess = { response ->
                        if (!response.data.isNullOrEmpty()) {
                            assetList = response.data ?: emptyList()
                            //currentIndex = 0

                            // Show content
                            binding.scrollView.visibility = View.VISIBLE
                            binding.bottomButtons.visibility = View.VISIBLE
                            binding.emptyState.visibility = View.GONE

                            showAssetInfo(currentIndex)
                        } else {
                            // No data found
                            binding.scrollView.visibility = View.GONE
                            binding.bottomButtons.visibility = View.GONE
                            binding.emptyState.visibility = View.VISIBLE
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@OfficeAssetsActivity,
                            "EC045",
                            "OfficeAssetsActivity",
                            "fetchAllAssets",
                            Exception(error)
                        )

                        // Show empty state on error
                        binding.scrollView.visibility = View.GONE
                        binding.bottomButtons.visibility = View.GONE
                        binding.emptyState.visibility = View.VISIBLE
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@OfficeAssetsActivity,
                    "EC046",
                    "OfficeAssetsActivity",
                    "fetchAllAssets",
                    e
                )

                // Show empty state on error
                binding.scrollView.visibility = View.GONE
                binding.bottomButtons.visibility = View.GONE
                binding.emptyState.visibility = View.VISIBLE
            }
        }
    }

    private fun showAssetInfo(index: Int) {
        val asset = assetList.getOrNull(index)
        if (asset != null) {
            binding.etBrand.setText(asset.brandname)
            binding.etAssetName.setText(asset.assetname)
            binding.etBuyingDate.setText(asset.buyingdate)
            binding.etReceivedOn.setText(asset.receivedon)


            val imagePath = asset.imageurl ?: ""
            val imageUrl = "${sharedPref.getString("base_url", "")}${imagePath.trimStart('/')}"
            Glide.with(this)
                .load(imageUrl)
                .error(R.drawable.noimage)
                .into(binding.imgAssetPreview)

            // Button visibility logic
            when (index) {
                0 -> {
                    binding.btndone.visibility = View.GONE
                    binding.btnNext.visibility = View.VISIBLE
                }
                assetList.size - 1 -> {
                    binding.btndone.visibility = View.VISIBLE
                    binding.btnNext.visibility = View.GONE
                }
                else -> {
                    binding.btndone.visibility = View.VISIBLE
                    binding.btnNext.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun highlightButton(lastClickedButton: AppCompatButton) {
        // Always keep both buttons highlighted (or modify as per design)
        binding.btnNext.background = ContextCompat.getDrawable(this, R.drawable.shape_color_btn)
        binding.btndone.background = ContextCompat.getDrawable(this, R.drawable.shape_color_btn)

        binding.btnNext.setTextColor(ContextCompat.getColor(this, R.color.white))
        binding.btndone.setTextColor(ContextCompat.getColor(this, R.color.white))
    }
}