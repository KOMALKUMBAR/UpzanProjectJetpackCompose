package com.harshal.upzyne

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import com.harshal.upzyne.UtilsMethods.getErrorAlertDialog

enum class NetworkQuality {
    NONE, WEAK, GOOD, GREAT
}

fun getNetworkQuality(context: Context): NetworkQuality {
    val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val network = connectivityManager.activeNetwork ?: return NetworkQuality.NONE
        val capabilities =
            connectivityManager.getNetworkCapabilities(network) ?: return NetworkQuality.NONE

        return when {
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                val rssi = wifiManager.connectionInfo.rssi
                when {
                    rssi >= -50 -> NetworkQuality.GREAT
                    rssi >= -70 -> NetworkQuality.GOOD
                    rssi >= -85 -> NetworkQuality.WEAK
                    else -> NetworkQuality.WEAK
                }
            }

            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                return if (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && capabilities.hasCapability(
                        NetworkCapabilities.NET_CAPABILITY_VALIDATED
                    )
                ) {
                    NetworkQuality.GOOD
                } else {
                    NetworkQuality.WEAK
                }
            }
            else -> NetworkQuality.NONE
        }
    } else {
        @Suppress("DEPRECATION") val activeNetworkInfo =
            connectivityManager.activeNetworkInfo ?: return NetworkQuality.NONE
        @Suppress("DEPRECATION") return when (activeNetworkInfo.type) {
            ConnectivityManager.TYPE_WIFI -> {
                val rssi = wifiManager.connectionInfo.rssi
                when {
                    rssi >= -50 -> NetworkQuality.GREAT
                    rssi >= -70 -> NetworkQuality.GOOD
                    rssi >= -85 -> NetworkQuality.WEAK
                    else -> NetworkQuality.WEAK
                }
            }

            ConnectivityManager.TYPE_MOBILE -> {
                if (activeNetworkInfo.isConnected) NetworkQuality.GOOD else NetworkQuality.WEAK
            }

            else -> NetworkQuality.NONE
        }
    }
}

fun checkNetworkAndShowMessage(context: Context): Boolean {
    val quality = getNetworkQuality(context)

    return when (quality) {
        NetworkQuality.NONE -> {
            getErrorAlertDialog(context, context.getString(R.string.no_internet))
            false
        }

        NetworkQuality.WEAK -> {
            getErrorAlertDialog(context, context.getString(R.string.slow_internet))
            false
        }

        NetworkQuality.GOOD, NetworkQuality.GREAT -> {
            true
        }
    }
}