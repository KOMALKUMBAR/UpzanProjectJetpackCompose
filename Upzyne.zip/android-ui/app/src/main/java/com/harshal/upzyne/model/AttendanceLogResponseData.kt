package com.harshal.upzyne.model

data class AttendanceLogResponseData(
    val `data`: List<AttendanceLogResponse>
)

data class AttendanceLogResponse(
    val attendancedate: String,
    val daytype: String,
    val logintime: String,
    val logouttime: String
)