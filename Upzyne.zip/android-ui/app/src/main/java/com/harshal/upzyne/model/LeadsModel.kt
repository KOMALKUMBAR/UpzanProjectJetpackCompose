package com.harshal.upzyne.model

import java.io.Serializable

import com.google.gson.annotations.SerializedName

class LeadsModel {

    data class LeadsModelDataClasss(
        val data: List<LeadData>
    ) {
        data class LeadData(
            val name: String,
            val email: String,
            val phonenumber: String,
            val alternatephone: String,
            val leadscore: Int,
            val leadid: Int,
            val timeago: String,
            val sourcebadge: String,
            val programme: String,
            val leaddate: String,
            val totalcount: Int,
            val statuscolor: String,
            val leadscorecolor: String,
            val leadsourcename: String,
            val statuslabel: String,
            val isotpverified: Boolean,
            val programmeCountry: String,
            val description: String,
            val salespitch: String,
            val usp: String,
            val upsellpitch: String,
            val percentage_score: String
        )
    }
    /**komal kumbar Lead Model**/
    data class EmailTemplate(
        val userid: Int,
        val createdat: String,
        val updatedat: String,
        val isactive: Boolean,
        val emailattachments: String,
        val emailbody: String,
        val emailsubject: String,
        val emailsubjectimage: String?, // Optional
        val templateid: Int,
        val templatename: String
    )
    data class GenericResponse(
        val emailSent: Boolean,
        val result: String?,
        val emailStatus: String?,
        val message: String?
    )
    data class  SetReminderResponse(
        val  result: Int,
        val message: String
    )
    //SendMessage Data Class
    data class SmsTemplate(
        val templateid: Int,
        val smstext: String,
        val isactive: Boolean,
        val createdat: String,
        val updatedat: String,
        val tenantid: Int,
        val createdby: Int,
        val updatedby: Int,
        val userid: Int?
    )

    data class SmsPostResponse(
        val result: String,
        val message: String
    )

    data class SmsPostRequest(
        val leadid: Long,
        val mobileno: String,
        val smstext: String,
        val messagetype: String,
        val status: String
    )

    data class LeadsScoreResponse(
        val data: List<LeadScoreData>
    ) {
        data class LeadScoreData(
            val leadid: Int,
            val percentage_score: Int,
            val suggestions: String,
            val raw_score: Int,
            val breakdown: String
        )
    }
 /**Lead Infomation Data Class **/
/* data class LeadInformationUpdateRequest(
     val leadId: Int,
     val firstName: String,
     val lastName: String,
     val email: String,
     val mobileNumber: String,
     val altMobileNumber: String,
     val productId: Int,
     val address1: String,
     val city: String,
     val state: String,
     val postalCode: String,
     val country: String,
     val countryCode: String
 )

    data class LeadInformationPostResponse(
        val success: Boolean
    )
   */
 data class IdName(
     val id: Int,
     val name: String
 )

    data class DropdownsResponse(
        val products: List<IdName>?,
        val lead_sources: List<IdName>?,
        val lead_statuses: List<IdName>?,
        val lead_types: List<IdName>?
    )

    data class LeadDetailsResponse(
        val leadId: Int,
        val firstName: String?,
        val lastName: String?,
        val email: String?,
        val mobileNumber: String?,
        val altMobileNumber: String?,
        val address1: String?,
        val city: String?,
        val state: String?,
        val postalCode: String?,
        val country: String?,
        val countryCode: String?,
        val interestedProgram: String?
    )

    data class UpdateLeadDetailsRequest(
        val leadId: Int,
        val firstName: String,
        val lastName: String,
        val email: String,
        val mobileNumber: String,
        val altMobileNumber: String?,
        val address1: String?,
        val city: String?,
        val state: String?,
        val postalCode: String?,
        val country: String?,
        val countryCode: String?,
        // spinnerThree -> lead_types
        val leadTypeId: Int?,
        val leadTypeName: String?
    )

    data class BaseResponse(
        val success: Boolean,
        val message: String?
    )


    /** LeadSummaryResponse **/


    data class LeadSummaryResponse(
        val data: LeadSummaryData?
    ) : Serializable

    data class LeadSummaryData(
        val lead_info: LeadInfo?,
        val response: LeadResponse?,
        val documents: List<DocumentItem>?,
        val assets: Assets?,
        val follow_up: FollowUp?
    ) : Serializable

    data class LeadInfo(
        val leadId: Int,
        val name: String?,
        val email: String?,
        val phone: String?,
        val status: String?,
        val product: String?,
        val joined_on: String?,
        val engaged_hrs: Double? = 0.0
    ) : Serializable

    data class LeadResponse(
        val percentage: Double? = 0.0,
        val total_interactions: Int? = 0
    ) : Serializable

    data class DocumentItem(
        val id: Int? = null,
        val title: String? = null,
        val documenturl: String? = null
    ) : Serializable

    data class Assets(
        val call_recordings: Int? = 0
    ) : Serializable

    data class FollowUp(
        val next_followup: String? = null,
        val pending_tasks: List<PendingTask>? = emptyList(),
        val ai_suggestion: String? = null,
        val reminder_set_by: String? = null
    ) : Serializable

    data class PendingTask(
        val text: String? = null,
        val type: String? = null,
        val set_by: String? = null
    ) : Serializable

/**LeadSummy TimeLine Data Model**/
    data class LeadTimelineResponse(
        val data: List<TimelineItem>
    )

    data class TimelineItem(
        val type: String,
        val title: String,
        val message: String,
        val time: String,
        val by: String?


    )
    /** Lead Communication data Model**/

    data class CommunicationResponse(
    val leadid: Int,
    val call_vibes: List<CallVibe>,
    val whisper_wire: List<WhisperWire>,
    val total_call_count: Int,
    val total_communications: Int,
    val latest_call_sentiment: String
    )

    data class CallVibe(
        val id: Int,
        val audiourl: String,
        val actorname: String,
        val createdat: String,
        val direction: String?,
        val vibeemoji: String?,
        val vibelabel: String?,
        val vibebgcolor: String?,
        val vibetextcolor: String?,
        val durationseconds: Int
    )

    data class WhisperWire(
        val id: Int,
        val preview: String?,
        val itemtype: String,
        val actorname: String,
        val createdat: String,
        val direction: String?,
        val rawchannel: String,
        val sentimentscore: String,
        val preferredcontactmethod: String
    )



    /**harshal sir**/
    data class LeadsModelCallRecordingRequest(
        val data: CallRecordingDetails
    ) {
        data class CallRecordingDetails(
            val leadId: Long,
            val mobileNo: String,
            val callDuration: String,
            val callDate: String,
            val callType: String
        )
    }

    data class CallRecordingResponse(
        val feedbackCode: String,
        val recordId: String
    )

    data class LeadsModelGetCallDetails(
        val data: callrecord
    ) {
        data class callrecord(
            val calldate: String,
            val callduration: String,
            val calltype: String,
            val createdat: String,
            val createdby: Int,
            val filename: String,
            val firstname: String,
            val lastname: String,
            val leadid: Long,
            val leadstatusname: String,
            val mobileno: String,
            val phonenumber: String,
            val recordid: Int,
            val tenantid: Int,
            val updatedat: String,
            val updatedby: Int,
            val uploadeddate: String,
            val userid: Int
        )
    }

    data class getLeadCounselorList(
        val data: CounselorData
    )

    data class CounselorData(
        @SerializedName("total_users")
        val totalUsers: Int,
        val users: List<counselorList>
    )

    data class counselorList(
        val userid: Int,
        val name: String,
        val designation: String,
        val departmentname: String,
        val profileurl: String?,  // nullable since some values are null or empty
        val availability: String,
        val totalreallocations: Int
    )

    data class getLeadStatus(
        val data: ArrayList<leadStatus>
    ) {
        data class leadStatus(
            val hexcolor: String,
            val leadstatusid: Int,
            val leadstatusname: String
        )
    }

    data class updateLeadStatus(
        val message: String,
    )

    data class updateLeadRemarkRequest(
        val leadid: Long?,
        val remarks: String
    )

    data class updateLeadRemarkResponse(
        val message: String?
    )

    data class ReassignLeadRequest(
        val leadId: Long,
        val newUserId: Int,
        val reason: String,
        val notifyLead: Boolean,
        val repeatReminder: Boolean,
    )

    data class ReassignLeadResponse(
        val data: ReassignLead
    ) {
        data class ReassignLead(
            val allocationId: String,
            val message: String,
            val result: String
        )
    }

    data class FilterResponse(
        val lead_score: List<ScoreRange>,
        val tags: List<String>,
        val status: List<Status>,
        val country: List<Country>,
        val course_type: List<CourseType>,
        val followup_due: List<String>,
        val created_date: List<String>
    )

    data class ScoreRange(
        val label: String,
        val min: Int,
        val max: Int
    )

    data class Status(
        val leadstatusid: Int,
        val leadstatusname: String
    )

    data class Country(
        val countryid: Int,
        val countryname: String
    )

    data class CourseType(
        val productid: Int,
        val productname: String
    )


}