package com.harshal.upzyne.activity.settingMenu

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.UtilsMethods.togglePasswordVisibility
import com.harshal.upzyne.databinding.ActivityChangePasswordBinding
import com.harshal.upzyne.databinding.ActivityPasswordUpdateDialogBinding
import com.harshal.upzyne.model.SettingModel.ChangePasswordRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class ChangePasswordActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChangePasswordBinding
    private lateinit var sharedPref: SharedPreferences
    private val job = Job()
    private lateinit var userFullName: String
    private val coroutineScope = CoroutineScope(Dispatchers.Main + job)

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChangePasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)

        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.change_password)
        binding.titleBar.text = "$userFullName - $activityName"

        setThemeBackground(this, binding.rootLayout)

        binding.rootLayout.setOnClickListener {
            currentFocus?.let { view ->
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(view.windowToken, 0)
                view.clearFocus()
            }
        }

        binding.imgArrowBack.setOnClickListener { finish() }

        binding.btnUpdatePassword.setOnClickListener {
            callChangePasswordApi()
        }
        var isNewVisible = false
        var isConfirmVisible = false
        var isChangeVisible = false

        removeSpacesOnTyping(binding.etCurrentPassword)
        removeSpacesOnTyping(binding.etNewPassword)
        removeSpacesOnTyping(binding.etConfirmPassword)

        binding.ivToggleNewPassword.setOnClickListener {
            isNewVisible = togglePasswordVisibility(
                binding.etNewPassword,
                binding.ivToggleNewPassword,
                isNewVisible
            )
        }

        binding.ivToggleConfirmPassword.setOnClickListener {
            isConfirmVisible = togglePasswordVisibility(
                binding.etConfirmPassword,
                binding.ivToggleConfirmPassword,
                isConfirmVisible
            )
        }

        binding.ivTogglePassword.setOnClickListener {
            isChangeVisible = togglePasswordVisibility(
                binding.etCurrentPassword,
                binding.ivTogglePassword,
                isChangeVisible
            )
        }
    }

    //remove White Spaces code
    private fun removeSpacesOnTyping(editText: android.widget.EditText) {
        editText.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                val original = s.toString()
                val filtered = original.replace("\\s".toRegex(), "")
                if (original != filtered) {
                    editText.setText(filtered)
                    editText.setSelection(filtered.length)
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun callChangePasswordApi() {
        val oldPassword = binding.etCurrentPassword.text.toString().trim()
        val newPassword = binding.etNewPassword.text.toString().trim()
        val confirmPassword = binding.etConfirmPassword.text.toString().trim()

        if (oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "all fields are required", Toast.LENGTH_SHORT).show()
            return
        }

        if (newPassword != confirmPassword) {
            binding.etConfirmPassword.error = "passwords do not match"
            Toast.makeText(this, "passwords do not match", Toast.LENGTH_SHORT).show()
            return
        }

        val token = "Bearer ${sharedPref.getString("auth_token", "")}"

        val request = ChangePasswordRequest(
            oldPasswordHash = oldPassword,
            newPasswordHash = newPassword
        )

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.changePassword(token, request)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ChangePasswordActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.updating_password),
                    apiCall = { call },
                    onSuccess = { response ->
                        if (response.error.isNullOrEmpty()) {
                            showSuccessDialog()
                        } else {
                            if (response.error.contains("incorrect", true) ||
                                response.error.contains("wrong", true) ||
                                response.error.contains("invalid", true)
                            ) {
                                binding.etCurrentPassword.error = getString(R.string.incorrect_current_password)
                                Toast.makeText(
                                    this@ChangePasswordActivity,
                                    getString(R.string.enter_correct_current_password),
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                Toast.makeText(
                                    this@ChangePasswordActivity,
                                    response.error,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@ChangePasswordActivity,
                            "EC050",
                            "ChangePasswordActivity",
                            "callChangePasswordApi",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@ChangePasswordActivity,
                    "EC051",
                    "ChangePasswordActivity",
                    "callChangePasswordApi",
                    e
                )
            }
        }
    }

    private fun showSuccessDialog() {
        val dialogBinding = ActivityPasswordUpdateDialogBinding.inflate(layoutInflater)
        val dialog = BottomSheetDialog(this)
        dialog.setContentView(dialogBinding.root)

        dialogBinding.btnYesupdate.setOnClickListener {
            dialog.dismiss()
            finish()
        }

        dialog.setCancelable(false)
        dialog.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
    }
}