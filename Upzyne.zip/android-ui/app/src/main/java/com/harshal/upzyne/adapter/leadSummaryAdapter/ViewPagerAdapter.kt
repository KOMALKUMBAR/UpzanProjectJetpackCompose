package com.harshal.upzyne.adapter.leadSummaryAdapter

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.harshal.upzyne.fragment.leadfragment.CommunicationFragment
import com.harshal.upzyne.fragment.leadfragment.NotesFragment
import com.harshal.upzyne.fragment.leadfragment.SummaryFragment
import com.harshal.upzyne.fragment.leadfragment.TimelineFragment
import com.harshal.upzyne.model.LeadsModel

class ViewPagerAdapter(
    activity: FragmentActivity,
    private val leadSummaryData: LeadsModel.LeadSummaryData,
    private val leadId: Int,
    private val leadName: String // <-- add this
// <-- added this
) : FragmentStateAdapter(activity) {

    override fun getItemCount(): Int = 4

    override fun createFragment(position: Int): Fragment {
        val fragment: Fragment = when (position) {
            0 -> SummaryFragment()
            1 -> CommunicationFragment()
            2 -> TimelineFragment()
            3 -> NotesFragment()
            else -> SummaryFragment()
        }

        fragment.arguments = Bundle().apply {
            putSerializable("lead_summary_data", leadSummaryData)
            putInt("lead_id", leadId)
            putString("lead_name", leadName) // <-- now using the leadId from constructor
        }

        return fragment
    }
}

