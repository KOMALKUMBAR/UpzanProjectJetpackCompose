package com.harshal.upzyne.adapter.leadSummaryAdapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.databinding.CommunicationCallVibesItemBinding
import com.harshal.upzyne.model.LeadsModel
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class CommunicationCallVibesAdapter(
    private val context: Context,
    private val items: MutableList<LeadsModel.CallVibe>
) : RecyclerView.Adapter<CommunicationCallVibesAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: CommunicationCallVibesItemBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = CommunicationCallVibesItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        with(holder.binding) {
            // Set Actor Name
            actorname.text = item.actorname

            // Set CreatedAt date/time (format nicely)
            // here callCreatedAt is a LinearLayout -> access first TextView inside it
            val dateTextView = callCreatedAt.getChildAt(0)
            if (dateTextView is android.widget.TextView) {
                dateTextView.text = formatDateTime(item.createdat)
            }

            // Audio seek bar - keep audiourl in tag
            audioSeekBar.progress = 0
            audioSeekBar.tag = item.audiourl

            // Store id in root tag (if needed)
            root.tag = item.id
        }
    }

    override fun getItemCount() = items.size

    fun updateData(newList: List<LeadsModel.CallVibe>) {
        items.clear()
        items.addAll(newList)
        notifyDataSetChanged()
    }
    private fun formatDateTime(dateTimeString: String): String {
        return try {
            val odt = OffsetDateTime.parse(dateTimeString)
            val formatter =
                DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a", Locale.getDefault())
            odt.format(formatter)
        } catch (e: Exception) {
            dateTimeString // fallback if parsing fails
        }
    }
}
