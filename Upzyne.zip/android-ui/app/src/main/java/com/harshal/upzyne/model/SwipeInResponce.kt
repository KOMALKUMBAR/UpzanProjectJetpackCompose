package com.harshal.upzyne.model

data class SwipeInResponce(val data: String)
