package com.harshal.upzyne.activity.leadMenu

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.provider.CalendarContract
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.core.view.WindowCompat
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import com.google.gson.JsonObject
import com.harshal.upzyne.*
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ActivitySetReminderBinding
import com.harshal.upzyne.databinding.ItemLeadProfileLayoutBinding
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.text.SimpleDateFormat
import java.util.*

class SetReminderActivity : AppCompatActivity() {

    // ViewBinding and global variables
    private lateinit var binding: ActivitySetReminderBinding
    private val calendar = Calendar.getInstance()
    private lateinit var userFullName: String
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private lateinit var phoneNumber: String
    private var selectedReminderType: String = "call"  // Default reminder type

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        binding = ActivitySetReminderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Setup UI theme and background
        setThemeBackground(this, binding.lay)

        // Load user info from SharedPreferences
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "").toString()
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "") ?: ""}"
        val activityName = getString(R.string.set_reminder)
        binding.titleText.text = "$userFullName - $activityName"

        // Load lead profile layout into container
        setupLeadProfileLayout()

        // Setup click listeners for UI elements
        setupClickListeners()

        // Setup validation on input fields
        setupValidation()
    }

    /** Populates the lead's profile info in top card layout **/
    private fun setupLeadProfileLayout() {
        val itemLeadBinding = ItemLeadProfileLayoutBinding.inflate(
            LayoutInflater.from(this),
            binding.leadContainer,
            false
        )
        binding.leadContainer.addView(itemLeadBinding.root)

        // Extract lead info from Intent extras
        val leadStatusColor = intent.getStringExtra("lead_statuscolor") ?: "#3E4A59"
        val leadVerified = intent.getBooleanExtra("lead_verified", false)
        phoneNumber = intent.getStringExtra("lead_phone") ?: "Unknown Number"

        // Set values
        itemLeadBinding.userName.text = intent.getStringExtra("lead_name")
        itemLeadBinding.userEmail.text = intent.getStringExtra("lead_email")
        itemLeadBinding.userPhone.text = phoneNumber
        itemLeadBinding.engagedDate.text = "engaged: ${intent.getStringExtra("lead_timeago")}"
        itemLeadBinding.joinedDate.text = "joinedDate: ${intent.getStringExtra("lead_leaddate")}"
        itemLeadBinding.course.text = intent.getStringExtra("lead_programme")
        itemLeadBinding.statusIcon.text = intent.getStringExtra("lead_sourcebadge")
        itemLeadBinding.tvOtpVerification.visibility = if (leadVerified) View.VISIBLE else View.GONE


        // Apply dynamic color to lead label
        val labelDrawable = itemLeadBinding.labelNewLead.background?.mutate()
        val colorWithAlpha = (leadStatusColor.toColorInt() and 0x00FFFFFF) or (0x30 shl 24)
        labelDrawable?.setColorFilter(colorWithAlpha, PorterDuff.Mode.SRC_ATOP)
        itemLeadBinding.labelNewLead.background = labelDrawable
        itemLeadBinding.labelNewLead.setTextColor(leadStatusColor.toColorInt())
        itemLeadBinding.labelNewLead.text = intent.getStringExtra("lead_source") ?: ""

        // Left border color
        val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.left_glass)
        if (backgroundDrawable is LayerDrawable) {
            val leftBorder = backgroundDrawable.findDrawableByLayerId(R.id.left_border)
            if (leftBorder is GradientDrawable) {
                leftBorder.setColor(leadStatusColor.toColorInt())
            }
            itemLeadBinding.itemLead.background = backgroundDrawable
        }
    }

    /** Configures user interaction: date/time pickers, buttons, reminder type switches **/
    private fun setupClickListeners() {
        // Back button
        binding.imgArrow.setOnClickListener { finish() }

        // Date picker
        binding.dateField.setOnClickListener {
            binding.dateField.error = null
            val datePicker = DatePickerDialog(
                this,
                { _, y, m, d ->
                    calendar.set(y, m, d)
                    val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
                    binding.dateField.text = dateFormat.format(calendar.time)
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
            datePicker.setOnShowListener {
                datePicker.getButton(DialogInterface.BUTTON_POSITIVE)?.setTextColor(Color.BLACK)
                datePicker.getButton(DialogInterface.BUTTON_NEGATIVE)?.setTextColor(Color.BLACK)
            }
            datePicker.show()
        }

        // Time picker
        binding.timeField.setOnClickListener {
            binding.timeField.error = null
            val timePickerDialog = TimePickerDialog(
                this,
                { _, h, m ->
                    calendar.set(Calendar.HOUR_OF_DAY, h)
                    calendar.set(Calendar.MINUTE, m)
                    val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
                    binding.timeField.text = timeFormat.format(calendar.time)
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                false
            )
            timePickerDialog.setOnShowListener {
                timePickerDialog.getButton(DialogInterface.BUTTON_POSITIVE)?.setTextColor(Color.BLACK)
                timePickerDialog.getButton(DialogInterface.BUTTON_NEGATIVE)?.setTextColor(Color.BLACK)
            }
            timePickerDialog.show()
        }

        // Reminder type selection (call, whatsapp, email)
        val selectedDrawable = ContextCompat.getDrawable(this, R.drawable.shape_purple)
        val defaultDrawable = ContextCompat.getDrawable(this, R.drawable.white_rectangle_roundcr)

        binding.callEditText.setOnClickListener {
            selectedReminderType = "call"
            binding.callEditText.background = selectedDrawable
            binding.whatsappEditText.background = defaultDrawable
            binding.emailEditText.background = defaultDrawable
        }

        binding.whatsappEditText.setOnClickListener {
            selectedReminderType = "whatsapp"
            binding.callEditText.background = defaultDrawable
            binding.whatsappEditText.background = selectedDrawable
            binding.emailEditText.background = defaultDrawable
        }

        binding.emailEditText.setOnClickListener {
            selectedReminderType = "email"
            binding.callEditText.background = defaultDrawable
            binding.whatsappEditText.background = defaultDrawable
            binding.emailEditText.background = selectedDrawable
        }

        // Google Calendar toggle
        binding.googleswitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.googleswitch.thumbTintList = ColorStateList.valueOf(Color.BLUE)
                binding.googleswitch.trackTintList = ColorStateList.valueOf(Color.BLUE)
                addEventToGoogleCalendar()
            } else {
                binding.googleswitch.thumbTintList = ColorStateList.valueOf(Color.GRAY)
                binding.googleswitch.trackTintList = ColorStateList.valueOf(Color.GRAY)
            }
        }

        // Submit button
        binding.btnsetReminder.setOnClickListener { sendSetReminder() }
    }

    /** Adds the event to Google Calendar app using Intent **/
    private fun addEventToGoogleCalendar() {
        val intent = Intent(Intent.ACTION_INSERT).apply {
            type = "vnd.android.cursor.item/event"
            putExtra(CalendarContract.Events.TITLE, "Follow-up with $phoneNumber")
            putExtra(CalendarContract.Events.DESCRIPTION, "Reminder set via Upzyne app")
            putExtra(CalendarContract.Events.EVENT_LOCATION, "Phone/WhatsApp/Email")
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, calendar.timeInMillis)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, calendar.timeInMillis + 30 * 60 * 1000)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Google Calendar not found", Toast.LENGTH_SHORT).show()
        }
    }

    /** Sends API call to backend to create reminder **/
    private fun sendSetReminder() {
        if (!checkNetworkAndShowMessage(this)) return

        val leadId = intent.getIntExtra("lead_id", 0)
        val remindertextStr = binding.setReminderTempl.text.toString().trim()
        val date = binding.dateField.text.toString().trim()
        val time = binding.timeField.text.toString().trim()
        val remindertimeStr = "$date $time"
        val notesStr = binding.notes.text.toString().trim()

        // Input validations
        var isValid = true
        if (leadId == 0) {
            binding.callEditText.error = "Enter valid Lead ID"
            return
        }
        if (remindertextStr.isEmpty()) {
            binding.setReminderTempl.error = "Enter Reminder Text"
            isValid = false
        }
        if (date.isEmpty()) {
            binding.dateField.error = "Select Date"
            return
        }
        if (time.isEmpty()) {
            binding.timeField.error = "Select Time"
            return
        }
        if (notesStr.isEmpty()) {
            binding.notes.error = "Enter Note"
            return
        }
        if (!isValid) return

        // Prepare JSON payload
        val jsonObject = JsonObject().apply {
            addProperty("leadid", leadId.toString())
            addProperty("remindertext", remindertextStr)
            addProperty("remindertime", remindertimeStr)
            addProperty("remindertype", selectedReminderType)
            addProperty("notes", notesStr)
            addProperty("isrepeat", "true")
            addProperty("addtocalendar", "true")
        }

        // Launch API call
        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.setReminder(bearerToken, jsonObject)
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@SetReminderActivity,
                    showLoading = true,
                    loadingMessage = "Sending reminder...",
                    apiCall = { call },
                    onSuccess = { response ->
                        val msg = response.body()?.message ?: "Reminder set successfully"
                        showCustomAlertDialog(this@SetReminderActivity, msg)
                    },
                    onError = { error ->
                        UtilsMethods.AppLogger.logAndToast(
                            this@SetReminderActivity,
                            "EC888",
                            "SetReminderActivity",
                            "sendSetReminder",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                UtilsMethods.AppLogger.logAndToast(
                    this@SetReminderActivity,
                    "EC999",
                    "SetReminderActivity",
                    "sendSetReminder",
                    e
                )
            }
        }
    }

    /** Shows confirmation alert dialog after reminder is set **/
    private fun showCustomAlertDialog(context: Context, message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Successfully")
        builder.setMessage(message)
        builder.setCancelable(false)
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
            clearForm()
        }

        val dialog = builder.create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.BLACK)
    }

    /** Clears all form fields after successful submission **/
    private fun clearForm() {
        binding.emailEditText.text?.clear()
        binding.setReminderTempl.text?.clear()
        binding.dateField.text = ""
        binding.timeField.text = ""
        binding.notes.text?.clear()

        val defaultDrawable = ContextCompat.getDrawable(this, R.drawable.white_rectangle_roundcr)
        binding.callEditText.background = defaultDrawable
        binding.whatsappEditText.background = defaultDrawable
        binding.emailEditText.background = defaultDrawable
    }

    /** Removes error messages while typing **/
    private fun setupValidation() {
        clearErrorOnTyping(binding.callEditText)
        clearErrorOnTyping(binding.notes)
        clearErrorOnTyping(binding.setReminderTempl)
    }

    /** Clears error on typing in a specific field **/
    private fun clearErrorOnTyping(view: EditText) {
        view.addTextChangedListener { view.error = null }
    }
}
