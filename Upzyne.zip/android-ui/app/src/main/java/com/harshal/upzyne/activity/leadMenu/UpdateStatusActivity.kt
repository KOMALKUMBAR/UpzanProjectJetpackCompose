package com.harshal.upzyne.activity.leadMenu

import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods.getErrorAlertDialog
import com.harshal.upzyne.UtilsMethods.maskPhoneNumber
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.activity.leadMenu.OwnedLeadsActivity.Companion.bearerToken
import com.harshal.upzyne.activity.leadMenu.ReassignLeadActivity.Companion.baseUrl
import com.harshal.upzyne.databinding.ActivityUpdateStatusBinding
import com.harshal.upzyne.databinding.LayoutErrorAlertBinding
import com.harshal.upzyne.model.LeadsModel
import kotlinx.coroutines.launch
import kotlin.let

class UpdateStatusActivity : AppCompatActivity() {
    private lateinit var binding: ActivityUpdateStatusBinding
    private lateinit var userFullName: String
    private lateinit var sharedPref: SharedPreferences

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUpdateStatusBinding.inflate(layoutInflater)
        setContentView(binding.root)
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "") ?: ""
        baseUrl = sharedPref.getString("base_url", "") ?: ""
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "") ?: ""}"
        binding.titleText.text = "$userFullName - ${getString(R.string.update_lead_status)}"

        setThemeBackground(this, binding.scrollbar)

        val _leadStatusColor = intent.getStringExtra("lead_statuscolor")
        val drawable1 = binding.labelNewLead.background?.mutate()
        val colorWithAlpha = (_leadStatusColor!!.toColorInt() and 0x00FFFFFF) or (0x30 shl 24)
        drawable1?.setColorFilter(colorWithAlpha, PorterDuff.Mode.SRC_ATOP)
        binding.labelNewLead.background = drawable1
        binding.labelNewLead.setTextColor(_leadStatusColor.toColorInt())

        val backgroundDrawable = ContextCompat.getDrawable(this, R.drawable.left_glass)
        if (backgroundDrawable is LayerDrawable) {
            val leftBorder = backgroundDrawable.findDrawableByLayerId(R.id.left_border)
            if (leftBorder is GradientDrawable) {
                leftBorder.setColor(_leadStatusColor.toColorInt())
            }
            binding.itemLead.background = backgroundDrawable
        }

        val _leadId = intent.getLongExtra("lead_id", 0)
        val leadType = intent.getStringExtra("lead_source")
        val _leadSourceBadge = intent.getBooleanExtra("lead_verified", false)
        binding.tvOtpVerification.visibility = if (_leadSourceBadge) View.VISIBLE else View.GONE

        binding.userName.text = intent.getStringExtra("lead_name")
        binding.userEmail.text = intent.getStringExtra("lead_email")
        binding.userPhone.text = maskPhoneNumber(intent.getStringExtra("lead_phone")!!)
        binding.engagedDate.text = intent.getStringExtra("lead_timeago")
        binding.joinedDate.text = intent.getStringExtra("lead_leaddate")
        binding.course.text = intent.getStringExtra("lead_programme")
        binding.statusIcon.text = intent.getStringExtra("lead_sourcebadge")
        binding.labelNewLead.text = intent.getStringExtra("lead_source")

        binding.lay.setOnClickListener {
            currentFocus?.let { view ->
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(view.windowToken, 0)
                view.clearFocus()
            }
        }

        binding.imgArrow.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.updateStatus.setOnClickListener {
            lifecycleScope.launch {
                var isStatusUpdated = false
                var isRemarkUpdated = false
                val selectedItem = binding.spinnerCallStatus.selectedItem as LeadsModel.getLeadStatus.leadStatus
                val statusName = selectedItem.leadstatusname
                val statusId = selectedItem.leadstatusid
                val followUpNotes = binding.followUpNotes.text.toString()

                if (statusName != leadType) {
                    isStatusUpdated = updateLeadStatus(_leadId, statusId)
                    Log.d("isStatusUpdated", "$isStatusUpdated")
                }

                if (followUpNotes.isNotEmpty()) {
                    isRemarkUpdated = updateLeadRemark(_leadId, statusName)
                    Log.d("isRemarkUpdated", "$isRemarkUpdated")
                }

                if (isStatusUpdated || isRemarkUpdated) {
                    val binding = LayoutErrorAlertBinding.inflate(LayoutInflater.from(this@UpdateStatusActivity))
                    val dialog = AlertDialog.Builder(this@UpdateStatusActivity)
                        .setView(binding.root)
                        .setCancelable(false)
                        .create()
                    binding.tvError.text = getString(R.string.status_and_remark_updated_successfully)
                    binding.btnok.setOnClickListener {
                        dialog.dismiss()
                        onBackPressedDispatcher.onBackPressed()
                    }
                    dialog.show()
                } else {
                    getErrorAlertDialog(this@UpdateStatusActivity, getString(R.string.status_and_remark_updating_failed))
                }
            }
        }

        lifecycleScope.launch {
            val leadStatusList = fetchLeadStatus()
            leadStatusList?.let { list ->
                val adapter = object : ArrayAdapter<LeadsModel.getLeadStatus.leadStatus>(
                    this@UpdateStatusActivity,
                    R.layout.item_spinner_color,
                    list
                ) {
                    override fun getView(
                        position: Int,
                        convertView: View?,
                        parent: ViewGroup
                    ): View {
                        return createCustomView(position, convertView, parent)
                    }

                    override fun getDropDownView(
                        position: Int,
                        convertView: View?,
                        parent: ViewGroup
                    ): View {
                        return createCustomView(position, convertView, parent)
                    }

                    private fun createCustomView(
                        position: Int,
                        convertView: View?,
                        parent: ViewGroup
                    ): View {
                        val inflater = LayoutInflater.from(context)
                        val view = convertView ?: inflater.inflate(
                            R.layout.item_spinner_color,
                            parent,
                            false
                        )

                        val statusItem = getItem(position)
                        val colorIndicator = view.findViewById<View>(R.id.colorDot)
                        val statusName = view.findViewById<TextView>(R.id.spinnerViewName)

                        statusName.text = statusItem?.leadstatusname

                        // Parse and apply hex color to shape background
                        statusItem?.hexcolor?.let { hex ->
                            try {
                                val drawable =
                                    colorIndicator.background.mutate() as GradientDrawable
                                drawable.setColor(Color.parseColor(hex))
                            } catch (e: Exception) {
                                // Fallback to gray if invalid hex or casting fails
                                val drawable =
                                    colorIndicator.background.mutate() as? GradientDrawable
                                drawable?.setColor(Color.GRAY)
                            }
                        }
                        return view
                    }
                }

                binding.spinnerCallStatus.adapter = adapter

                // Set selected item based on existing status
                val selectedStatus = leadType
                val indexToSelect = list.indexOfFirst {
                    it.leadstatusname.equals(selectedStatus, ignoreCase = true)
                }
                if (indexToSelect >= 0) {
                    binding.spinnerCallStatus.setSelection(indexToSelect)
                }
            }
        }
    }

    private suspend fun updateLeadRemark(
        leadid: Long?,
        statusName: String
    ): Boolean {
        return try {
            val requestBody = LeadsModel.updateLeadRemarkRequest(
                leadid,
                statusName
            )

            val call = ApiClient.apiService.updateLeadRemark(bearerToken, requestBody)

            ApiRequestHandler.makeSuspendApiCall(
                context = this@UpdateStatusActivity,
                showLoading = true,
                loadingMessage = getString(R.string.uploading),
                apiCall = { call },
                onSuccess = { response ->
                    val result = response.body()
                    Log.d("updateLeadRemark", "$result")
                },
                onError = { error ->
                    Log.d("eeee", error)
                }
            )
            true
        } catch (e: Exception) {
            getErrorAlertDialog(this@UpdateStatusActivity, e.toString())
            false
        }
    }

    private suspend fun updateLeadStatus(leadId: Long?, statusId: Int): Boolean {
        return try {
            val call = ApiClient.apiService.updateLeadStatus(bearerToken, leadId, statusId)

            ApiRequestHandler.makeSuspendApiCall(
                context = this@UpdateStatusActivity,
                showLoading = true,
                loadingMessage = getString(R.string.uploading),
                apiCall = { call },
                onSuccess = { response ->
                    val result = response.body()
                    Log.d("updateLeadStatus", "$result")
                },
                onError = { error ->
                    Log.d("eeee", error)
                }
            )
            true
        } catch (e: Exception) {
            getErrorAlertDialog(this@UpdateStatusActivity, e.toString())
            false
        }
    }

    private suspend fun fetchLeadStatus(): List<LeadsModel.getLeadStatus.leadStatus>? {
        return try {
            val call = ApiClient.apiService.getLeadStatus(bearerToken)
            Log.d("inStatuslead", call.toString())
            var result: List<LeadsModel.getLeadStatus.leadStatus>? = null

            ApiRequestHandler.makeSuspendApiCall(
                context = this,
                showLoading = true,
                loadingMessage = getString(R.string.fetching_data),
                apiCall = { call },
                onSuccess = { response ->
                    result = response.body()
                    Log.d("Statusleadresponce", "$result")
                },
                onError = { error ->
                    Log.d("eeee", error)
                }
            )
            result
        } catch (e: Exception) {
            Log.d("rrrrr", e.toString())
            null
        }
    }
}