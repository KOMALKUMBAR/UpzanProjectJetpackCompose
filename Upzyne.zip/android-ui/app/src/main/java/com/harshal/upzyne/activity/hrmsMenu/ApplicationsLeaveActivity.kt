package com.harshal.upzyne.activity.hrmsMenu

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.adapter.ApplicationsLeaveAdapter
import com.harshal.upzyne.databinding.ActivityApplicationsLeaveBinding
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch
import java.util.Locale

class ApplicationsLeaveActivity : AppCompatActivity() {
    private lateinit var binding: ActivityApplicationsLeaveBinding
    private lateinit var adapter: ApplicationsLeaveAdapter
    private lateinit var bearerToken: String
    lateinit var userFullName: String

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityApplicationsLeaveBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        // Set up token
        val sharedPref = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        //setThemeBackground(this, binding.rootLayout)
        //setThemeBackground(this, binding.recyclerviewNextStatus)
        setThemeBackground(this, binding.linearInside)

        val token = sharedPref.getString("auth_token", "") ?: ""
        bearerToken = "Bearer $token"

        // Set user name on header
        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.apply_status)
        binding.titleBar.text = "$userFullName - $activityName"

        binding.recyclerviewNextStatus.layoutManager = LinearLayoutManager(this)

        binding.imgArrowBack.setOnClickListener {
            finish()
        }

        fetchLeaveApplications()
    }

    @SuppressLint("SetTextI18n")
    private fun fetchLeaveApplications() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getLeaveApplications(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ApplicationsLeaveActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val leaveList = response.data

                        if (leaveList.isNotEmpty()) {
                            // Show content
                            binding.emptyState.visibility = View.GONE
                            binding.contentScroll.visibility = View.VISIBLE

                            val recent = leaveList.first()
                            val past = leaveList.drop(1)

                            // Bind recent application
                            binding.leaveType.text = " ${recent.leavetype.lowercase(Locale.ROOT)}"
                            binding.leaveDate.text = "${recent.datefrom} to ${recent.dateto}"
                            binding.leaveDescription.text = " ${recent.remarks.lowercase(Locale.ROOT)}"
                            binding.status.text = " ${recent.status.lowercase(Locale.ROOT)}"

                            // Bind past to RecyclerView
                            adapter = ApplicationsLeaveAdapter(past)
                            binding.recyclerviewNextStatus.adapter = adapter
                        } else {
                            // Show empty state
                            binding.emptyState.visibility = View.VISIBLE
                            binding.contentScroll.visibility = View.GONE
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@ApplicationsLeaveActivity,
                            "EC024",
                            "ApplicationsLeaveActivity",
                            "fetchLeaveApplications",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@ApplicationsLeaveActivity,
                    "EC024",
                    "ApplicationsLeaveActivity",
                    "fetchLeaveApplications",
                    e
                )
            }
        }
    }
}