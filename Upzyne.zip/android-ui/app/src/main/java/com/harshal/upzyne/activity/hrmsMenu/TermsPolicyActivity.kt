package com.harshal.upzyne.activity.hrmsMenu

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.CommonUtils.LanguageUtils
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.databinding.ActivityTermspolicyBinding
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch

class TermsPolicyActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTermspolicyBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var activityName: String
    lateinit var userFullName: String

    //code for language change. insert it in every activity at start.
    override fun attachBaseContext(newBase: Context) {
        val lang = LanguageUtils.getLanguage(newBase)
        val context = LanguageUtils.setLocale(newBase, lang)
        super.attachBaseContext(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTermspolicyBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        activityName = intent.getStringExtra("activityName").toString()
        //binding.titleBar.text = activityName

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "").toString()
        //val activityName = getString(R.string.terms_and_policy)
        binding.titleBar.text = "$userFullName - $activityName"

        binding.imgArrow.setOnClickListener {
            finish()
        }

        fetchTermsPolicy("Bearer ${sharedPref.getString("auth_token", "")}")
    }

    private fun fetchTermsPolicy(token: String) {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = if (activityName == "terms & condition") {
                    ApiClient.apiService.getTerms(token)
                } else {
                    ApiClient.apiService.getPolicy(token)
                }

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@TermsPolicyActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        binding.tvLastUpdate.text = "${getString(R.string.last_update)} ${response.data.lastupdated}"
                        binding.tvTitle.text = response.data.title
                        binding.tvDescription.text = response.data.description
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@TermsPolicyActivity,
                            "EC039",
                            "TermsPolicyActivity",
                            "fetchTermsPolicy",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@TermsPolicyActivity,
                    "EC039",
                    "TermsPolicyActivity",
                    "fetchTermsPolicy",
                    e
                )
            }
        }
    }
}