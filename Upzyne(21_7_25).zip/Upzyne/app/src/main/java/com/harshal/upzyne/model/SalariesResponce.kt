package com.harshal.upzyne.model

data class SalariesResponce(val data: List<SalariesList>)

data class SalariesList(
    val attendance: String,
    val month: Int,
    val paidon: String,
    val received: String,
    val year: Int
)