package com.harshal.upzyne.activity.settingMenu

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.harshal.upzyne.databinding.ActivityThemeBinding
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.saveGradientColors
import com.harshal.upzyne.UtilsMethods.setDynamicGradientBackground
import com.harshal.upzyne.adapter.HolidayAdapter
import com.harshal.upzyne.adapter.ThemeAdapter
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.model.Backgrounds
import kotlinx.coroutines.launch

class ThemeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityThemeBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    lateinit var userFullName: String
    private lateinit var themeList: List<Backgrounds>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityThemeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val token = sharedPref.getString("auth_token", "") ?: ""
        bearerToken = "Bearer $token"

        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.themes)
        binding.titleBar.text = "$userFullName - $activityName"

        binding.imgBack.setOnClickListener { finish() }
        binding.recyclerTheme.layoutManager = LinearLayoutManager(this)

        fetchThemes()
    }

    private fun fetchThemes() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getThemes(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ThemeActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        themeList = response.backgrounds

                        val themeAdapter = ThemeAdapter(themeList)
                        binding.recyclerTheme.adapter = themeAdapter
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@ThemeActivity,
                            "EC046",
                            "ThemeActivity",
                            "fetchThemes",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@ThemeActivity,
                    "EC046",
                    "ThemeActivity",
                    "fetchThemes",
                    e
                )
            }
        }
    }
}