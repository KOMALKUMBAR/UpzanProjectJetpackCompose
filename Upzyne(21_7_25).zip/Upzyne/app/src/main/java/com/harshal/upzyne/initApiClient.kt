package com.harshal.upzyne

import android.app.Application

class initApiClient: Application() {
    override fun onCreate() {
        super.onCreate()
        ApiClient.init(this) // ✅ Correct place to initialize singleton
    }
}