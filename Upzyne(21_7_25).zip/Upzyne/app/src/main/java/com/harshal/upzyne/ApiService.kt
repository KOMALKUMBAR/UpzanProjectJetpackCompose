package com.harshal.upzyne

import com.harshal.upzyne.model.AbsentMemberResponse
import com.harshal.upzyne.model.ApplicationLeaveResponse
import com.harshal.upzyne.model.ApplyLeaveResponse
import com.harshal.upzyne.model.AttendanceLogResponseData
import com.harshal.upzyne.model.AttendanceTodayResponse
import com.harshal.upzyne.model.ClientRequest
import com.harshal.upzyne.model.ClientValidationResponse
import com.harshal.upzyne.model.CompanyDetails
import com.harshal.upzyne.model.FaqData
import com.harshal.upzyne.model.HolidayResponce
import com.harshal.upzyne.model.LeadsModel
import com.harshal.upzyne.model.LeaveType
import com.harshal.upzyne.model.LoginRequest
import com.harshal.upzyne.model.LoginResponse
import com.harshal.upzyne.model.ProfileInfoResponce
import com.harshal.upzyne.model.SalariesResponce
import com.harshal.upzyne.model.SalarySlipResponseData
import com.harshal.upzyne.model.SettingModel
import com.harshal.upzyne.model.SettingModel.PersonalInfoResponse
import com.harshal.upzyne.model.SwipeInResponce
import com.harshal.upzyne.model.TeamContactsResponse
import com.harshal.upzyne.model.TermPolicyResponse
import com.harshal.upzyne.model.ThemeResponse
import com.harshal.upzyne.model.UserListResponse
import com.harshal.upzyne.model.WorkPlaceResponce
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Part
import retrofit2.http.Query

interface ApiService {
    //------Login
    @Headers("Accept: */*", "Content-Type: application/json")
    @POST("auth/validate_client")
    suspend fun validateClient(@Body request: ClientRequest): ClientValidationResponse

    @Headers("Accept: */*", "Content-Type: application/json")
    @POST("auth/login")
    suspend fun loginClient(@Body request: LoginRequest): LoginResponse

    //----------home
    @Headers("Accept: */*")
    @GET("user/member-details/basic-info")
    suspend fun basicInfo(@Header("Authorization") token: String): ProfileInfoResponce

    //--------hrms
    @GET("user/hrms/attendance/work/location")
    suspend fun getWorkPlace(@Header("Authorization") token: String): WorkPlaceResponce

    @GET("user/hrms/attendance/today")
    suspend fun getTodayAttendance(@Header("Authorization") token: String): AttendanceTodayResponse

    @Headers("Accept: */*")
    @Multipart
    @POST("user/hrms/attendance/swipe_in")
    suspend fun uploadSwipeInData(
        @Header("Authorization") token: String,
        @Part file: MultipartBody.Part,
        @Part("data") data: RequestBody
    ): SwipeInResponce

    @Headers("Accept: */*")
    @Multipart
    @POST("user/hrms/attendance/swipe_out")
    suspend fun uploadSwipeOutData(
        @Header("Authorization") token: String,
        @Part file: MultipartBody.Part,
        @Part("data") data: RequestBody
    ): SwipeInResponce

    @Multipart
    @POST("user/hrms/leave/apply")
    suspend fun applyLeaveWithFile(
        @Header("Authorization") token: String,
        @Part("leaveData") leaveData: RequestBody,
        @Part file: MultipartBody.Part? = null
    ): ApplyLeaveResponse

    @GET("user/hrms/leave/types")
    suspend fun getLeaveTypes(
        @Header("Authorization") token: String
    ):List<LeaveType>

    @GET("user/hrms/hr/terms")
    suspend fun getTerms(@Header("Authorization") token: String): TermPolicyResponse

    @GET("user/hrms/hr/privacy")
    suspend fun getPolicy(@Header("Authorization") token: String): TermPolicyResponse

    @GET("user/hrms/hr/holiday/list")
    suspend fun getHoliday(@Header("Authorization") bearerToken: String): HolidayResponce

    @GET("user/hrms/attendance/absent")
    suspend fun getAbsentMember(@Header("Authorization") bearerToken: String): AbsentMemberResponse

    @GET("user/hrms/hr/salary/slips")
    suspend fun getSalaries(@Header("Authorization") token: String): SalariesResponce

    @GET("user/hrms/hr/salary/slip")
    suspend fun getSalarySlip(
        @Header("Authorization") bearerToken: String,
        @Query("month") month: Int,
        @Query("year") year: Int
    ): SalarySlipResponseData

    @GET("user/hrms/attendance/logs")
    suspend fun getAttendanceLogs(
        @Header("Authorization") bearerToken: String,
        @Query("startDate") startDate: String,
        @Query("endDate") endDate: String
    ): AttendanceLogResponseData

    @GET("user/hrms/hr/team/contacts/search")
    suspend fun searchTeamContacts(
        @Header("Authorization") bearerToken: String,
        @Query("term") term: String
    ): TeamContactsResponse

    @GET("user/hrms/hr/team/contacts")
    suspend fun getTeamContacts(@Header("Authorization") bearerToken: String): TeamContactsResponse

    @GET("user/hrms/leave/applications")
    suspend fun getLeaveApplications(@Header("Authorization") token: String): ApplicationLeaveResponse

    @GET("user/member-details/list-with-department")
    suspend fun getUserListWithDept(@Header("Authorization") token: String): UserListResponse

    //----------setting
    @GET("user/member-details/profile-details")
    suspend fun getProfileDetails(@Header("Authorization") token: String): PersonalInfoResponse

    @PUT("/user/member/update-address")
    suspend fun updateAddress(
        @Header("Authorization") token: String,
        @Body addressData: Map<String, String>
    ): SettingModel.UpdatePersonalAddressResponse

    @GET("user/common/tenant/basic-details")
    suspend fun getThemes(@Header("Authorization") bearerToken: String): ThemeResponse

    @GET("user/common/tenant/faqs")
    suspend fun getFAQ(@Header("Authorization") bearerToken: String): List<FaqData>

    @GET("user/common/contact-info")
    suspend fun getCompanyDetails(@Header("Authorization") bearerToken: String): CompanyDetails

    @GET("user/hrms/hr/team-assets-image")
    suspend fun getTeamAssets( @Header("Authorization") token:  String): SettingModel.TeamAssetResponse

    @GET("user/member-details/bank-details")
    suspend  fun getBankDetails(@Header("Authorization") token: String): SettingModel.BankDetailsResponse

    @POST("user/member-details/change_password")
    suspend fun changePassword(@Header("Authorization") token: String, @Body body: SettingModel.ChangePasswordRequest):
          SettingModel.ChangePasswordResponse

    @GET("user/hrms/hr/document/types")
    suspend fun getDocumentHrTypes( @Header("Authorization") token:  String): SettingModel.DocumentHrTypesResponse

    @Multipart
    @POST("user/hrms/hr/document/upload")
    suspend fun uploadDocument(
        @Header("Authorization") token: String,
        @Part file: MultipartBody.Part,
        @Part("documentTypeId") documentTypeId: RequestBody,
        @Part("remarks") remarks: RequestBody
    ):SettingModel.UploadDocumentResponseBody

    @Multipart
    @PUT("user/member-details/update-profile-image")
    fun uploadProfileImage(
        @Header("Authorization") token: String,
        @Part file: MultipartBody.Part
    ): Call<SettingModel.UploadDocumentResponseBody>

    @GET("user/hrms/hr/document/list")
   suspend fun getUploadedDocuments(@Header("Authorization") token: String
    ): SettingModel.DocumentListResponse

    //------------Leads Menu
    @GET("user/leads/assigned")
    suspend fun getAssignedLeads(
        @Header("Authorization") bearerToken: String,
        @Query("limit") limit: Int,
        @Query("offset") offset: Int
    ): Response<List<LeadsModel.LeadsModelDataClasss.LeadData>>

    @GET("user/leads/assigned/search")
    suspend fun searchAssignedLeads(
        @Header("Authorization") bearerToken: String,
        @Query("q") query: String,
        @Query("limit") limit: Int,
        @Query("offset") offset: Int
    ): Response<List<LeadsModel.LeadsModelDataClasss.LeadData>>

    @GET("user/leads/score-details-percent")
    suspend fun getLeadScore(
        @Header("Authorization") token: String,
        @Query("leadId") limit: Int,
    ): Response<LeadsModel.LeadsScoreResponse>


}