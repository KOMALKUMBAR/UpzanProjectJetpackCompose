package com.harshal.upzyne.model

class LeadsModel {

    data class LeadsModelDataClasss(
        val data: List<LeadData>
    ) {
        data class LeadData(
            val name: String,
            val phonenumber: String,
            val leadscore: Int,
            val leadid: Int,
            val timeago: String,
            val sourcebadge: String,
            val programme: String,
            val leaddate: String,
            val totalcount: Int,
            val statuscolor: String,
            val leadscorecolor: String,
            val leadsourcename: String,
            val statuslabel: String,
            val isotpverified: Boolean,
            val programmeCountry: String,
            val description: String,
            val salespitch: String,
            val usp: String,
            val upsellpitch: String
        )
    }

    data class LeadsScoreResponse(
        val data: List<LeadScoreData>
    ) {
        data class LeadScoreData(
            val leadid: Int,
            val percentage_score: Int,
            val suggestions: String,
            val raw_score: Int,
            val breakdown: String
        )
    }

}