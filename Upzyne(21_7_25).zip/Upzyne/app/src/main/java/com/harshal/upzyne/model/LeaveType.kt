package com.harshal.upzyne.model

data class LeaveType(
    val leavetypeid: Int,
    val leavetypename: String
)
