package com.harshal.upzyne.model

import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import okio.BufferedSink
import java.io.IOException

class ProgressRequestBody(
    private val fileBytes: ByteArray,
    private val contentType: String,
    private val onProgress: (Int) -> Unit
) : RequestBody() {

    override fun contentType() = contentType.toMediaTypeOrNull()

    override fun contentLength() = fileBytes.size.toLong()

    @Throws(IOException::class)
    override fun writeTo(sink: BufferedSink) {
        val bufferSize = 2048
        var uploaded = 0L
        var offset = 0
        var bytesRemaining = fileBytes.size
        var lastProgress = 0

        while (bytesRemaining > 0) {
            val chunkSize = minOf(bufferSize, bytesRemaining)
            sink.write(fileBytes, offset, chunkSize)
            uploaded += chunkSize
            offset += chunkSize
            bytesRemaining -= chunkSize

            val progress = (100 * uploaded / fileBytes.size).toInt()
            if (progress != lastProgress) {
                onProgress(progress)
                lastProgress = progress
            }
        }
    }
}
