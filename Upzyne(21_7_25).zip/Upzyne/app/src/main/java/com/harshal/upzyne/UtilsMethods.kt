package com.harshal.upzyne

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import com.harshal.upzyne.databinding.LayoutErrorAlertBinding
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Window
import android.widget.EditText
import android.widget.ImageView
import androidx.core.graphics.toColorInt
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.harshal.upzyne.databinding.DialogLoadingBinding

object UtilsMethods {

    fun getActiveIpAddress(context: Context): String? {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork: Network = connectivityManager.activeNetwork ?: return null
        val networkCapabilities =
            connectivityManager.getNetworkCapabilities(activeNetwork) ?: return null

        val linkProperties: LinkProperties =
            connectivityManager.getLinkProperties(activeNetwork) ?: return null

        val isWifi = networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        val isMobile = networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)

        for (linkAddress in linkProperties.linkAddresses) {
            val ip = linkAddress.address.hostAddress
            if (ip != null) {
                if (!ip.contains(":")) { // Ignore IPv6
                    return when {
                        isWifi -> "Wi-Fi IP: $ip"
                        isMobile -> "Mobile IP: $ip"
                        else -> "Other IP: $ip"
                    }
                }
            }
        }
        return null
    }

    fun getDeviceDetails(context: Context): Map<String, String> {
        return mapOf(
            "Brand" to Build.BRAND,
            "Device" to Build.DEVICE,
            "Model" to Build.MODEL,
            "Manufacturer" to Build.MANUFACTURER,
            "Product" to Build.PRODUCT,
            "Hardware" to Build.HARDWARE,
            "Board" to Build.BOARD,
            "Bootloader" to Build.BOOTLOADER,
            "Display" to Build.DISPLAY,
            "Fingerprint" to Build.FINGERPRINT,
            "Host" to Build.HOST,
            "ID" to Build.ID,
            "Tags" to Build.TAGS,
            "Type" to Build.TYPE,
            "User" to Build.USER,
            "Android Version" to Build.VERSION.RELEASE,
            "SDK Version" to Build.VERSION.SDK_INT.toString(),
            "Codename" to Build.VERSION.CODENAME,
            "Security Patch" to (Build.VERSION.SECURITY_PATCH ?: "Unknown"),
        )
    }

    @SuppressLint("HardwareIds")
    fun getAndroidId(context: Context): String {
        return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
    }

    fun getErrorAlertDialog(context: Context, error: String) {
        val binding = LayoutErrorAlertBinding.inflate(LayoutInflater.from(context))

        val dialog = AlertDialog.Builder(context)
            .setView(binding.root)
            .setCancelable(false)
            .create()

        binding.tvError.text = error
        binding.btnok.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    fun takeScreenshotOfView(view: View): Bitmap {
        val screenshot = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(screenshot)
        view.draw(canvas)
        return screenshot
    }

    fun saveBitmapToFile(bitmap: Bitmap, context: Context): Uri? {
        val filename = "screenshot_${System.currentTimeMillis()}.png"
        val folderName = "Pictures/Upzyne/loginlogout"

        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpg")
            put(MediaStore.Images.Media.RELATIVE_PATH, folderName)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }

        val resolver = context.contentResolver
        val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

        imageUri?.let { uri ->
            try {
                resolver.openOutputStream(uri)?.use { outputStream ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                }

                contentValues.clear()
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, contentValues, null, null)
                return uri

            } catch (e: Exception) {
                Log.e("SaveImage", "Error saving image: ${e.message}")
                resolver.delete(uri, null, null)
            }
        }

        return null
    }

    fun shareImageOnWhatsApp(context: Context, imageUri: Uri) {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, imageUri)
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            context.startActivity(shareIntent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "whatsapp not installed.", Toast.LENGTH_SHORT).show()
        }
    }

    fun compressPhoto(path: String, reqWidth: Int, reqHeight: Int): Bitmap {
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeFile(path, options)

        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
        options.inJustDecodeBounds = false

        return BitmapFactory.decodeFile(path, options)
    }

    fun calculateInSampleSize(
        options: BitmapFactory.Options,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        val (height: Int, width: Int) = options.run { outHeight to outWidth }
        var inSampleSize = 1

        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2

            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }

        return inSampleSize
    }

    object AppLogger {
        fun logAndToast(
            context: Context,
            code: String,
            screen: String,
            function: String,
            e: Exception
        ) {
            val message =
                "Error Code: $code\nScreen: $screen\nFunction: $function\nMessage: ${e.message}"
            val message1 = "Error Code: $code\nScreen: $screen\nFunction: $function\nMessage:"
            //Toast.makeText(context, message1, Toast.LENGTH_LONG).show()
            Log.d(screen, "Error $code in $function: $message", e)
        }
    }

    fun View.setDynamicGradientBackground(
        startColor: String,
        centerColor: String,
        endColor: String,
        cornerRadiusDp: Float = 8f
    ) {
        val gradientDrawable = GradientDrawable(
            GradientDrawable.Orientation.RIGHT_LEFT,
            intArrayOf(
                startColor.toColorInt(),
                centerColor.toColorInt(),
                endColor.toColorInt()
            )
        )
        gradientDrawable.cornerRadius = cornerRadiusDp * context.resources.displayMetrics.density
        this.background = gradientDrawable
    }

    fun saveGradientColors(
        context: Context,
        startColor: String,
        centerColor: String,
        endColor: String
    ) {
        val sharedPref = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putString("startColor", startColor)
            putString("centerColor", centerColor)
            putString("endColor", endColor)
            apply()
        }
    }

    fun getGradientColors(context: Context): Triple<String, String, String>? {
        val sharedPref = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val startColor = sharedPref.getString("startColor", "#ffe4e1")
        val centerColor = sharedPref.getString("centerColor", "#ffecd2")
        val endColor = sharedPref.getString("endColor", "#fffbe6")

        return if (startColor != null && centerColor != null && endColor != null) {
            Triple(startColor, centerColor, endColor)
        } else {
            null
        }
    }

    fun setThemeBackground(context: Context, view: View?) {
        val selectedTheme = getGradientColors(context)

        selectedTheme?.let { (start, center, end) ->
            view?.setDynamicGradientBackground(start, center, end)
            if (context is Activity) {
                context.window.statusBarColor = start.toColorInt()
            }
        }
    }

    private var dialog: Dialog? = null
    fun showLoading(context: Context, message: String) {
        if (dialog != null && dialog!!.isShowing) return

        val binding = DialogLoadingBinding.inflate(LayoutInflater.from(context))
        binding.tvLoading.text = message
        dialog = Dialog(context)
        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.setContentView(binding.root)
        dialog?.setCancelable(false)
        dialog?.show()

        setThemeBackground(context, binding.rootLayout)
    }

    fun hideLoading() {
        dialog?.dismiss()
        dialog = null
    }

    //rootInserPadding code above 15 UI
    fun applyInsetPadding(activity: Activity, rootView: View, paddingDp: Int = 10) {
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)

        ViewCompat.setOnApplyWindowInsetsListener(rootView) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val scale = view.context.resources.displayMetrics.density
            val paddingPx = (paddingDp * scale).toInt()

            view.setPadding(
                systemBars.left + paddingPx,
                systemBars.top + paddingPx,
                systemBars.right + paddingPx,
                systemBars.bottom + paddingPx
            )
            insets
        }
    }

    fun togglePasswordVisibility(
        editText: EditText,
        toggleView: ImageView,
        isVisible: Boolean
    ): Boolean {
        val newVisible = !isVisible
        editText.inputType = if (newVisible)
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        else
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

        toggleView.setImageResource(if (newVisible) R.drawable.ic_eyeslash else R.drawable.ic_eye)
        editText.setSelection(editText.text.length)
        return newVisible
    }

    fun maskPhoneNumber(number: String): String {
        // Remove all non-digit characters except the '+' for uniform processing
        val cleaned = number.replace(Regex("[^\\d+]"), "")

        // Extract last 10 digits (Indian mobile number)
        val last10 = cleaned.takeLast(10)

        return if (last10.length == 10) {
            val masked = last10.replaceRange(3, 8, "******")
            "+91 $masked"
        } else {
            number // fallback for unexpected format
        }
    }
}