import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.model.TeamContactsResponseData

class TeamContactsAdapter(private val contacts: List<TeamContactsResponseData>) : RecyclerView.Adapter<TeamContactsAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvContactNumber: TextView = view.findViewById(R.id.tvPhone)
        val tvDesignation: TextView = view.findViewById(R.id.tvDesignation)
        val tvEmail: TextView = view.findViewById(R.id.tvEmail)
        val rootLayout: View = view.findViewById(R.id.rootLayout)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_team_contacts, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount() = contacts.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        setThemeBackground(holder.itemView.context, holder.rootLayout)
        val contact = contacts[position]
        holder.tvName.text = contact.name
        holder.tvContactNumber.text = contact.contactnumber
        holder.tvDesignation.text = contact.designation
        holder.tvEmail.text = contact.email
    }
}
