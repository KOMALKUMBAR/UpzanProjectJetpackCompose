package com.harshal.upzyne.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.databinding.MenuItemRowBinding
import com.harshal.upzyne.databinding.MenuItemSublistBinding
import com.harshal.upzyne.model.menu_item_data

class menuAdapter(
    private val items: List<menu_item_data>,
    private val onSubItemClick: (parent: menu_item_data, subItem: String) -> Unit,
    private val onItemClick: (item: menu_item_data) -> Unit
) : RecyclerView.Adapter<menuAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: MenuItemRowBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: menu_item_data) {
            val context = binding.root.context
            binding.titleText.text = item.title

            // ✅ Always reset the text color
            if (item.title.equals("logout", ignoreCase = true)) {
                binding.titleText.setTextColor(ContextCompat.getColor(context, R.color.red))
            } else {
                binding.titleText.setTextColor(ContextCompat.getColor(context, R.color.black)) // Replace with your actual default color
            }

            binding.startIcon.setImageResource(item.iconResId)

            // Set arrow direction
            if (item.subItems.isNullOrEmpty()) {
                binding.arrowIcon.visibility = View.GONE
            } else {
                binding.arrowIcon.visibility = View.VISIBLE
                val arrowRes = if (item.isExpanded) R.drawable.ic_arrow_drop_up else R.drawable.ic_arrow_drop_down
                binding.arrowIcon.setImageResource(arrowRes)
            }

            // Manage sub-items
            binding.subListLayout.removeAllViews()
            if (item.isExpanded) {
                item.subItems.forEach { subItem ->
                    val subItemBinding = MenuItemSublistBinding.inflate(
                        LayoutInflater.from(context),
                        binding.subListLayout,
                        false
                    )
                    subItemBinding.subItemText.text = subItem
                    subItemBinding.subItemCard.setOnClickListener {
                        onSubItemClick(item, subItem)
                    }
                    binding.subListLayout.addView(subItemBinding.root)
                }
                binding.subListLayout.visibility = View.VISIBLE
            } else {
                binding.subListLayout.visibility = View.GONE
            }

            binding.itemLayout.setOnClickListener {
                if (item.title.equals("logout", ignoreCase = true)
                    || item.title.equals("setting", ignoreCase = true)
                    || item.subItems.isNullOrEmpty()
                ) {
                    onItemClick(item)
                } else {
                    item.isExpanded = !item.isExpanded
                    notifyItemChanged(adapterPosition)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = MenuItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount() = items.size
}
