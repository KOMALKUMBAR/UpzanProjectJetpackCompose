package com.harshal.upzyne.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ItemFaqBinding
import com.harshal.upzyne.model.FaqData

class FaqAdapter(private val faqList: List<FaqData>) : RecyclerView.Adapter<FaqAdapter.FaqViewHolder>() {
    inner class FaqViewHolder(val binding: ItemFaqBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FaqViewHolder {
        val binding = ItemFaqBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FaqViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FaqViewHolder, position: Int) {
        val item = faqList[position]
        setThemeBackground(holder.itemView.context, holder.binding.rootLayout)

        holder.binding.tvQuestion.text = item.question
        holder.binding.tvAnswer.text = item.answer
        holder.binding.tvAnswer.visibility = View.GONE
        holder.binding.tvQuestion.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_arrow_drop_down, 0)

        holder.binding.rootLayout.setOnClickListener {
            val isVisible = holder.binding.tvAnswer.visibility == View.VISIBLE
            holder.binding.tvAnswer.visibility = if (isVisible) View.GONE else View.VISIBLE
            holder.binding.tvQuestion.setCompoundDrawablesWithIntrinsicBounds(
                0, 0,
                if (isVisible) R.drawable.ic_arrow_drop_down else R.drawable.ic_arrow_drop_up,
                0
            )
        }
    }

    override fun getItemCount(): Int = faqList.size
}