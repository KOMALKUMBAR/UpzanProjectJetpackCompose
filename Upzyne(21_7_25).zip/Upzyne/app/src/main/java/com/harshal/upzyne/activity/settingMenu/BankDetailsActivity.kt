package com.harshal.upzyne.activity.settingMenu

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.applyInsetPadding
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityBankDetailsBinding
import com.harshal.upzyne.model.SettingModel.BankDetails
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BankDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBankDetailsBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private lateinit var userFullName: String

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBankDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.bank_details)
        binding.titleBar.text = "$userFullName - $activityName"
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "")}"
        applyInsetPadding(this, binding.root)
        setThemeBackground(this, binding.rootLayout)

        binding.imgArrow.setOnClickListener { finish() }

        fetchBankDetails()
    }

    private fun fetchBankDetails() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getBankDetails(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@BankDetailsActivity,
                    showLoading = true,
                    loadingMessage = "Fetching bank details...",
                    apiCall = { call },
                    onSuccess = { response ->
                        if (response.data != null) {
                            updateUI(response.data)
                        } else {
                            Toast.makeText(
                                this@BankDetailsActivity,
                                "No bank details found",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@BankDetailsActivity,
                            "EC043",
                            "BankDetailsActivity",
                            "fetchBankDetails",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@BankDetailsActivity,
                    "EC044",
                    "BankDetailsActivity",
                    "fetchBankDetails",
                    e
                )
            }
        }
    }

    private fun updateUI(data: BankDetails) {
        binding.apply {
            bankNameTextView.text = data.bankname
            accountNumberTextView.text = data.accountnumber
            ifscCodeTextView.text = data.ifsccode
            accountHolderNameTextView.text = data.accountholdername
            branchName.text = data.branchname
            accountTypeTextView.text = data.accounttype
            aadharCardTextView.text = data.aadharcard
            panCardTextView.text = data.pancard
        }
    }
}