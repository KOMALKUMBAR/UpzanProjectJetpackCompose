package com.harshal.upzyne.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.model.SettingModel.DocumentData

class UploadedDocumentAdapter(private val documentList: MutableList<DocumentData>, private val onItemClick: (DocumentData) -> Unit) : RecyclerView.Adapter<UploadedDocumentAdapter.DocViewHolder>() {

    inner class DocViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDocType: TextView = itemView.findViewById(R.id.assetsTxt)
        val tvUploadDate: TextView = itemView.findViewById(R.id.tvUploadDate)
        val rootLayout: RelativeLayout = itemView.findViewById(R.id.rootLayout)

        init {
            itemView.setOnClickListener {
                onItemClick(documentList[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DocViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.document_list_item, parent, false)
        return DocViewHolder(view)
    }

    override fun onBindViewHolder(holder: DocViewHolder, position: Int) {
        setThemeBackground(holder.itemView.context, holder.rootLayout)

        val doc = documentList[position]
        holder.tvDocType.text = doc.documenttypename
        holder.tvUploadDate.text = doc.uploaddate.take(10)
    }

    override fun getItemCount(): Int = documentList.size
}
