package com.harshal.upzyne.activity.hrmsMenu

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.*
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.adapter.AttendanceLogAdapter
import com.harshal.upzyne.databinding.ActivityLoginlogoutLogBinding
import com.harshal.upzyne.model.AttendanceLogResponse
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AttendanceLogActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginlogoutLogBinding
    private lateinit var adapter: AttendanceLogAdapter
    private lateinit var sharedPref: SharedPreferences
    private lateinit var errorDrawable: Drawable

    private var startDateInMillis: Long = System.currentTimeMillis()
    private var endDateInMillis: Long = System.currentTimeMillis()

    private val attendanceList = mutableListOf<AttendanceLogResponse>()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private lateinit var userFullName: String

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginlogoutLogBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.attendance)
        binding.titleBar.text = "$userFullName - $activityName"

        adapter = AttendanceLogAdapter(attendanceList)
        binding.rvAttendanceList.layoutManager = LinearLayoutManager(this)
        binding.rvAttendanceList.adapter = adapter

        errorDrawable = ContextCompat.getDrawable(this, R.drawable.baseline_error_24)!!.mutate()
        errorDrawable.setTint(Color.RED)

        // Set default current date
        val currentDate = Date()
        val calendar = Calendar.getInstance()
        calendar.time = currentDate
        calendar.add(Calendar.DAY_OF_YEAR, -7)
        val sevenDaysAgo = calendar.time

        // Format when setting text
        binding.edtDateto.text = dateFormat.format(currentDate)
        binding.edtDatefrom.text = dateFormat.format(sevenDaysAgo)
        fetchAttendanceLogs(binding.edtDatefrom.text.toString(), binding.edtDateto.text.toString())

        binding.edtDatefrom.setOnClickListener { showDatePicker(true) }
        binding.edtDateto.setOnClickListener { showDatePicker(false) }

        binding.ivDateGo.setOnClickListener { onSearchClicked() }
        binding.imgArrow.setOnClickListener { finish() }
    }

    private fun onSearchClicked() {
        val startDate = binding.edtDatefrom.text.toString()
        val endDate = binding.edtDateto.text.toString()

        val hasError = listOf(
            validateDateField(binding.edtDatefrom, startDate, getString(R.string.date_from)),
            validateDateField(binding.edtDateto, endDate, getString(R.string.date_to))
        ).any { it }

        if (!hasError) fetchAttendanceLogs(startDate, endDate)
    }

    private fun validateDateField(view: TextView, date: String, placeholder: String): Boolean {
        return if (date.equals(placeholder, true) || date.isEmpty()) {
            setRightErrorIcon(view, errorDrawable)
            true
        } else {
            setRightErrorIcon(view, null)
            false
        }
    }

    private fun setRightErrorIcon(view: TextView, right: Drawable?) {
        val left = ContextCompat.getDrawable(this, R.drawable.ic_datepicker)
        view.setCompoundDrawablesWithIntrinsicBounds(left, null, right, null)
        view.compoundDrawablePadding = 10
    }

    private fun showDatePicker(isStartDate: Boolean) {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = if (isStartDate) startDateInMillis else endDateInMillis
        }

        val dialog = DatePickerDialog(
            this,
            { _, y, m, d ->
                val date = String.format("%04d-%02d-%02d", y, m + 1, d)
                val parsedDate = dateFormat.parse(date) ?: return@DatePickerDialog

                if (isStartDate) {
                    startDateInMillis = parsedDate.time
                    binding.edtDatefrom.text = dateFormat.format(parsedDate)
                    setRightErrorIcon(binding.edtDatefrom, null)
                } else {
                    if (parsedDate.time < startDateInMillis) {
                        Toast.makeText(this, "end date cannot be before start date", Toast.LENGTH_SHORT).show()
                    } else {
                        endDateInMillis = parsedDate.time
                        binding.edtDateto.text = dateFormat.format(parsedDate)
                        setRightErrorIcon(binding.edtDateto, null)
                    }
                }
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )

        dialog.datePicker.minDate = if (isStartDate) 0 else startDateInMillis
        dialog.datePicker.maxDate = System.currentTimeMillis()

        dialog.setOnShowListener {
            dialog.getButton(DatePickerDialog.BUTTON_POSITIVE)?.setTextColor(Color.BLACK)
            dialog.getButton(DatePickerDialog.BUTTON_NEGATIVE)?.setTextColor(Color.BLACK)
        }

        dialog.show()
    }

    private fun fetchAttendanceLogs(startDate: String, endDate: String) {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                binding.emptyState.visibility = View.GONE
                binding.rvAttendanceList.visibility = View.GONE

                val call = ApiClient.apiService.getAttendanceLogs(
                    "Bearer ${sharedPref.getString("auth_token", "")}",
                    startDate, endDate)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@AttendanceLogActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        attendanceList.clear()

                        response.data?.let {
                            attendanceList.addAll(it)
                        }

                        adapter.notifyDataSetChanged()
                        toggleEmptyState(attendanceList.isEmpty())
                    },
                    onError = {
                        toggleEmptyState(true)
                        AppLogger.logAndToast(this@AttendanceLogActivity, "EC023", "AttendanceLogActivity", "fetchAttendanceLogs", Exception(it))
                    }
                )
            } catch (e: Exception) {
                toggleEmptyState(true)
                Log.e("errorr", e.toString())
                AppLogger.logAndToast(this@AttendanceLogActivity, "EC023", "AttendanceLogActivity", "fetchAttendanceLogs", e)
            }
        }
    }

    private fun toggleEmptyState(isEmpty: Boolean) {
        binding.emptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.rvAttendanceList.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }
}