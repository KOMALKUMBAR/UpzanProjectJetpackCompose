package com.harshal.upzyne.activity.settingMenu

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.adapter.FaqAdapter
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityFaqHelpBinding
import com.harshal.upzyne.model.FaqData
import kotlinx.coroutines.launch

class FaqHelpActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFaqHelpBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private var allFaqList: List<FaqData> = emptyList()

    @SuppressLint("UseCompatLoadingForDrawables", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFaqHelpBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val userFullName = sharedPref.getString("user_fname", "") ?: ""
        val activityName = getString(R.string.faq_and_help)
        binding.titleBar.text = "$userFullName - $activityName"
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "") ?: ""}"

        binding.recyclerFAQ.layoutManager = LinearLayoutManager(this)
        binding.imgArrow.setOnClickListener { finish() }

        binding.etSearchFaq.addTextChangedListener {
            val query = it.toString().trim()
            if (query.isNotEmpty()) filterLocalFaq(query)
            else updateRecycler(allFaqList)
        }

        binding.btnFAQ.setOnClickListener {
            toggleButtons(true)
            fetchFAQ()
        }

        binding.btnContact.setOnClickListener {
            toggleButtons(false)
            fetchCompanyDetails()
        }

        fetchFAQ()
    }

    private fun toggleButtons(isFaqSelected: Boolean) {
        if (isFaqSelected) {
            binding.btnContact.background = getDrawable(R.drawable.shape_blank_btn)
            binding.btnFAQ.background = getDrawable(R.drawable.shape_color_btn)
            binding.btnFAQ.setTextColor(ContextCompat.getColor(this, R.color.white))
            binding.btnContact.setTextColor(ContextCompat.getColor(this, R.color.black))

            binding.layFaq.visibility = android.view.View.VISIBLE
            binding.layContact.visibility = android.view.View.GONE

            binding.recyclerFAQ.visibility = android.view.View.VISIBLE
            binding.etSearchFaq.visibility = android.view.View.VISIBLE
        } else {
            binding.btnFAQ.background = getDrawable(R.drawable.shape_blank_btn)
            binding.btnContact.background = getDrawable(R.drawable.shape_color_btn)
            binding.btnContact.setTextColor(ContextCompat.getColor(this, R.color.white))
            binding.btnFAQ.setTextColor(ContextCompat.getColor(this, R.color.black))

            binding.layContact.visibility = android.view.View.VISIBLE
            binding.layFaq.visibility = android.view.View.GONE

            binding.recyclerFAQ.visibility = android.view.View.GONE
            binding.etSearchFaq.visibility = android.view.View.GONE
        }
    }

    private fun fetchFAQ() {
        if (!checkNetworkAndShowMessage(this)) return
        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getFAQ(bearerToken)
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@FaqHelpActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        allFaqList = response.map { FaqData(it.question, it.answer) }
                        updateRecycler(allFaqList)
                    },
                    onError = {
                        AppLogger.logAndToast(this@FaqHelpActivity, "EC036", "FaqHelpActivity", "fetchFAQ", Exception(it))
                    }
                )
            } catch (e: Exception) {
                Log.e("FAQ_FETCH", e.message.toString())
            }
        }
    }

    private fun filterLocalFaq(query: String) {
        val filtered = allFaqList.filter {
            it.question.contains(query, true) || it.answer.contains(query, true)
        }
        updateRecycler(filtered)
    }

    private fun updateRecycler(list: List<FaqData>) {
        binding.recyclerFAQ.adapter = FaqAdapter(list)
        binding.recyclerFAQ.adapter?.notifyDataSetChanged()
    }

    private fun fetchCompanyDetails() {
        if (!checkNetworkAndShowMessage(this)) return
        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getCompanyDetails(bearerToken)
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@FaqHelpActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        binding.tvCompanyName.text = response.name
                        binding.tvCompanyAddress.text = "${response.address1}, ${response.address2}, ${response.postalcode}"

                        binding.imgWebsite.setOnClickListener { openLink(response.websitelink) }
                        binding.imgFacebook.setOnClickListener { openLink(response.facebooklink) }
                        binding.imgEmail.setOnClickListener { openEmail(response.supportemail) }
                        binding.imgInstagram.setOnClickListener { openLink(response.instagramlink) }
                        binding.imgWhatsapp.setOnClickListener { openWhatsApp(response.supportphone, "com.whatsapp") }
                        binding.imgWhatsappBusiness.setOnClickListener { openWhatsApp(response.supportphone, "com.whatsapp.w4b") }
                    },
                    onError = {
                        AppLogger.logAndToast(this@FaqHelpActivity, "EC036", "FaqHelpActivity", "fetchCompanyDetails", Exception(it))
                    }
                )
            } catch (e: Exception) {
                Log.e("COMPANY_FETCH", e.message.toString())
            }
        }
    }

    private fun openWhatsApp(phone: String, packageName: String) {
        val uri = Uri.parse("https://wa.me/$phone")
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setPackage(packageName)
            data = uri
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "App not installed: $packageName", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openEmail(email: String) {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:$email")
                putExtra(Intent.EXTRA_SUBJECT, "Support Request")
            }
            startActivity(Intent.createChooser(intent, "Send Email"))
        } catch (e: Exception) {
            Toast.makeText(this, "No email app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openLink(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open link", Toast.LENGTH_SHORT).show()
        }
    }
}