package com.harshal.upzyne.activity.hrmsMenu

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.google.gson.Gson
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ActivityApplyLeaveBinding
import com.harshal.upzyne.model.ApplyLeaveRequestData
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.model.LeaveType
import com.harshal.upzyne.util.FileUtils
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class ApplyLeaveActivity : AppCompatActivity() {
    private lateinit var binding: ActivityApplyLeaveBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private var selectedDate: String = ""
    private var coverByUserMap = mutableMapOf<String, Int>()
    lateinit var userFullName: String
    private var selectedFileUri: Uri? = null
    private var selectedFileName: String? = null
    private val leaveTypeIdMap = mutableMapOf<String,Int>()
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        try {

            uri?.let {
                val mimeType = contentResolver.getType(it)
                if (mimeType == "application/pdf" || mimeType == "image/png" || mimeType == "image/jpeg") {
                    selectedFileUri = it
                    selectedFileName = getFileNameFromUri(it)
                    binding.tvFileName.text = selectedFileName
                } else {
                    Toast.makeText(this, "select PDF, PNG or JPEG only", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            UtilsMethods.AppLogger.logAndToast(
                this, "EC028", "ApplyLeaveActivity", "filePickerLauncher", e
            )
        }
    }

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityApplyLeaveBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.apply_leave)
        binding.titleBar.text = "$userFullName - $activityName"
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "") ?: ""}"

        setThemeBackground(this, binding.rootLayout)

        setupSpinners()
        setupDatePicker()
        fetchCoverByList()
        setupSubmitButton()
        setupLeaveTypeSpinner()

        binding.rootLayout.setOnClickListener {
            currentFocus?.let { view ->
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(view.windowToken, 0)
                view.clearFocus()
            }
        }

        binding.imgArrowBack.setOnClickListener { finish() }

        binding.btnBrowse.setOnClickListener {
            filePickerLauncher.launch("*/*")
        }

        binding.tvFileName.setOnTouchListener { v, event ->
            try {
                if (event.action == MotionEvent.ACTION_UP) {
                    v.performClick()
                    val drawableEnd = binding.tvFileName.compoundDrawables[2]
                    drawableEnd?.let {
                        val x = event.x.toInt()
                        val width = binding.tvFileName.width
                        if (x >= (width - it.bounds.width() - binding.tvFileName.paddingEnd)) {
                            selectedFileUri = null
                            selectedFileName = null
                            binding.tvFileName.text = ""
                            Toast.makeText(this, "file removed", Toast.LENGTH_SHORT).show()
                            return@setOnTouchListener true
                        }
                    }
                }
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this, "EC029", "ApplyLeaveActivity", "tvFileName.setOnTouchListener", e
                )
            }
            false
        }
    }

    private fun setupLeaveTypeSpinner() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getLeaveTypes(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ApplyLeaveActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { leaveTypeList: List<LeaveType> ->
                        if (leaveTypeList.isEmpty()) {
                            Toast.makeText(this@ApplyLeaveActivity, "no leave types found", Toast.LENGTH_SHORT).show()
                            return@makeSuspendApiCall
                        }

                        // Map leave type names to IDs
                        leaveTypeIdMap.clear()
                        leaveTypeIdMap.putAll(leaveTypeList.associate { it.leavetypename to it.leavetypeid })

                        val displayList = listOf("select") + leaveTypeIdMap.keys.toList()

                        val adapter = ArrayAdapter(
                            this@ApplyLeaveActivity,
                            R.layout.item_spinner,
                            displayList
                        ).apply {
                            setDropDownViewResource(R.layout.item_spinner)
                        }

                        binding.spinnerOne.adapter = adapter
                    },
                    onError = { error ->
                        Toast.makeText(this@ApplyLeaveActivity, "Error loading leave types: $error", Toast.LENGTH_SHORT).show()
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(this@ApplyLeaveActivity, "EC057", "ApplyLeaveActivity", "setupLeaveTypeSpinner", e)
            }
        }
    }

    private fun getFileNameFromUri(uri: Uri): String {
        var name = "unknown_file"
        try {
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index != -1) name = it.getString(index)
                }
            }
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC030", "ApplyLeaveActivity", "getFileNameFromUri", e)
        }
        return name
    }

    private fun setupSpinners() {
        val periods = listOf("select") + (1..10).map { it.toString() }
        binding.spinnerTwo.adapter = ArrayAdapter(this, R.layout.item_spinner, periods).apply {
            setDropDownViewResource(R.layout.item_spinner)
        }
    }

    private fun setupDatePicker() {
        binding.dateField.setOnClickListener {
            val calendar = Calendar.getInstance()
            val datePicker = DatePickerDialog(
                this,
                { _, year, month, dayOfMonth ->
                    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                    calendar.set(year, month, dayOfMonth)
                    selectedDate = sdf.format(calendar.time)
                    binding.dateField.setText(selectedDate)

                    binding.errorLeaveDate.visibility = View.GONE
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
            datePicker.datePicker.minDate = System.currentTimeMillis() - 1000

            // Show dialog first, then access buttons
            datePicker.setOnShowListener {
                datePicker.getButton(DialogInterface.BUTTON_POSITIVE)?.setTextColor(Color.BLACK)
                datePicker.getButton(DialogInterface.BUTTON_NEGATIVE)?.setTextColor(Color.BLACK)
            }

            datePicker.show()
        }
    }

    private fun fetchCoverByList() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getUserListWithDept(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ApplyLeaveActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val userList = response.data
                        val names = userList.map { it.fullname }

                        coverByUserMap = userList.associate { it.fullname to it.userid }.toMutableMap()

                        val displayList = listOf("select") + names

                        val adapter = ArrayAdapter(
                            this@ApplyLeaveActivity,
                            R.layout.item_spinner,
                            displayList
                        ).apply {
                            setDropDownViewResource(R.layout.item_spinner)
                        }

                        binding.spinnerThree.adapter = adapter
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@ApplyLeaveActivity,
                            "EC031",
                            "ApplyLeaveActivity",
                            "fetchCoverByList",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@ApplyLeaveActivity,
                    "EC031",
                    "ApplyLeaveActivity",
                    "fetchCoverByList",
                    e
                )
            }
        }
    }

    private fun calculateEndDate(startDateStr: String, totalDays: Int): String {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val calendar = Calendar.getInstance()
            calendar.time = sdf.parse(startDateStr) ?: Date()
            calendar.add(Calendar.DATE, totalDays - 1)
            sdf.format(calendar.time)
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC032", "ApplyLeaveActivity", "calculateEndDate", e)
            startDateStr
        }
    }

    private fun setupSubmitButton() {
        if (!checkNetworkAndShowMessage(this)) return

        try {
            binding.applyLeave.setOnClickListener {
                lifecycleScope.launch {
                    try {
                        val totalDays = binding.spinnerTwo.selectedItem.toString().toIntOrNull() ?: 0
                        val leaveTypeRaw = binding.spinnerOne.selectedItem.toString()
                        val remarks = binding.txtArea.text.toString()
                        val coverByName = binding.spinnerThree.selectedItem.toString()
                        val coverById = coverByUserMap[coverByName] ?: 0

                        Log.d("leavetype", "$leaveTypeRaw, $totalDays, $remarks, $coverById, $coverByName")

                        var hasTrue = false

                        if (selectedDate.isBlank()) {
                            binding.errorLeaveDate.visibility = View.VISIBLE
                            hasTrue = true
                        } else {
                            binding.errorLeaveDate.visibility = View.GONE
                        }

                        if (leaveTypeRaw.isBlank() || leaveTypeRaw == "select") {
                            binding.errorLeaveType.visibility = View.VISIBLE
                            hasTrue = true
                        } else {
                            binding.errorLeaveType.visibility = View.GONE
                        }

                        if (coverById == 0) {
                            binding.errorJobCovered.visibility = View.VISIBLE
                            hasTrue = true
                        } else {
                            binding.errorJobCovered.visibility = View.GONE
                        }

                        if (totalDays == 0) {
                            binding.errorLeavePeriod.visibility = View.VISIBLE
                            hasTrue = true
                        } else {
                            binding.errorLeavePeriod.visibility = View.GONE
                        }

                        if (hasTrue) return@launch
                        val leaveType = leaveTypeRaw.lowercase()
                        val leaveTypeId = leaveTypeIdMap[leaveTypeRaw] ?: 0

                        val dateTo = calculateEndDate(selectedDate, totalDays)

                        val requestData = ApplyLeaveRequestData(
                            dateFrom = selectedDate,
                            dateTo = dateTo,
                            totalDays = totalDays,
                            leaveType = leaveType,
                            leavePeriod = "full day",
                            remarks = remarks,
                            workCoverBy = coverById
                        )

                        val json = Gson().toJson(requestData)
                        val jsonRequestBody = json.toRequestBody("application/json".toMediaTypeOrNull())

                        val filePart = selectedFileUri?.let { uri ->
                            val filePath = FileUtils.getPath(this@ApplyLeaveActivity, uri)
                            if (!filePath.isNullOrEmpty()) {
                                val file = File(filePath)
                                val mimeType = contentResolver.getType(uri) ?: "application/octet-stream"
                                val requestFile = file.asRequestBody(mimeType.toMediaTypeOrNull())
                                MultipartBody.Part.createFormData("file", file.name, requestFile)
                            } else null
                        }

                        val call = ApiClient.apiService.applyLeaveWithFile(bearerToken, jsonRequestBody, filePart)

                        ApiRequestHandler.makeSuspendApiCall (
                            context = this@ApplyLeaveActivity,
                            showLoading = true,
                            loadingMessage = getString(R.string.loading),
                            apiCall = { call },
                            onSuccess = {
                                Toast.makeText(this@ApplyLeaveActivity, "leave applied successfully!", Toast.LENGTH_SHORT).show()
                                clearForm()
                                finish()
                                startActivity(Intent(this@ApplyLeaveActivity, ApplicationsLeaveActivity::class.java))
                            },
                            onError = { error ->
                                Toast.makeText(this@ApplyLeaveActivity, "Error: $error", Toast.LENGTH_LONG).show()
                            }
                        )
                    } catch (e: Exception) {
                        AppLogger.logAndToast(this@ApplyLeaveActivity, "EC033", "ApplyLeaveActivity", "setupSubmitButton", e)
                    }
                }
            }
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC034", "ApplyLeaveActivity", "setupSubmitButton", e)
        }
    }

    private fun clearForm() {
        try {
            binding.spinnerOne.setSelection(0)
            binding.spinnerTwo.setSelection(0)
            binding.spinnerThree.setSelection(0)
            binding.txtArea.setText("")
            binding.dateField.setText("")
            selectedFileUri = null
            selectedFileName = null
            binding.tvFileName.text = ""
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC035", "ApplyLeaveActivity", "clearForm", e)
        }
    }
}