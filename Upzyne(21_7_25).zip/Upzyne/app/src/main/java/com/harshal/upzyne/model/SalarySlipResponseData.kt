package com.harshal.upzyne.model

data class SalarySlipResponseData(
    val data: SalarySlipData
)

data class SalarySlipData(
    val attendancedays: Int,
    val bankaccountno: String,
    val bankname: String,
    val basicpay: Double,
    val department: String,
    val designation: String,
    val employeename: String,
    val empno: String,
    val gross_salary: Double,
    val house_rent_allowance: Double,
    val ifsccode: String,
    val incentive: Double,
    val income_tax: Double,
    val leave_deduction: Double,
    val leave_travel_allowance: Double,
    val medical_allowance: Double,
    val net_salary: Double,
    val paid_on: String,
    val pancard: String,
    val payment_mode: String,
    val professional_tax: Double,
    val record_created_at: String,
    val record_updated_at: String,
    val salary_month: String,
    val salary_year: Int,
    val totalworkdays: Int,
    val transport_allowance: Double,
    val personal_allowance: Double,
    val total_deductions: Double
)
