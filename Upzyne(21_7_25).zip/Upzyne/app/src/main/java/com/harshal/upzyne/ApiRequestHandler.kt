package com.harshal.upzyne

import android.content.Context
import android.util.Log
import com.harshal.upzyne.UtilsMethods.hideLoading
import com.harshal.upzyne.UtilsMethods.showLoading
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object ApiRequestHandler {
    suspend fun <Res> makeSuspendApiCall(
        context: Context,
        showLoading: Boolean = true,
        loadingMessage: String,
        apiCall: suspend () -> Res,
        onSuccess: (Res) -> Unit,
        onError: (String) -> Unit
    ) {
        if (showLoading) showLoading(context, loadingMessage)

        try {
            val response = apiCall()
            onSuccess(response)
        } catch (e: Exception) {
            val errorMessage = if (e is retrofit2.HttpException) {
                try {
                    val errorJson = e.response()?.errorBody()?.string()
                    JSONObject(errorJson ?: "").optString("error", "unknown error")
                } catch (ex: Exception) {
                    "unknown error"
                }
            } else {
                e.localizedMessage ?: "unknown error occurred"
            }

            Log.e("ApiRequestHandler", "API call failed: $errorMessage", e)
            onError(errorMessage)
        } finally {
            if (showLoading) hideLoading()
        }
    }
}
