package com.harshal.upzyne.adapter.leadsAdpter

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import android.util.Log
import android.util.TypedValue
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.maskPhoneNumber
import com.harshal.upzyne.model.LeadsModel
import androidx.core.graphics.drawable.toDrawable
import com.harshal.upzyne.UtilsMethods.getErrorAlertDialog
import com.harshal.upzyne.adapter.leadsAdapter.ItemClickInterface
import java.io.File
import java.util.Date

class OwnedLeadsAdapter(private val leads: List<LeadsModel.LeadsModelDataClasss.LeadData>, val itemClickInterface: ItemClickInterface) :
    RecyclerView.Adapter<OwnedLeadsAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name = view.findViewById<TextView>(R.id.user_name)
        val phone = view.findViewById<TextView>(R.id.user_phone)
        val score = view.findViewById<TextView>(R.id.progress)
        val status = view.findViewById<TextView>(R.id.label_new_lead)
        val course = view.findViewById<TextView>(R.id.course)
        val joined = view.findViewById<TextView>(R.id.joinedDate)
        val engaged = view.findViewById<TextView>(R.id.engagedDate)
        val viewLay = view.findViewById<LinearLayout>(R.id.itemLead)
        val status_icon = view.findViewById<TextView>(R.id.status_icon)
        val budge = view.findViewById<ImageView>(R.id.tv_otpVerification)
        val imgMenu = view.findViewById<ImageView>(R.id.more_btn)
        val btnCall = view.findViewById<ImageView>(R.id.call_btn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.item_owned_leads, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val lead = leads[position]
        val statusColor = lead.statuscolor
        val scoreColor = lead.leadscorecolor

        holder.name.text = lead.name
        holder.phone.text = maskPhoneNumber(lead.phonenumber)

        val drawable = ContextCompat.getDrawable(
            holder.itemView.context, R.drawable.shape_circle_red
        ) as GradientDrawable
        drawable.setStroke(3, scoreColor.toColorInt())
        holder.score.background = drawable
        holder.score.text = "${lead.leadscore}%"

        val drawable1 = holder.status.background?.mutate()
        val colorWithAlpha = (statusColor.toColorInt() and 0x00FFFFFF) or (0x30 shl 24)
        drawable1?.setColorFilter(colorWithAlpha, PorterDuff.Mode.SRC_ATOP)
        holder.status.background = drawable1
        holder.status.setTextColor(statusColor.toColorInt())

        holder.status.text = lead.statuslabel
        holder.course.text = lead.programme
        holder.course.paintFlags = holder.course.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        holder.joined.text = "joined: ${lead.leaddate}"
        holder.engaged.text = "engaged: ${lead.timeago}"
        holder.status_icon.text = lead.sourcebadge
        holder.budge.visibility = if (lead.isotpverified) View.VISIBLE else View.GONE

        val backgroundDrawable =
            ContextCompat.getDrawable(holder.itemView.context, R.drawable.left_glass)
        if (backgroundDrawable is LayerDrawable) {
            val leftBorder = backgroundDrawable.findDrawableByLayerId(R.id.left_border)
            if (leftBorder is GradientDrawable) {
                leftBorder.setColor(statusColor.toColorInt())
            }
            holder.viewLay.background = backgroundDrawable
        }

        holder.imgMenu.setOnClickListener {
            showPopupMenu(holder.itemView.context, holder.imgMenu)
        }
       holder.course.setOnClickListener {
           showCouserPopupMenu(holder.itemView.context, lead)
        }

        holder.btnCall.setOnClickListener {
            showCallPopupMenu(holder.itemView.context, holder.btnCall, lead.phonenumber)
        }

        holder.score.setOnClickListener {
            itemClickInterface.onLeadScoreClick(lead.leadid)
        }
    }

    override fun getItemCount(): Int = leads.size
}

data class CallLogEntry(
    val number: String,
    val type: String,
    val date: Date,
    val durationSeconds: Long
)

// ======================== COMMON HELPERS ===========================

private fun createPopupWindow(context: Context, popupView: View): PopupWindow {
    return PopupWindow(
        popupView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true
    ).apply {
        elevation = 10f
        isOutsideTouchable = true
        isFocusable = true
        setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
    }
}

private fun dimBackground(context: Context, popupWindow: PopupWindow): View {
    val parentView = (context as Activity).window.decorView.rootView
    val dimView = View(context).apply {
        setBackgroundColor("#80000000".toColorInt())
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
    }
    (parentView as ViewGroup).addView(dimView)
    popupWindow.setOnDismissListener { parentView.removeView(dimView) }
    return dimView
}

private fun positionPopup(
    anchor: View, popupWindow: PopupWindow, popupView: View, context: Context
) {
    val marginPx = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, 20f, context.resources.displayMetrics
    ).toInt()

    popupView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
    val popupWidth = popupView.measuredWidth
    val popupHeight = popupView.measuredHeight

    val displayMetrics = context.resources.displayMetrics
    val screenWidth = displayMetrics.widthPixels
    val screenHeight = displayMetrics.heightPixels

    val location = IntArray(2)
    anchor.getLocationOnScreen(location)
    val anchorX = location[0]
    val anchorY = location[1]

    val x = anchorX.coerceIn(marginPx, screenWidth - popupWidth - marginPx)
    val showBelow = anchorY + anchor.height + popupHeight + marginPx <= screenHeight

    if (showBelow) {
        popupWindow.showAsDropDown(anchor, x - anchorX, 0)
    } else {
        val y = (anchorY - popupHeight).coerceAtLeast(marginPx)
        popupWindow.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
    }
}

// =================== Popup Menu Implementations ===================

private fun showCallPopupMenu(context: Context, btnCall: ImageView, contactNumber: String) {
    val inflater = LayoutInflater.from(context)
    val popupView = inflater.inflate(R.layout.menu_call_popup, null)
    val popupWindow = createPopupWindow(context, popupView)

    val clickListener = View.OnClickListener { view ->
        popupWindow.dismiss()
        when (view.id) {
            R.id.mnPhone1 -> {
                registerPhoneStateListener(context, contactNumber)

                // Example: make call after 2 seconds delay
                Handler(Looper.getMainLooper()).postDelayed({
                    makePhoneCall(context, contactNumber)
                }, 1000)/*Toast.makeText(context, "clicked", Toast.LENGTH_SHORT).show()
                val callIntent = Intent(Intent.ACTION_DIAL).apply {
                    data = "tel:$phone1".toUri()
                }
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    context.startActivity(callIntent)
                } else {
                    ActivityCompat.requestPermissions(
                        context as Activity,
                        arrayOf(Manifest.permission.CALL_PHONE),
                        1
                    )
                }*/
            }

            R.id.mnPhone2 -> {
                Toast.makeText(context, "clicked", Toast.LENGTH_SHORT).show()
            }
        }
    }

    popupView.findViewById<TextView>(R.id.mnPhone1).apply {
        text = contactNumber
        setOnClickListener(clickListener)
    }
    popupView.findViewById<View>(R.id.mnPhone2).setOnClickListener(clickListener)

    dimBackground(context, popupWindow)
    positionPopup(btnCall, popupWindow, popupView, context)
}
// =================== Couse Popup Menu Implementations komal ===================

private fun showCouserPopupMenu(context: Context, lead: LeadsModel.LeadsModelDataClasss.LeadData) {
    val inflater = LayoutInflater.from(context)
    val popupView = inflater.inflate(R.layout.menu_couseitem_popup, null)

    val salesText = popupView.findViewById<TextView>(R.id.salesText)
    salesText.text = lead.salespitch

    val upsellText = popupView.findViewById<TextView>(R.id.upsellpitch)
    upsellText.text = lead.upsellpitch

    val uspLayout = popupView.findViewById<LinearLayout>(R.id.uspText)
    uspLayout.removeAllViews()

    val uspItems = lead.usp.split("\\n", "\n") // support both escaped and real line breaks

    for (item in uspItems) {
        val itemLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            val image = ImageView(context).apply {
                setImageResource(R.drawable.ic_check_circle_green)
                layoutParams = LinearLayout.LayoutParams(40, 40).apply {
                    marginEnd = 12
                }
            }

            val text = TextView(context).apply {
                text = item.trim()
                textSize = 14f
                setTextColor(Color.BLACK)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            addView(image)
            addView(text)
        }

        uspLayout.addView(itemLayout)
    }

    val popupWindow = PopupWindow(popupView,
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
        true)

    popupWindow.elevation = 10f
    popupWindow.isOutsideTouchable = true

    popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0)

    val gotItBtn = popupView.findViewById<Button>(R.id.gotit)
    gotItBtn.setOnClickListener {
        popupWindow.dismiss()
    }

}





private fun makePhoneCall(context: Context, phoneNumber: String) {
    val callIntent = Intent(Intent.ACTION_DIAL)
    callIntent.data = Uri.parse("tel:$phoneNumber")
    if (ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) != PackageManager.PERMISSION_GRANTED
    ) {
        ActivityCompat.requestPermissions(
            context as Activity, arrayOf(Manifest.permission.CALL_PHONE), 200
        )
        return
    }
    context.startActivity(callIntent)
}

private var phoneStateListener: PhoneStateListener? = null
fun registerPhoneStateListener(context: Context, contactNumber: String) {
    val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

    phoneStateListener = object : PhoneStateListener() {
        private var isCallActive = false

        override fun onCallStateChanged(state: Int, incomingNumber: String?) {
            Log.d("onCallEnded", "State: $state")
            when (state) {
                TelephonyManager.CALL_STATE_OFFHOOK -> {
                    isCallActive = true
                    Log.d("onCallEnded", "Call started")
                }

                TelephonyManager.CALL_STATE_IDLE -> {
                    if (isCallActive) {
                        isCallActive = false
                        Log.d("onCallEnded", "Call ended")
                        onCallEnded(context, contactNumber)
                    }
                }

                TelephonyManager.CALL_STATE_RINGING -> {
                    Log.d("onCallEnded", "Phone is ringing")
                }
            }
        }
    }
    telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE)
}

private fun onCallEnded(context: Context, phoneNumber: String) {
    val logEntry = getLatestCallLog(context, phoneNumber)
    if (logEntry != null) {
        //val endTime = Date(logEntry.date.time + logEntry.durationSeconds * 1000)
        val endTime = Date(System.currentTimeMillis())
        Log.d("end_time", endTime.toString())
        val recording = findSamsungCallRecording(phoneNumber, endTime)
        val message = if (recording != null) {
            "Recording found - ${recording.absolutePath}"
        } else {
            "Recording not found"
        }
        getErrorAlertDialog(context, message)
    } else {
        getErrorAlertDialog(context, "No call log found for $phoneNumber")
    }
}

private fun findSamsungCallRecording(phoneNumber: String, callEndTime: Date): File? {
    val paths = listOf(
        "/storage/emulated/0/Call/",
        "/storage/emulated/0/Sounds/Call/",
        "/storage/emulated/0/Recordings/Call/"
    )
    val timeWindow = 2 * 60 * 1000L // ±2 min
    for (path in paths) {
        val dir = File(path)
        if (dir.exists() && dir.isDirectory) {
            val suffixes = listOf(".mp3", ".m4a", ".aac", ".wav", ".amr")
            val files = dir.listFiles { file ->
                val matchName = file.name.contains(phoneNumber)
                val matchType = suffixes.any { file.name.endsWith(it, true) }
                val matchTime = kotlin.runCatching {
                    val fileModified = file.lastModified()
                    Math.abs(fileModified - callEndTime.time) <= timeWindow
                }.getOrDefault(false)
                matchName && matchType && matchTime
            }
            if (!files.isNullOrEmpty()) return files[0]
        }
    }
    return null
}

private fun getLatestCallLog(context: Context, phoneNumber: String): CallLogEntry? {
    val projection = arrayOf(
        CallLog.Calls.NUMBER,
        CallLog.Calls.TYPE,
        CallLog.Calls.DATE,
        CallLog.Calls.DURATION
    )

    val cursor = context.contentResolver.query(
        CallLog.Calls.CONTENT_URI,
        projection,
        "${CallLog.Calls.NUMBER} LIKE ?",
        arrayOf("%$phoneNumber%"),
        "${CallLog.Calls.DATE} DESC"
    )

    cursor?.use {
        if (it.moveToFirst()) {
            val number = it.getString(0)
            val type = it.getInt(1)
            val startDate = Date(it.getLong(2))
            val duration = it.getLong(3)
            val endDate = Date(startDate.time + duration * 1000)

            Log.d("CALL_LOG_DEBUG", "Start: $startDate, End: $endDate, Duration: $duration sec")

            return CallLogEntry(number, getCallType(type), endDate, duration)
        }
    }
    return null
}

private fun getCallType(type: Int): String = when (type) {
    CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
    CallLog.Calls.INCOMING_TYPE -> "Incoming"
    CallLog.Calls.MISSED_TYPE -> "Missed"
    else -> "Unknown"
}

@SuppressLint("MissingInflatedId")
private fun showPopupMenu(context: Context, imgMenu: ImageView) {
    val inflater = LayoutInflater.from(context)
    val popupView = inflater.inflate(R.layout.menu_leaditem_popup, null)
    val popupWindow = createPopupWindow(context, popupView)

    val clickListener = View.OnClickListener {
        popupWindow.dismiss()
        Toast.makeText(context, "clicked", Toast.LENGTH_SHORT).show()
    }

    val menuItemIds = listOf(
        R.id.mnSmartInsights,
        R.id.mnChangeOwner,
        R.id.mnAddNote,
        R.id.mnSetReminder,
        R.id.mnChangeStage,
        R.id.mnEmailLead,
        R.id.mnWhatsappChat,
        R.id.mnLeadScore
    )

    menuItemIds.forEach { id ->
        popupView.findViewById<View>(id).setOnClickListener(clickListener)
    }

    dimBackground(context, popupWindow)
    positionPopup(imgMenu, popupWindow, popupView, context)
}
