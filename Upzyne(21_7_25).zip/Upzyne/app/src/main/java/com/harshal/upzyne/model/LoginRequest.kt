package com.harshal.upzyne.model

data class LoginRequest(
    val username: String,
    val password: String,
    val clientId: String,
    val tenantId: Int,
    val deviceId: String)
