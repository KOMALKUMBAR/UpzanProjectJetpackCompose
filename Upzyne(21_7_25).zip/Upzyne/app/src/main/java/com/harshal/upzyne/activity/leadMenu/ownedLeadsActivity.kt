package com.harshal.upzyne.activity.leadsMenu

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.adapter.leadsAdapter.ItemClickInterface
import com.harshal.upzyne.adapter.leadsAdpter.OwnedLeadsAdapter
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityOwnedLeadsBinding
import com.harshal.upzyne.model.LeadsModel
import kotlinx.coroutines.launch

class ownedLeadsActivity : AppCompatActivity(), ItemClickInterface {
    private lateinit var binding: ActivityOwnedLeadsBinding
    private lateinit var ownedLeadsAdpter: OwnedLeadsAdapter
    private lateinit var bearerToken: String
    private lateinit var userFullName: String
    private lateinit var activityName: String
    private lateinit var sharedPref: SharedPreferences
    private val leadList = mutableListOf<LeadsModel.LeadsModelDataClasss.LeadData>()
    private val leadScoreList = mutableListOf<LeadsModel.LeadsScoreResponse>()
    private val loadedLeadIds = mutableSetOf<Int>()
    private var isSearchMode = false

    private var offset = 0
    private val limit = 20
    private var isLoading = false
    private var isLastPage = false
    private var _totalCount: String = "0"
    private var totalLeadsAvailable = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOwnedLeadsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fname", "") ?: ""
        activityName = getString(R.string.owned_leads)
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "") ?: ""}"
        binding.titleText.text = "$userFullName - $activityName [$_totalCount]"
        binding.recyclerviewOwnLeads.layoutManager = LinearLayoutManager(this)
        ownedLeadsAdpter = OwnedLeadsAdapter(leadList,this)
        binding.recyclerviewOwnLeads.adapter = ownedLeadsAdpter

        setThemeBackground(this, binding.contentFrame)

        binding.imgArrow.setOnClickListener { finish() }

        binding.recyclerviewOwnLeads.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (!recyclerView.canScrollVertically(1) && !isLoading && !isLastPage) {
                    fetchAssignedLeads(limit, offset)
                }
            }
        })

        binding.searchEditText.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString().trim()
                if (query.isNotEmpty()) {
                    isSearchMode = true
                    searchLeads(query)
                } else {
                    isSearchMode = false
                    resetAndFetch()
                }
            }

            override fun afterTextChanged(s: android.text.Editable?){}
        })

        fetchAssignedLeads(limit, offset)
    }

    private fun searchLeads(query: String) {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.searchAssignedLeads(
                    bearerToken,
                    query,
                    limit = 20,
                    offset = 0
                )

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ownedLeadsActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val leads = response.body() ?: emptyList()
                        leadList.clear()
                        loadedLeadIds.clear()
                        leadList.addAll(leads)
                        ownedLeadsAdpter.notifyDataSetChanged()

                        binding.titleText.text = "$userFullName - $activityName [${leads.size}]"

                        if (leads.isEmpty()) {
                            binding.emptyState.visibility = View.VISIBLE
                            binding.recyclerviewOwnLeads.visibility = View.GONE

                        } else {
                            binding.emptyState.visibility = View.GONE
                            binding.recyclerviewOwnLeads.visibility = View.VISIBLE
                        }
                    },
                    onError = {
                        Log.e("LEAD_SEARCH", "Error: $it")
                        binding.emptyState.visibility = View.VISIBLE
                        binding.recyclerviewOwnLeads.visibility = View.GONE
                    }
                )
            } catch (e: Exception) {
                Log.e("LEAD_SEARCH", "Exception: ${e.message}")
                binding.emptyState.visibility = View.VISIBLE
                binding.recyclerviewOwnLeads.visibility = View.GONE
            }
        }
    }

    private fun resetAndFetch() {
        offset = 0
        isLastPage = false
        leadList.clear()
        loadedLeadIds.clear()
        ownedLeadsAdpter.notifyDataSetChanged()
        fetchAssignedLeads(limit,offset)
        }

    private fun fetchAssignedLeads(limit: Int, offset: Int) {
        if (!checkNetworkAndShowMessage(this)) return
        isLoading = true

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getAssignedLeads(bearerToken, limit, offset)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ownedLeadsActivity,
                    showLoading = offset == 0,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        val newLeads = response.body() ?: emptyList()
                        Log.d("LEAD_DEBUG", "Fetched: ${newLeads.size} leads at offset $offset")

                        if (offset == 0 && newLeads.isEmpty()) {
                            // Empty data on first load
                            binding.emptyState.visibility = View.VISIBLE
                            binding.recyclerviewOwnLeads.visibility = View.GONE
                            isLastPage = true
                        } else {
                            // Update total count and title
                            if (offset == 0 && newLeads.isNotEmpty()) {
                                totalLeadsAvailable = newLeads.first().totalcount
                                _totalCount = totalLeadsAvailable.toString()
                                binding.titleText.text =
                                    "$userFullName - $activityName [$_totalCount]"
                            }

                            // Filter out duplicates
                            val filteredNewLeads = newLeads.filter { loadedLeadIds.add(it.leadid) }

                            if (filteredNewLeads.isNotEmpty()) {
                                leadList.addAll(filteredNewLeads)
                                ownedLeadsAdpter.notifyItemRangeInserted(
                                    leadList.size - filteredNewLeads.size,
                                    filteredNewLeads.size
                                )

                                binding.emptyState.visibility = View.GONE
                                binding.recyclerviewOwnLeads.visibility = View.VISIBLE

                                Toast.makeText(
                                    this@ownedLeadsActivity,
                                    "${leadList.size} out of $totalLeadsAvailable leads loaded",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }

                            // Final check if there's nothing to show at all
                            if (leadList.isEmpty()) {
                                binding.emptyState.visibility = View.VISIBLE
                                binding.recyclerviewOwnLeads.visibility = View.GONE
                            }

                            // Stop pagination if all leads loaded or no more data
                            if (leadList.size >= totalLeadsAvailable || newLeads.size < limit) {
                                isLastPage = true
                            } else {
                                this@ownedLeadsActivity.offset += limit
                            }
                        }

                        isLoading = false

                    },
                    onError = { error ->
                        isLoading = false
                        UtilsMethods.AppLogger.logAndToast(
                            this@ownedLeadsActivity,
                            "EC999",
                            "OwnedLeadsActivity",
                            "fetchAssignedLeads",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                isLoading = false
                UtilsMethods.AppLogger.logAndToast(
                    this@ownedLeadsActivity,
                    "EC999",
                    "OwnedLeadsActivity",
                    "fetchAssignedLeads",
                    e
                )
            }
        }
    }

    override fun onLeadScoreClick(leadId: Int) {
        isLoading = true

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getLeadScore(bearerToken, leadId)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ownedLeadsActivity,
                    showLoading = true,
                    loadingMessage = getString(R.string.fetching_data),
                    apiCall = { call },
                    onSuccess = { response ->
                        isLoading = false
                        val leadsScore = response.body()?.data ?: emptyList()
                        showScorePopup(this@ownedLeadsActivity,leadsScore)
                    },
                    onError = { error ->
                        isLoading = false
                        UtilsMethods.AppLogger.logAndToast(
                            this@ownedLeadsActivity,
                            "EC999",
                            "OwnedLeadsActivity",
                            "fetchAssignedLeads",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                isLoading = false
                UtilsMethods.AppLogger.logAndToast(
                    this@ownedLeadsActivity,
                    "EC999",
                    "OwnedLeadsActivity",
                    "fetchAssignedLeads",
                    e
                )
            }
        }
    }

    private fun showScorePopup(
        context: Context,
        leadsScore: List<LeadsModel.LeadsScoreResponse.LeadScoreData>
    ) {
        val leadScoreData = leadsScore.first()
        val inflater = LayoutInflater.from(context)
        val popupView = inflater.inflate(R.layout.activity_lead_score_details, null)

        val salesText = popupView.findViewById<TextView>(R.id.tvScore)
        salesText.text = leadScoreData.percentage_score.toString()

        val upsellText = popupView.findViewById<TextView>(R.id.tvLevel)
        upsellText.text = leadScoreData.suggestions

        val popupWindow = PopupWindow(popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true)

        popupWindow.elevation = 10f
        popupWindow.isOutsideTouchable = true

        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0)

        val gotItBtn = popupView.findViewById<Button>(R.id.btnClose)
        gotItBtn.setOnClickListener {
            popupWindow.dismiss()
        }

    }
}