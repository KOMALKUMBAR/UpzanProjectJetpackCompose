package com.harshal.upzyne.adapter.leadsAdapter

interface ItemClickInterface {
    fun onLeadScoreClick(leadId: Int)
}