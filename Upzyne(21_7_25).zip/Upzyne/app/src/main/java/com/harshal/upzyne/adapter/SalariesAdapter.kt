package com.harshal.upzyne.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.activity.hrmsMenu.SalarySlipActivity
import com.harshal.upzyne.databinding.ItemSalarySlipBinding
import com.harshal.upzyne.model.SalariesList
import java.time.Month

class SalariesAdapter(private val salariesList: List<SalariesList>) :
RecyclerView.Adapter<SalariesAdapter.SalariesViewHolder>() {

    inner class SalariesViewHolder(val binding: ItemSalarySlipBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SalariesViewHolder {
        val binding = ItemSalarySlipBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SalariesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SalariesViewHolder, position: Int) {
        setThemeBackground(holder.itemView.context, holder.binding.laySalaryslip)

        val item = salariesList[position]
        val salaryMonth = "${Month.of(item.month).name.lowercase()} ${item.year}"
        holder.binding.tvMonth.text = salaryMonth
        holder.binding.tvAttendance.text = item.attendance
        holder.binding.tvReceived.text = item.received
        holder.binding.tvPaidOn.text = item.paidon

        holder.binding.laySalaryslip.setOnClickListener {
            val intent = Intent(holder.itemView.context, SalarySlipActivity::class.java)
            intent.putExtra("salaryMonth", item.month)
            intent.putExtra("salaryYear", item.year)
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = salariesList.size
}