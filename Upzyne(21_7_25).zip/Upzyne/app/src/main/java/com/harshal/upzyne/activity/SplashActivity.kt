package com.harshal.upzyne.activity

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import androidx.appcompat.app.AppCompatActivity
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.databinding.ActivityMainBinding
import com.harshal.upzyne.UtilsMethods.setThemeBackground

class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var sharedPref: SharedPreferences
    companion object{
       private  const val TAG ="SplashActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val isLoggedIn = sharedPref.getBoolean("is_logged_in", false)
        setThemeBackground(this, binding.rootLayout)

        binding.rootLayout.post {
            val screenHeight = binding.rootLayout.height
            val logoHeight = binding.appLogo.height
            val centerY = screenHeight / 2.5 - logoHeight / 2.5
            val bottomY = screenHeight - binding.appLogo.bottom

            // ⏳ Delay 2 seconds before doing anything
            Handler(Looper.getMainLooper()).postDelayed({
                binding.appName.visibility = View.GONE
                binding.appLogo.visibility = View.VISIBLE

                val moveUp = TranslateAnimation(
                    0f, 0f, bottomY.toFloat(), -centerY.toFloat()
                ).apply {
                    duration = 1000
                    fillAfter = true
                    setAnimationListener(object : Animation.AnimationListener {
                        override fun onAnimationStart(animation: Animation?) {}

                        override fun onAnimationRepeat(animation: Animation?) {}

                        override fun onAnimationEnd(animation: Animation?) {
                            if (isLoggedIn) {
                                startActivity(Intent(this@SplashActivity, HomeActivity::class.java))
                            } else {
                                startActivity(Intent(this@SplashActivity, LoginActivity::class.java))
                            }
                            finish() // Optional: remove current activity from back stack
                        }
                    })
                }

                binding.appLogo.startAnimation(moveUp)
            }, 2000)
        }
    }
}
