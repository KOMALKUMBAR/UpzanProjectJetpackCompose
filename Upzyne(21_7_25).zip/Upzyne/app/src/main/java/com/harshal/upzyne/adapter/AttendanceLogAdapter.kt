package com.harshal.upzyne.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.model.AttendanceLogResponse

class AttendanceLogAdapter(private val list: List<AttendanceLogResponse>) :
    RecyclerView.Adapter<AttendanceLogAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dateText: TextView = view.findViewById(R.id.dateformate)
        val typeText: TextView = view.findViewById(R.id.fulldayTxt)
        val timeInText: TextView = view.findViewById(R.id.timeTxt)
        val timeOutText: TextView = view.findViewById(R.id.coinTime)
        val card1: View = view.findViewById(R.id.card1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_attendance_logs, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val context = holder.itemView.context
        setThemeBackground(context, holder.card1)

        val item = list[position]
        holder.dateText.text = item.attendancedate
        holder.typeText.text = item.daytype ?: "Absent"

        holder.timeInText.text = item.logintime?.takeIf { it.length >= 16 }?.substring(11, 16) ?: "N/A"
        holder.timeOutText.text = item.logouttime?.takeIf { it.length >= 16 }?.substring(11, 16) ?: "N/A"
    }

}