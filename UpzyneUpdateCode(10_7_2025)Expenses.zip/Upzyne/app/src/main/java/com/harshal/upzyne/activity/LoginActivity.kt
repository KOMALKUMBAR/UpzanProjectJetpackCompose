package com.harshal.upzyne.activity

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.TextWatcher
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.isVisible
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.databinding.ActivityLoginBinding
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.getAndroidId
import com.harshal.upzyne.UtilsMethods.getErrorAlertDialog
import com.harshal.upzyne.model.ClientRequest
import com.harshal.upzyne.model.LoginRequest
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.UtilsMethods.togglePasswordVisibility

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var _clientId: String
    private var _tenantId: Int = 0
    private lateinit var _userName: String
    private lateinit var _userPassword: String
    private val PERMISSION_REQUEST_CODE = 1000
    private val OVERLAY_PERMISSION_REQUEST_CODE = 1001
    var isPasswordVisible = false



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)  //for screen within the window
        setThemeBackground(this, null)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)

        val ipAddress = UtilsMethods.getActiveIpAddress(this)
        Log.d("NetworkInfo", ipAddress.toString())

        // Check if Android version is below 11
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            val message =
                "Your device is running an Android version below 11.\nSome app features may be limited or not work correctly."
            getErrorAlertDialog(this, message)
        }

        try {
            startAppFlow()
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC003", "LoginActivity", "PermissionCheck", e)
        }

        binding.rootLayout.setOnClickListener {
            currentFocus?.let { view ->
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(view.windowToken, 0)
                view.clearFocus()
            }
        }

        binding.imgBack.setOnClickListener {
            when {
                binding.layResetpassword.isVisible -> {
                    binding.layForgetpassword.visibility = View.VISIBLE
                    binding.layResetpassword.visibility = View.GONE
                }

                binding.layForgetpassword.isVisible -> {
                    binding.layLogin.visibility = View.VISIBLE
                    binding.layForgetpassword.visibility = View.GONE
                }

                binding.layLogin.isVisible -> {
                    binding.layClientidValidate.visibility = View.VISIBLE
                    binding.layLogin.visibility = View.GONE
                    binding.imgBack.visibility = View.INVISIBLE
                }

                else -> {
                    binding.imgBack.visibility = View.INVISIBLE
                }
            }
        }

        //Client Id Window
        binding.etClientId.requestFocus()
        binding.etClientId.addTextChangedListener {
            _clientId = it.toString().trim()
            if (_clientId.isNotEmpty()) {
                binding.btnValidate.setTextColor(Color.WHITE)
                binding.btnValidate.setBackgroundResource(R.drawable.shape_color_btn)
            } else {
                binding.btnValidate.setTextColor(Color.BLACK)
                binding.btnValidate.setBackgroundResource(R.drawable.shape_blank_btn)
            }
        }

        binding.btnValidate.setOnClickListener {
            try {
                if (binding.btnValidate.currentTextColor == Color.WHITE) {
                    fetchClientId(_clientId)
                    binding.etClientId.clearFocus()
                    binding.etEmailAddress.requestFocus()
                    val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.hideSoftInputFromWindow(binding.etClientId.windowToken, 0)
                }
                else if (binding.btnValidate.currentTextColor == Color.BLACK) {
                    binding.etClientId.error = "please enter client id"
                }

            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this,
                    "EC004",
                    "LoginActivity",
                    "btnValidate.setOnClickListener",
                    e
                )
            }
        }



        //Login Window
        binding.etEmailAddress.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                val original = s.toString()
                _userName = original
                    .trim()
                    .replace(Regex("\\s+"), ".")
                    .replace(Regex("\\.+"), ".")
                    .lowercase()

                if (original != _userName) {
                    binding.etEmailAddress.removeTextChangedListener(this)
                    binding.etEmailAddress.setText(_userName)
                    binding.etEmailAddress.setSelection(_userName.length)
                    binding.etEmailAddress.addTextChangedListener(this)
                }
            }
        })

        binding.etEmailPassword.addTextChangedListener {
            _userPassword = it.toString().trim()
            if (_userPassword.isNotEmpty()) {
                binding.btnLogin.setTextColor(Color.WHITE)
                binding.btnLogin.setBackgroundResource(R.drawable.shape_color_btn)
            } else {
                binding.btnLogin.setTextColor(Color.BLACK)
                binding.btnLogin.setBackgroundResource(R.drawable.shape_blank_btn)
            }
        }
        //icon Password

        binding.isPasswordVisible.setOnClickListener {
            isPasswordVisible = togglePasswordVisibility(binding.etEmailPassword, binding.isPasswordVisible, isPasswordVisible)
        }


        binding.tvForgetPassword.setOnClickListener {
            binding.layLogin.visibility = View.GONE
            binding.layForgetpassword.visibility = View.VISIBLE
        }
        binding.tvForgetPassword.paintFlags = binding.tvForgetPassword.paintFlags or Paint.UNDERLINE_TEXT_FLAG

        binding.btnLogin.setOnClickListener {
            try {
                if (binding.btnLogin.currentTextColor == Color.WHITE) {
                    val email = _userName
                    val password = _userPassword
                    val clientid = _clientId
                    val deviceId = getAndroidId(this)


                    Log.d("deviceId", "$deviceId / $clientid")
                    if (email.isNotEmpty() || password.isNotEmpty()) {
                        fetchLogin(email, password, clientid, _tenantId, deviceId)
                    } else {
                        Toast.makeText(
                            this@LoginActivity,
                            "enter email id or password",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else if (binding.btnLogin.currentTextColor == Color.BLACK) {
                    if (binding.etEmailAddress.text.isNullOrEmpty()){
                        binding.etEmailAddress.error = "please enter username"
                    } else {
                        binding.etEmailPassword.error = "please enter password"
                    }
                }
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this,
                    "EC005",
                    "LoginActivity",
                    "btnLogin.setOnClickListener",
                    e
                )
            }
        }

        //Forget Password Window
        binding.tvBackLogin.setOnClickListener {
            binding.layLogin.visibility = View.VISIBLE
            binding.layForgetpassword.visibility = View.GONE
        }

        binding.etEmailAddressforget.addTextChangedListener {
            val input = it.toString().trim()
            if (input.isNotEmpty()) {
                binding.btnSendResetLink.setTextColor(Color.WHITE)
                binding.btnSendResetLink.setBackgroundResource(R.drawable.shape_color_btn)
            } else {
                binding.btnSendResetLink.setTextColor(Color.BLACK)
                binding.btnSendResetLink.setBackgroundResource(R.drawable.shape_blank_btn)
            }
        }

        binding.btnSendResetLink.setOnClickListener {
            if (binding.etEmailAddressforget.text.toString().isNotEmpty()) {
                SendPasswordResetLink()
                binding.layResetpassword.visibility = View.VISIBLE
                binding.layForgetpassword.visibility = View.GONE
            } else {
                Toast.makeText(this@LoginActivity, "enter email id", Toast.LENGTH_SHORT).show()
            }
        }

        //OTP verification
        setupOtpInputs()

        binding.otpEdt1.addTextChangedListener {
            val input = it.toString().trim()
            if (input.isNotEmpty()) {
                binding.btnSubmit.setTextColor(Color.WHITE)
                binding.btnSubmit.setBackgroundResource(R.drawable.shape_color_btn)
            } else {
                binding.btnSubmit.setTextColor(Color.BLACK)
                binding.btnSubmit.setBackgroundResource(R.drawable.shape_blank_btn)
            }
        }

        //Reset Password Window
        binding.etResetEmailPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val password = s.toString()
                binding.passwordStrengthBar.progress = calculatePasswordStrength(password)
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        binding.etConfirmResetEmailPassword.addTextChangedListener {
            val input = it.toString().trim()
            if (input.isNotEmpty()) {
                binding.btnConfirmPassword.setTextColor(Color.WHITE)
                binding.btnConfirmPassword.setBackgroundResource(R.drawable.shape_color_btn)
            } else {
                binding.btnConfirmPassword.setTextColor(Color.BLACK)
                binding.btnConfirmPassword.setBackgroundResource(R.drawable.shape_blank_btn)
            }
        }

        binding.btnConfirmPassword.setOnClickListener {
            if (binding.etConfirmResetEmailPassword.text.toString().isNotEmpty()) {
                ConfirmResetPassword()
            } else {
                Toast.makeText(this@LoginActivity, "enter email id", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun ConfirmResetPassword() {
        if (binding.etResetEmailPassword.text.toString() == binding.etConfirmResetEmailPassword.text.toString()) {
            Toast.makeText(this@LoginActivity, "password matched", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this@LoginActivity, "password miss matched", Toast.LENGTH_SHORT).show()
        }
    }

    private fun SendPasswordResetLink() {}

    private fun calculatePasswordStrength(password: String): Int {
        var strength = 0
        if (password.length >= 6) strength += 25
        if (password.length >= 10) strength += 25
        if (password.any { it.isDigit() }) strength += 20
        if (password.any { it.isUpperCase() }) strength += 15
        if (password.any { !it.isLetterOrDigit() }) strength += 15
        return strength.coerceAtMost(100)
    }

    private fun fetchLogin(userName: String, passWord: String, clientId: String, tenantId: Int, deviceId: String) {
        if (!checkNetworkAndShowMessage(this)) return

        try {
            lifecycleScope.launch {
                val request = LoginRequest(
                    username = userName,
                    password = passWord,
                    clientId = clientId,
                    tenantId = tenantId,
                    deviceId = deviceId
                )
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@LoginActivity,
                    apiCall = { ApiClient.apiService.loginClient(request) },
                    onSuccess = { response ->
                        Log.d("loginSuccess", response.data.toString())

                        with(sharedPref.edit()) {
                            putBoolean("is_logged_in", true)
                            putString("auth_token", response.data.token)
                            putString("app_username", userName)
                            putString("app_password", passWord)
                            apply()
                        }

                        startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
                        finish()
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@LoginActivity,
                            "EC006",
                            "LoginActivity",
                            "fetchLogin",
                            Exception(error)
                        )
                        Log.d("errorrr", error)
                        getErrorAlertDialog(this@LoginActivity, error)
                    }
                )
            }
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC006", "LoginActivity", "fetchLogin", e)
        }
    }

    private fun fetchClientId(clientId: String) {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val request = ClientRequest(clientId = clientId)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@LoginActivity,
                    apiCall = { ApiClient.apiService.validateClient(request) },
                    onSuccess = { response ->
                        Log.d("clientIdSuccess", response.data.toString())

                        val clientId = response.data.clientId
                        _tenantId = response.data.tenantId
                        val licenseStatus = response.data.licenseStatus

                        if (licenseStatus == "Valid"){
                            if (_clientId == clientId) {
                                binding.layLogin.visibility = View.VISIBLE
                                binding.imgBack.visibility = View.VISIBLE
                                binding.layClientidValidate.visibility = View.GONE
                                //binding.etClientId.text = null

                                with(sharedPref.edit()) {
                                    putString("base_url", response.data.baseUrl)
                                    apply()
                                }
                            }
                        } else {
                            getErrorAlertDialog(this@LoginActivity, "License Expired")
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@LoginActivity,
                            "EC007",
                            "LoginActivity",
                            "fetchClientId",
                            Exception(error)
                        )
                        getErrorAlertDialog(this@LoginActivity, error)
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(this@LoginActivity, "EC007", "LoginActivity", "fetchClientId", e)
            }
        }
    }

    private fun startAppFlow() {
        if (hasAllPermissions()) {
            initializeLoginUI()
        } else {
            requestAllPermissionsIfNeeded()
        }
    }

    // Step 1: Define required permissions based on SDK version
    private fun getRequiredPermissions(): List<String> {
        val permissions = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS
        )

        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                permissions.addAll(
                    listOf(
                        Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.READ_MEDIA_VIDEO,
                        Manifest.permission.READ_MEDIA_AUDIO
                    )
                )
            }

            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> {
                permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }

            else -> {
                permissions.addAll(
                    listOf(
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    )
                )
            }
        }

        return permissions
    }

    // Step 2: Check if all required permissions are granted
    private fun hasAllPermissions(): Boolean {
        return getRequiredPermissions().all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    // Step 3: Request only missing permissions
    private fun requestAllPermissionsIfNeeded() {
        try {
            val missingPermissions = getRequiredPermissions().filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }

            if (missingPermissions.isNotEmpty()) {
                ActivityCompat.requestPermissions(
                    this,
                    missingPermissions.toTypedArray(),
                    PERMISSION_REQUEST_CODE
                )
            } else {
                initializeLoginUI()
            }
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC008", "LoginActivity", "requestAllPermissionsIfNeeded", e)
        }
    }

    // Step 4: Handle permission result
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        try {
            if (requestCode == PERMISSION_REQUEST_CODE) {
                val denied = permissions.indices.filter {
                    grantResults[it] != PackageManager.PERMISSION_GRANTED
                }

                if (denied.isEmpty()) {
                    Toast.makeText(this, "Permissions granted successfully", Toast.LENGTH_SHORT).show()
                    initializeLoginUI()
                } else {
                    Toast.makeText(this, "Some permissions were denied", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC009", "LoginActivity", "onRequestPermissionsResult", e)
        }
    }

    // Step 5: Initialize the actual app UI logic
    private fun initializeLoginUI() {
        try {
            termPolicy()
            checkOverlayPermission()
            disableBatteryOptimization()

            val ipAddress = UtilsMethods.getActiveIpAddress(this)
            Log.d("NetworkInfo", ipAddress.toString())
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC010", "LoginActivity", "initializeLoginUI", e)
        }
    }

    // Step 6: Handle overlay permission
    private fun checkOverlayPermission() {
        try {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST_CODE)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Overlay permission check failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // Step 7: Handle battery optimization exception
    private fun disableBatteryOptimization() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = getSystemService(POWER_SERVICE) as PowerManager
                if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Battery optimization handling failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // Step 8: Overlay permission result
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        try {
            if (requestCode == OVERLAY_PERMISSION_REQUEST_CODE) {
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Overlay permission is needed for caller floating window", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Activity result error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // Optional: Terms & Privacy Policy handling
    private fun termPolicy() {
        val text = getString(R.string.policy_text)
        val spannable = SpannableString(text)

        val termsStart = text.indexOf("term")
        val privacyEnd = text.indexOf("policy") + "policy".length

        val combinedSpan = object : ClickableSpan() {
            override fun onClick(widget: View) {
                Toast.makeText(this@LoginActivity, "Terms & Privacy clicked", Toast.LENGTH_SHORT).show()
            }

            override fun updateDrawState(ds: TextPaint) {
                ds.color = Color.BLUE
                ds.isUnderlineText = true
            }
        }

        spannable.setSpan(combinedSpan, termsStart, privacyEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        binding.tvPolicy.text = spannable
        binding.tvPolicy.movementMethod = LinkMovementMethod.getInstance()
    }

    private fun setupOtpInputs() {
        val otpInputs = listOf(
            binding.otpEdt1,
            binding.otpEdt2,
            binding.otpEdt3,
            binding.otpEdt4,
            binding.otpEdt5,
            binding.otpEdt6
        )

        for (i in otpInputs.indices) {
            otpInputs[i].addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

                override fun afterTextChanged(s: Editable?) {
                    if (s?.length == 1 && i < otpInputs.size - 1) {
                        otpInputs[i + 1].requestFocus()
                    } else if (s?.isEmpty() == true && i > 0) {
                        otpInputs[i - 1].requestFocus()
                    }
                }
            })
        }
    }
}