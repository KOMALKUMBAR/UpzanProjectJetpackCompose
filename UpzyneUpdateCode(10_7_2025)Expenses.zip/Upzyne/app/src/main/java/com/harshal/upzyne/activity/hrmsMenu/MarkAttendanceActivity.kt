package com.harshal.upzyne.activity.hrmsMenu

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.harshal.upzyne.databinding.ActivityMarkattendanceBinding
import java.io.File
import android.Manifest
import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Environment
import android.util.Log
import android.view.View
import androidx.core.view.WindowCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.databinding.BottomLoginLayoutBinding
import com.harshal.upzyne.databinding.BottomLogoutLayoutBinding
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.hideLoading
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.UtilsMethods.showLoading
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.time.ZoneId
import java.time.format.DateTimeFormatterBuilder
import java.time.temporal.ChronoField
import kotlin.math.abs

class MarkAttendanceActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMarkattendanceBinding
    private lateinit var imageUri: Uri
    private val CAMERA_REQUEST_CODE = 1001
    private val CAMERA_PERMISSION_CODE = 2001
    private lateinit var sharedPref: SharedPreferences
    lateinit var imagePath1: String
    lateinit var userFullName: String
    lateinit var userLoginTime: String
    lateinit var userLogoutTime: String
    lateinit var userWorkingHrs: String
    lateinit var userDayType: String

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMarkattendanceBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)  //for screen within the window
        setThemeBackground(this, null)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fullname", "").toString()
        binding.swipinTxt.text = "${userFullName.trim().split(" ").firstOrNull() ?: ""} - swipe in"
        WindowCompat.setDecorFitsSystemWindows(window, true)

        val currentDate = Date()
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        val formattedDate = dateFormat.format(currentDate)

        binding.dateTxt.text = formattedDate

        binding.scanImg.setOnClickListener() {
            checkCameraPermissionAndOpen()
        }

        binding.imgArrow.setOnClickListener {
            finish()
        }

        fetchTodayAttendance()
    }

    private fun fetchTodayAttendance() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            binding.loadingOverlay.visibility = View.VISIBLE

            try {
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@MarkAttendanceActivity,
                    apiCall = {
                        val token = sharedPref.getString("auth_token", "") ?: ""
                        ApiClient.apiService.getTodayAttendance("Bearer $token")
                    },
                    onSuccess = { response ->
                        binding.loadingOverlay.visibility = View.GONE
                        response.data?.let { Log.d("AttendanceSuccess", it.toString()) }

                        val apiImagePath =
                            sharedPref.getString("base_url", "") + response.data?.loginimage
                        Log.d("AttendanceImagePath", apiImagePath)

                        if (response.data != null) {
                            binding.layBottom.visibility = View.VISIBLE
                            binding.ivshare.setOnClickListener {
                                processLoginLogoutImage(response.data!!.logintime)
                            }

                            binding.swipinTxt.text =
                                "${userFullName.trim().split(" ").firstOrNull() ?: ""} - swipe out"

                            Glide.with(this@MarkAttendanceActivity).load(apiImagePath)
                                .placeholder(R.drawable.profile).error(R.drawable.noimage)
                                .into(binding.profileOutImg)
                        } else {
                            binding.swipinTxt.text =
                                "${userFullName.trim().split(" ").firstOrNull() ?: ""} - swipe in"
                        }

                        response.data?.let { Log.d("AttendanceLogintime", it.logintime) }

                        val dateTimeFlexibleFormatter =
                            DateTimeFormatterBuilder().appendPattern("yyyy-MM-dd'T'HH:mm:ss")
                                .appendFraction(ChronoField.NANO_OF_SECOND, 0, 6, true)
                                .toFormatter()

                        val formattedLogin = runCatching {
                            LocalDateTime.parse(
                                response.data!!.logintime, dateTimeFlexibleFormatter
                            ).format(DateTimeFormatter.ofPattern("MMM-dd-yyyy | hh:mm a"))
                        }.getOrElse { "Invalid Date" }

                        val formattedLogout = runCatching {
                            LocalDateTime.parse(
                                response.data!!.logouttime, dateTimeFlexibleFormatter
                            ).format(DateTimeFormatter.ofPattern("MMM-dd-yyyy | hh:mm a"))
                        }.getOrElse { "Invalid Date" }

                        binding.dataTimeTxt.text = formattedLogin
                        userLoginTime = formattedLogin
                        userLogoutTime = formattedLogout
                        userWorkingHrs = response.data?.totalworkinghours.toString()
                        userDayType = response.data?.daytype.toString()
                    },
                    onError = { error ->
                        binding.loadingOverlay.visibility = View.GONE
                        UtilsMethods.AppLogger.logAndToast(
                            this@MarkAttendanceActivity,
                            "EC011",
                            "MarkAttendanceActivity",
                            "fetchTodayAttendance",
                            Exception(error)
                        )
                    })
            } catch (e: Exception) {
                binding.loadingOverlay.visibility = View.GONE
                UtilsMethods.AppLogger.logAndToast(
                    this@MarkAttendanceActivity,
                    "EC011",
                    "MarkAttendanceActivity",
                    "fetchTodayAttendance",
                    e
                )
            }
        }
    }

    private fun processLoginLogoutImage(userLogin: String) {
        val loginTimeString = userLogin // ISO format input
        val loginTime = parseIsoTimeToMillis(loginTimeString)

        val matchedImage = getClosestImageUri(loginTime)
        Log.d("FileUri2", " $matchedImage")
        matchedImage?.let {
            UtilsMethods.shareImageOnWhatsApp(this, it)
        } ?: Toast.makeText(this, "No matching file found", Toast.LENGTH_SHORT).show()
    }

    private fun parseIsoTimeToMillis(isoTime: String): Long {
        return try {
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS")
            val localDateTime = LocalDateTime.parse(isoTime, formatter)
            val zoneId = ZoneId.systemDefault()
            localDateTime.atZone(zoneId).toInstant().toEpochMilli()
        } catch (e: Exception) {
            e.printStackTrace()
            System.currentTimeMillis() // fallback to current time
        }
    }

    private fun getClosestImageUri(targetTime: Long): Uri? {
        val folder = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "Upzyne/loginlogout"
        )

        if (!folder.exists() || !folder.isDirectory) return null

        val imageFiles = folder.listFiles() ?: return null
        if (imageFiles.isEmpty()) return null

        val allowedTimeDiff = 2 * 60 * 1000L // 2 minutes in milliseconds

        var closestFile: File? = null
        var minDiff = Long.MAX_VALUE

        for (file in imageFiles) {
            val timeDiff = abs(file.lastModified() - targetTime)
            if (timeDiff < minDiff && timeDiff <= allowedTimeDiff) {
                minDiff = timeDiff
                closestFile = file
            }
        }
        Log.d("FileUri1", " $closestFile")

        return closestFile?.let {
            try {
                FileProvider.getUriForFile(
                    this, "${applicationContext.packageName}.fileprovider", it
                )
            } catch (e: IllegalArgumentException) {
                e.printStackTrace()
                null
            }
        }
    }

    private fun showBottomLogoutDialog() {
        try {
            fetchTodayAttendance()

            val dialog = BottomSheetDialog(this)

            val binding = BottomLogoutLayoutBinding.inflate(layoutInflater)
            dialog.setContentView(binding.root)
            dialog.setCanceledOnTouchOutside(false)

            binding.titleName.text = userFullName
            val bitmap = UtilsMethods.compressPhoto(imagePath1, 800, 800) // Target width & height
            binding.profileOutImg.setImageBitmap(bitmap)
            binding.tvLogoutTime.text = userLogoutTime
            binding.tvWorkingHrs.text = "$userWorkingHrs hrs ($userDayType)"

            binding.btnCancel.setOnClickListener {
                dialog.dismiss()
            }
            binding.btnConfirm.setOnClickListener {
                lifecycleScope.launch {
                    val isSuccess = uploadSwipeInData(imagePath1)
                    if (isSuccess) {
                        binding.ivshare.visibility = View.VISIBLE
                        binding.logoutText.visibility = View.GONE
                        binding.logoutSuccessfulText.visibility = View.VISIBLE
                        binding.btnCancel.visibility = View.GONE
                        binding.btnConfirm.visibility = View.GONE
                        binding.layCallDetails.visibility = View.GONE
                        binding.btnok.visibility = View.VISIBLE
                    }
                    hideLoading()
                }
            }
            binding.btnok.setOnClickListener {
                dialog.dismiss()
            }
            binding.ivshare.setOnClickListener {
                val bitmap = UtilsMethods.takeScreenshotOfView(binding.layLogout)
                val uri = UtilsMethods.saveBitmapToFile(bitmap, this)

                uri?.let {
                    UtilsMethods.shareImageOnWhatsApp(this, it)
                }
            }

            dialog.show()
        } catch (e: Exception) {
            UtilsMethods.AppLogger.logAndToast(
                this, "EC012", "MarkAttendanceActivity", "showBottomLogoutDialog", e
            )
        }
    }

    private fun showBottomLoginDialog() {
        try {
            val dialog = BottomSheetDialog(this)

            val binding = BottomLoginLayoutBinding.inflate(layoutInflater)
            dialog.setContentView(binding.root)
            dialog.setCanceledOnTouchOutside(false)

            binding.titleName.text = userFullName
            //binding.profileOutImg.setImageURI(imageUri)
            val bitmap = UtilsMethods.compressPhoto(imagePath1, 800, 800) // Target width & height
            binding.profileOutImg.setImageBitmap(bitmap)

            val currentTime = runCatching {
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMM-dd-yyyy | hh:mm a"))
            }.getOrElse { "Invalid Date" }
            binding.dataTimeTxt.text = currentTime

            binding.btnCancel.setOnClickListener {
                dialog.dismiss()
            }
            binding.btnConfirm.setOnClickListener {
                lifecycleScope.launch {
                    val isSuccess = uploadSwipeInData(imagePath1)
                    if (isSuccess) {
                        binding.ivshare.visibility = View.VISIBLE
                        binding.loginText.visibility = View.GONE
                        binding.loginSuccessfulText.visibility = View.VISIBLE
                        binding.btnCancel.visibility = View.GONE
                        binding.btnConfirm.visibility = View.GONE
                        binding.btnok.visibility = View.VISIBLE
                    }
                    hideLoading()
                }
            }
            binding.btnok.setOnClickListener {
                val bitmap = UtilsMethods.takeScreenshotOfView(binding.layLogin)
                val uri = UtilsMethods.saveBitmapToFile(bitmap, this)
                dialog.dismiss()

                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
            binding.ivshare.setOnClickListener {
                val bitmap = UtilsMethods.takeScreenshotOfView(binding.layLogin)
                val uri = UtilsMethods.saveBitmapToFile(bitmap, this)

                uri?.let {
                    UtilsMethods.shareImageOnWhatsApp(this, it)
                }
            }
            dialog.show()
        } catch (e: Exception) {
            UtilsMethods.AppLogger.logAndToast(
                this, "EC013", "MarkAttendanceActivity", "showBottomLoginDialog", e
            )
        }
    }

    private suspend fun uploadSwipeInData(imagePath: String): Boolean {
        return try {
            showLoading(this)
            val file = File(imagePath)

            val requestFile = file.asRequestBody("image/*".toMediaTypeOrNull())
            val filePart = MultipartBody.Part.createFormData("file", file.name, requestFile)

            val jsonString = """
            {
                "loginIpAddress": "${UtilsMethods.getActiveIpAddress(this@MarkAttendanceActivity)}",
                "workplace": "NA"
            }
        """.trimIndent()

            val jsonRequestBody = jsonString.toRequestBody("application/json".toMediaTypeOrNull())

            val response = if (binding.layBottom.isVisible) {
                ApiClient.apiService.uploadSwipeOutData(
                    "Bearer ${sharedPref.getString("auth_token", "")}", filePart, jsonRequestBody
                )
            } else {
                ApiClient.apiService.uploadSwipeInData(
                    "Bearer ${sharedPref.getString("auth_token", "")}", filePart, jsonRequestBody
                )
            }
            Log.d("uploadAttendanceSuccess", response.data)
            true
        } catch (e: Exception) {
            UtilsMethods.AppLogger.logAndToast(
                this@MarkAttendanceActivity,
                "EC014",
                "MarkAttendanceActivity",
                "uploadSwipeInData",
                e
            )
            false
        }
    }

    private fun checkCameraPermissionAndOpen() {
        try {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                openCamera()
            } else {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE
                )
            }
        } catch (e: Exception) {
            UtilsMethods.AppLogger.logAndToast(
                this, "EC015", "MarkAttendanceActivity", "checkCameraPermissionAndOpen", e
            )
        }
    }

    private fun openCamera() {
        try {
            val imagePath = File.createTempFile("IMG_", ".jpg", externalCacheDir)
            imagePath1 = imagePath.toString()

            imageUri = FileProvider.getUriForFile(
                this, "${applicationContext.packageName}.fileprovider", imagePath
            )
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
            if (intent.resolveActivity(packageManager) != null) {
                startActivityForResult(intent, CAMERA_REQUEST_CODE)
            }
        } catch (e: Exception) {
            UtilsMethods.AppLogger.logAndToast(
                this, "EC016", "MarkAttendanceActivity", "openCamera", e
            )
        }
    }


    // Handle camera permission result
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == CAMERA_PERMISSION_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                openCamera()
            } else {
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            // Load captured image into another ImageView
            when (binding.layBottom.visibility) {
                View.VISIBLE -> showBottomLogoutDialog()
                View.INVISIBLE -> Log.d("Visibility", "layBottom is invisible")
                View.GONE -> showBottomLoginDialog()
            }
        }
    }
}