package com.example.upsyneexpenses.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.upsyneexpenses.adapter.ApprovedAdapter
import com.harshal.upzyne.R
import com.harshal.upzyne.databinding.FragmentApprovedBinding
import com.harshal.upzyne.model.ExpensesModel

class ApprovedFragment : Fragment() {


    private var _binding: FragmentApprovedBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentApprovedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val Approvedexpenses = listOf(
            ExpensesModel.Expense(
                R.drawable.spoon,
                "team lunch",
                "₹1565",
                "travel",
                "approved",
                "Sept 15, 2024"
            ),
            ExpensesModel.Expense(
                R.drawable.pendingtravel,
                "office supplies",
                "₹565",
                "food",
                "approved",
                "Sept 15, 2024"
            )
        )

        binding.approvedexpensesRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.approvedexpensesRecyclerView.adapter = ApprovedAdapter(Approvedexpenses)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null

    }

}
