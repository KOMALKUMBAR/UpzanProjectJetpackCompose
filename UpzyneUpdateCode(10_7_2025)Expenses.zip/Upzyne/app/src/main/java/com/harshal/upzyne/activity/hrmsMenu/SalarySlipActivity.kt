package com.harshal.upzyne.activity.hrmsMenu

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast

import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ActivitySalaryslipBinding
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch

class SalarySlipActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySalaryslipBinding
    private lateinit var sharedPref: SharedPreferences
    lateinit var userFullName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySalaryslipBinding.inflate(layoutInflater)
        setContentView(binding.root)

        UtilsMethods.applyInsetPadding(this, binding.rootLayout)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fullname", "").toString()
        binding.swipinTxt.text = "${userFullName.trim().split(" ").firstOrNull() ?: ""} - Salary Slip "

        val getMonth = intent.getIntExtra("salaryMonth", 0)
        val getYear = intent.getIntExtra("salaryYear", 0)

        binding.imgArrow.setOnClickListener { finish() }
        setThemeBackground(this, binding.tvCounsNameCard)
        getSalarySlip(getMonth, getYear)
    }

    private fun getSalarySlip(month: Int, year: Int) {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getSalarySlip(
                    "Bearer ${sharedPref.getString("auth_token", "")}",
                    month, year)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@SalarySlipActivity,
                    apiCall = { call },
                    onSuccess = { response -> val data = response.data
                        if (data != null) {
                            updateUI(data)
                        } else {
                            Toast.makeText(
                                this@SalarySlipActivity,
                                "No data found",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@SalarySlipActivity,
                            "EC026",
                            "SalarySlipActivity",
                            "getSalarySlip",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@SalarySlipActivity,
                    "EC026",
                    "SalarySlipActivity",
                    "getSalarySlip",
                    e
                )
            }
        }
    }


    private fun updateUI(data: com.harshal.upzyne.model.SalarySlipData) {
        try {
            binding.apply {
                tvCounsName.text = data.employeename
               tvMonth.text =data.paidon
                tvEmplDept.text = "${data.departmentname}||${data.designation}"
                tvPAN.text = data.pancard
                tvPaidOn.text = data.paidon
                tvNetPay.text = "₹${data.netpay}"
                tvBasicPay.text = "₹${data.basicpay}"
                tvMedicalAllowance.text = "₹${data.medical_allowance}"
                tvTransportAllowance.text = "₹${data.transport_allowance}"
                tvPersonalAllowance.text = "₹${data.personal_allowance}"
                tvLeaveDeduction.text = "₹${data.leavededuction}"
                tvTotalDeduction.text = "₹${data.total_deductions}"
                tvAccountNo.text = data.bankaccountno
                tvISFC.text = data.ifsccode
                tvAttendance.text = "${data.attendancedays}/${data.totalworkdays}"
                tvLeaves.text = data.leavetaken.toString()
            }
        } catch (e: Exception) {
            AppLogger.logAndToast(this, "EC027", "SalarySlipActivity", "updateUI", e)
        }

    }
}

