package com.harshal.upzyne.activity.settingMenu

import android.app.DownloadManager
import android.content.*
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.harshal.upzyne.R
import com.harshal.upzyne.databinding.ActivityDocumentPreviewBinding
import java.net.URL

class DocumentPreviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDocumentPreviewBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var baseUrl: String
    private lateinit var userFullName: String

    private var downloadId: Long = -1L

    private val onDownloadComplete = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
            if (id == downloadId) {
                Toast.makeText(this@DocumentPreviewActivity, "Download complete", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDocumentPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        baseUrl = sharedPref.getString("base_url", "http://103.175.163.215:22888/") ?: ""
        userFullName = sharedPref.getString("user_full_name", "User") ?: "User"

        binding.swipinTxt.text = "${userFullName.trim().split(" ").firstOrNull() ?: ""} - preview"
        binding.imgArrow.setOnClickListener { finish() }

        val rawUrl = intent.getStringExtra("document_url") ?: return
        val documentUrl = if (rawUrl.startsWith("http")) rawUrl else baseUrl + rawUrl

        val extension = MimeTypeMap.getFileExtensionFromUrl(documentUrl)
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)

        if (mimeType != null && mimeType.startsWith("image")) {
            binding.documentImageView.visibility = View.VISIBLE
            binding.documentWebView.visibility = View.GONE

            Glide.with(this)
                .load(documentUrl)
                .placeholder(R.drawable.profile)
                .into(binding.documentImageView)
        } else {
            binding.documentImageView.visibility = View.GONE
            binding.documentWebView.visibility = View.VISIBLE
            binding.documentWebView.settings.javaScriptEnabled = true
            binding.documentWebView.loadUrl("https://docs.google.com/gview?embedded=true&url=$documentUrl")
        }

        binding.btnDownload.setOnClickListener {
            startDownload(documentUrl)
        }

        // Register broadcast receiver (for Android 12+)
        registerReceiver(
            onDownloadComplete,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            Context.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(onDownloadComplete)
    }

    private fun startDownload(url: String) {
        val fileName = Uri.parse(url).lastPathSegment ?: "downloaded_file"
        val extension = MimeTypeMap.getFileExtensionFromUrl(url)
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)

        if (mimeType != null && mimeType.startsWith("image")) {
            Thread {
                try {
                    val input = URL(url).openStream()
                    val bitmap = BitmapFactory.decodeStream(input)

                    val contentValues = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/UpzyneDocuments")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }

                    val resolver = contentResolver
                    val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

                    imageUri?.let {
                        resolver.openOutputStream(it)?.use { outputStream ->
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                        }

                        contentValues.clear()
                        contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                        resolver.update(it, contentValues, null, null)

                        runOnUiThread {
                            Toast.makeText(this, "Image saved to gallery", Toast.LENGTH_SHORT).show()
                        }
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                    runOnUiThread {
                        Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }.start()

        } else {
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(fileName)
                .setDescription("Downloading...")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)

            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            downloadId = dm.enqueue(request)

            Toast.makeText(this, "Download started...", Toast.LENGTH_SHORT).show()
        }
    }
}
