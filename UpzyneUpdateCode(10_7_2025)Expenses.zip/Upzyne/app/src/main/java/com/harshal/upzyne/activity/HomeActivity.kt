package com.harshal.upzyne.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.fragment.app.Fragment
import com.harshal.upzyne.R
import com.harshal.upzyne.databinding.ActivityHomeBinding
import com.harshal.upzyne.fragment.MoreFragment

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        loadFragment(MoreFragment())    //load default fragment

        binding.bottomNav.setOnItemSelectedListener {
            val fragment = when (it.itemId) {
                /*R.id.nav_dashboard -> DashboardFragment()
                R.id.nav_leads -> LeadsFragment()
                R.id.nav_chat -> ChatFragment()*/
                R.id.nav_more -> MoreFragment()
                else -> null
            }
            fragment?.let { loadFragment(it) }
            true
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, fragment)
            .commit()
    }
}
