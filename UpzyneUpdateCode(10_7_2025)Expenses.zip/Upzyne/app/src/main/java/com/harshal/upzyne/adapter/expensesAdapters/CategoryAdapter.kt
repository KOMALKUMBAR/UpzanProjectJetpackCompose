package com.harshal.upzyne.adapter.expensesAdapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.model.ExpensesModel

class CategoryAdapter(
    private val categoryList: List<ExpensesModel.Category>,
    private val onCategorySelected: (Int) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    private var selectedPosition = RecyclerView.NO_POSITION

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.category_item_xml, parent, false)
        return CategoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val category = categoryList[position]
        holder.nameTextView.text = category.name

        // Highlight selected
        val isSelected = position == selectedPosition
        holder.llCard.setBackgroundResource(
            if (isSelected) R.drawable.select_status_bg
            else R.drawable.default_category_background
        )
        holder.nameTextView.setTextColor(if (isSelected) Color.WHITE else Color.BLACK)

        holder.itemView.setOnClickListener {
            val actualPosition = holder.adapterPosition
            if (actualPosition != RecyclerView.NO_POSITION) {
                val previousPosition = selectedPosition
                selectedPosition = actualPosition
                notifyItemChanged(previousPosition)
                notifyItemChanged(selectedPosition)
                onCategorySelected(categoryList[actualPosition].categoryid)
            }
        }
    }

    override fun getItemCount() = categoryList.size

    class CategoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.travel)
        val llCard:LinearLayout=itemView.findViewById(R.id.llCard)
    }
}

