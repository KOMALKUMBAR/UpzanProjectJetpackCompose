package com.harshal.upzyne.activity.settingMenu

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.activity.hrmsMenu.FaqHelpActivity
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivitySettingPageBinding
import kotlinx.coroutines.launch

class SettingPageActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingPageBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var baseUrl: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySettingPageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        baseUrl = sharedPref.getString("base_url", "").toString()
        binding.email.text = sharedPref.getString("user_email", "")
        binding.mobile.text = sharedPref.getString("user_contact", "")
        setThemeBackground(this, binding.llFirst)
        setThemeBackground(this, binding.llSecond)
        setThemeBackground(this, binding.llSetting)

        getBasicProfile()
        binding.llPersonalInfoAccount.setOnClickListener {
            val intent = Intent(this, PersonInfoPageActivity::class.java)
            startActivity(intent)
        }
        binding.officeAccount.setOnClickListener {
            val intent = Intent(this, OfficeAssetsActivity::class.java)
            startActivity(intent)
        }
        binding.llBankDetails.setOnClickListener {
            val intent = Intent(this, BankDetailsActivity::class.java)
            startActivity(intent)
        }
        binding.documentVault.setOnClickListener {
            val intent = Intent(this, DocumentActivity::class.java)
            startActivity(intent)
        }
        binding.changePassword.setOnClickListener {
            val intent = Intent(this, ChangePasswordActivity::class.java)
            startActivity(intent)
        }
        binding.themes.setOnClickListener {
            val intent = Intent(this, ThemeActivity::class.java)
            startActivity(intent)
        }
        binding.versionAndUpdate.setOnClickListener {
            val intent = Intent(this, FaqHelpActivity::class.java)
            startActivity(intent)
        }
        binding.faqAndHelp.setOnClickListener {
            val intent = Intent(this, FaqHelpActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        setThemeBackground(this, binding.llFirst)
        setThemeBackground(this, binding.llSecond)
        setThemeBackground(this, binding.llSetting)
    }

    private fun getBasicProfile() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@SettingPageActivity,
                    apiCall = {
                        ApiClient.apiService.basicInfo("Bearer ${sharedPref.getString("auth_token", "")}")
                    },
                    onSuccess = { response ->
                        Log.d("ProfileSuccess", response.data.toString())
                        val profile = response.data

                        binding.profileName.text = profile.fullName
                        binding.profileDesc.text = profile.designation
                        binding.profileDepartment.text = profile.departmentName
                        binding.profileCode.text = profile.employeeId

                        val imageUrl = "${baseUrl + profile.profileUrl}?t=${System.currentTimeMillis()}"
                        Glide.with(this@SettingPageActivity)
                            .load(imageUrl)
                            .placeholder(R.drawable.profile)
                            .error(R.drawable.noimage)
                            .into(binding.profileImg)

                        with(sharedPref.edit()) {
                            putString("user_fullname", profile.fullName)
                            putString("user_email", profile.email)
                            putString("user_contact", profile.contactNumber)
                            apply()
                        }
                    },
                    onError = { error ->
                        Log.e("ProfileError", error)
                        Toast.makeText(
                            this@SettingPageActivity,
                            "Failed to fetch profile: $error",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                )
            } catch (e: Exception) {
                Log.e("ProfileException", e.toString())
                Toast.makeText(this@SettingPageActivity, "Exception: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }


}
