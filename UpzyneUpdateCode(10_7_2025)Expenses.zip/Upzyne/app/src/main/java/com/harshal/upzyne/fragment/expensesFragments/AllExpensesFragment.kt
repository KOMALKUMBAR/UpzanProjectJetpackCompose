package com.example.upsyneexpenses.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.upsyneexpenses.adapter.AllExpensesAdapter
import com.harshal.upzyne.databinding.FragmentAllExpensesBinding
import com.harshal.upzyne.model.ExpensesModel

class AllExpensesFragment : Fragment() {

    private lateinit var binding: FragmentAllExpensesBinding
    private lateinit var adapter: AllExpensesAdapter
    private val expenseList = mutableListOf<ExpensesModel.ExpenseData>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View { binding = FragmentAllExpensesBinding.inflate(inflater, container, false)

        //  Add LayoutManager to avoid blank RecyclerView
        binding.expensesRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = AllExpensesAdapter(requireContext(), expenseList)
        binding.expensesRecyclerView.adapter = adapter

        return binding.root
    }

    fun updateExpensesList(newList: List<ExpensesModel.ExpenseData>) {
        Log.d("AllExpensesFragment", "Updating list with ${newList.size} items")
        expenseList.clear()
        expenseList.addAll(newList)
        adapter.notifyDataSetChanged()
    }
}
