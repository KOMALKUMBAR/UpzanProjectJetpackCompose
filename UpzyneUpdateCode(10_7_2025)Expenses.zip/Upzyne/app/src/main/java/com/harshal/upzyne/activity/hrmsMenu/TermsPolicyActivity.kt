package com.harshal.upzyne.activity.hrmsMenu

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.databinding.ActivityTermspolicyBinding
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch

class TermsPolicyActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTermspolicyBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var activityName: String
    lateinit var userFullName: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTermspolicyBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        activityName = intent.getStringExtra("activityName").toString()
        binding.swipinTxt.text = activityName

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fullname", "").toString()
        binding.swipinTxt.text =
            "${userFullName.trim().split(" ").firstOrNull() ?: ""} - Term Policy "

        binding.imgArrow.setOnClickListener {
            finish()
        }

        fetchTermsPolicy()
    }

    private fun fetchTermsPolicy() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = if (activityName == "terms & condition") {
                    ApiClient.apiService.getTerms("Bearer ${sharedPref.getString("auth_token", "")}")
                } else {
                    ApiClient.apiService.getPolicy("Bearer ${sharedPref.getString("auth_token", "")}")
                }

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@TermsPolicyActivity,
                    apiCall = { call },
                    onSuccess = { response ->
                        Log.d("TermsPolicySuccess", response.data.toString())

                        binding.tvLastUpdate.text = "last update: ${response.data.lastupdated}"
                        binding.tvTitle.text = response.data.title
                        binding.tvDescription.text = response.data.description
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@TermsPolicyActivity,
                            "EC039",
                            "TermsPolicyActivity",
                            "fetchTermsPolicy",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@TermsPolicyActivity,
                    "EC039",
                    "TermsPolicyActivity",
                    "fetchTermsPolicy",
                    e
                )
            }
        }
    }

}
