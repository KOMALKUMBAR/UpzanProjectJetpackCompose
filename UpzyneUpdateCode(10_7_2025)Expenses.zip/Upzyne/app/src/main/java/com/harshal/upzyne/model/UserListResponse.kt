package com.harshal.upzyne.model

data class UserListResponse(
    val data: List<UserData>
)

data class UserData(
    val userid: Int,
    val fullname: String
)
