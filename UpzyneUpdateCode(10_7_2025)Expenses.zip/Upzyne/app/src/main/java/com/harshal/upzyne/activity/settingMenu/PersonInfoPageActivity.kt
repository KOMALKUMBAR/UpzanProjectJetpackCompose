package com.harshal.upzyne.activity.settingMenu

import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityPersonInfoPageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PersonInfoPageActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPersonInfoPageBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var userFullName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPersonInfoPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setThemeBackground(this, binding.llBasicInformation)
        setThemeBackground(this, binding.llContact)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fullname", "").toString()

        binding.titleBar.text = "${userFullName.trim().split(" ").firstOrNull() ?: ""} - personal information"
        val userEmail = sharedPref.getString("user_email", "NA")
        val userPhone = sharedPref.getString("user_contact", "NA")
        binding.textemail.text = userEmail
        binding.textMobileNumbar.text = userPhone
        binding.imgArrow.setOnClickListener { finish() }

        disableEditTexts()
        binding.btnSubmit.visibility = View.GONE

        binding.imageViewEdit.setOnClickListener {
            enableEditTexts()
            binding.btnSubmit.visibility = View.VISIBLE
        }

        binding.btnSubmit.setOnClickListener {
            val address = binding.textAddress.text.toString().trim()
            val city = binding.textCity.text.toString().trim()
            val state = binding.textState.text.toString().trim()
            val pincode = binding.textPinCode.text.toString().trim()

            if (address.isEmpty() || city.isEmpty() || state.isEmpty() || pincode.isEmpty()) {
                Toast.makeText(this, "Please fill all address fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val addressMap = mapOf(
                "address" to address,
                "city" to city,
                "state" to state,
                "pincode" to pincode
            )

            val token = sharedPref.getString("auth_token", "") ?: ""
            val bearerToken = "Bearer $token"

            lifecycleScope.launch {
                try {
                    ApiRequestHandler.makeSuspendApiCall(
                        context = this@PersonInfoPageActivity,
                        apiCall = {
                            ApiClient.apiService.updateAddress(bearerToken, addressMap)
                        },
                        onSuccess = { response ->
                            Toast.makeText(this@PersonInfoPageActivity, response.message ?: "Address updated successfully", Toast.LENGTH_SHORT).show()
                            disableEditTexts()
                            binding.btnSubmit.visibility = View.GONE
                        },
                        onError = { error ->
                            UtilsMethods.AppLogger.logAndToast(
                                this@PersonInfoPageActivity,
                                "EC025",
                                "PersonInfoPageActivity",
                                "updateAddress",
                                Exception(error)
                            )
                        }
                    )
                } catch (e: Exception) {
                    UtilsMethods.AppLogger.logAndToast(
                        this@PersonInfoPageActivity,
                        "EC025",
                        "PersonInfoPageActivity",
                        "updateAddress",
                        e
                    )
                }
            }

        }

        fetchProfileDetails()
    }

    private fun fetchProfileDetails() {
        if (!checkNetworkAndShowMessage(this)) return

        val token = sharedPref.getString("auth_token", "") ?: ""
        val bearerToken = "Bearer $token"

        lifecycleScope.launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    ApiClient.apiService.getProfileDetails(bearerToken)
                }

                val data = response.data

                binding.textJoiningDate.setText(data.joiningDate.takeIf { it.isNotBlank() } ?: "NA")
                binding.textDob.setText(data.dateOfBirth.takeIf { it.isNotEmpty() } ?: "NA")
                binding.textAddress.setText(data.address.takeIf { it.isNotEmpty() } ?: "NA")
                binding.textCity.setText(data.city.takeIf { it.isNotBlank() } ?: "NA")
                binding.textState.setText(data.state.takeIf { it.isNotBlank() } ?: "NA")
                binding.textPinCode.setText(data.pincode.takeIf { it.isNotBlank() } ?: "NA")
                binding.textGender.setText(data.gender.takeIf { it.isNotBlank() } ?: "NA")
                binding.textLeaveBalance.setText(data.leaveBalance.toString())

            } catch (e: Exception) {
                Toast.makeText(this@PersonInfoPageActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun disableEditTexts() {
        binding.textJoiningDate.isEnabled = false
        binding.textDob.isEnabled = false
        binding.textAddress.isEnabled = false
        binding.textCity.isEnabled = false
        binding.textState.isEnabled = false
        binding.textPinCode.isEnabled = false
        binding.textGender.isEnabled = false
        binding.textLeaveBalance.isEnabled = false
    }

    private fun enableEditTexts() {
        binding.textJoiningDate.isEnabled = true
        binding.textDob.isEnabled = true
        binding.textAddress.isEnabled = true
        binding.textCity.isEnabled = true
        binding.textState.isEnabled = true
        binding.textPinCode.isEnabled = true
        binding.textGender.isEnabled = true
        binding.textLeaveBalance.isEnabled = true
    }
}
