package com.harshal.upzyne.model

data class ProfileInfoResponce(val data: ProfileInfo)

data class ProfileInfo(
    val fullName: String,
    val email: String,
    val userName: String,
    val profileUrl: String?,  // Nullable as per JSON
    val designation: String,
    val departmentName: String,
    val employeeId: String,
    val contactNumber: String
)

