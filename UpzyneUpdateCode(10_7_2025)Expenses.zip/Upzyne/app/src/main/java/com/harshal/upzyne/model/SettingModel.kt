package com.harshal.upzyne.model

class SettingModel {

    data class PersonalInfoResponse(
        val data: ProfileData
    )

    data class ProfileData(
        val state: String,
        val address: String,
        val country: String,
        val pincode: String,
        val city: String,
        val leaveBalance: Int,
        val joiningDate: String,
        val dateOfBirth: String,
        val gender: String
    )
    data class UpdatePersonalAddressResponse(
        val status: Boolean,
        val message: String
    )

    // BankDetailsResponse.kt
    data class BankDetailsResponse(
        val data: BankDetails
    )

    data class BankDetails(
        val pancard: String,
        val accountholdername: String,
        val ifsccode: String,
        val branchname: String,
        val bankname: String,
        val aadharcard: String,
        val accounttype: String,
        val accountnumber: String
    )

    // ChangePasswordRequest.kt
    data class ChangePasswordRequest(
        val oldPasswordHash: String,
        val newPasswordHash: String
    )

    data class ChangePasswordResponse(
        val error: String?
    )

    data class UploadDocumentRequestBody(
        val file: String, val documentTypeId: Int, val remarks: String
    )

    data class UploadDocumentResponseBody(
        val data: String
    )

    data class UploadedDocument(
        val employeedocumentid: Int,
        val documenttypename: String,
        val documenturl: String,
        val isverified: Boolean,
        val uploaddate: String
    )

    //TeamAsset Acctivity
    data class TeamAssetResponse(
        val data: List<AssetItem>
    )

    data class AssetItem(
        val assetid: Int,
        val brandname: String,
        val assetname: String,
        val buyingdate: String,
        val receivedon: String,
        val imageurl: String
    )

    data class UserIdRequest(
        val userId: Int
    )

    data class DocumentHrTypesResponse(
        val data: List<DocumentType>) {
        data class DocumentType(
            val documenttypename: String, val isactive: Boolean, val documenttypeid: Int
        )
    }

    data class DocumentListResponse(val data: List<DocumentData>)
    data class DocumentData(
        val userid: Int,
        val employeedocumentid: Int,
        val documenttypename: String,
        val isverified: Boolean,
        val documenturl: String,
        val uploaddate: String
    )
}