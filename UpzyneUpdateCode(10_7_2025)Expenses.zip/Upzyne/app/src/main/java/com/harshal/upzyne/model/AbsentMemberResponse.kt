package com.harshal.upzyne.model

data class AbsentMemberResponse(
    val data: List<AbsentMember>
)

data class AbsentMember(
    val leavedate: String,
    val name: String,
    val profileurl: String,
    val userid: Int
)