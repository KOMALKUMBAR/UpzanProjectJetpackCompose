package com.harshal.upzyne.model

data class SwipeInData(val userId: Int,
                       val loginIpAddress: String,
                       val wifiName: String)
