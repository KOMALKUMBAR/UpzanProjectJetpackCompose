package com.example.upsyneexpenses.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.databinding.ItemViewExpenseCardBinding
import com.harshal.upzyne.model.ExpensesModel


class ApprovedAdapter(private val list: List<ExpensesModel.Expense>): RecyclerView.Adapter<ApprovedAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemViewExpenseCardBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemViewExpenseCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = list[position]
        with(holder.binding) {

            aroplaneIcon.setImageResource(item.iconResId)
            expenseTitle.text = item.title
            expenseAmount.text = item.amount
            expenseCategory.text = item.category
            expenseStatus.text = item.status
            expenseDate.text = item.date

            when(item.status.lowercase()) {
                "approved" -> {
                    expenseStatus.setBackgroundResource(R.drawable.status_approved_bg)
                    expenseStatus.setTextColor(Color.parseColor("#4CAF50"))
                }

                "pending" -> {
                    expenseStatus.setBackgroundResource(R.drawable.status_pending_bg)
                    expenseStatus.setTextColor(Color.parseColor("#FF9800"))
                }

                "rejected" -> {
                    expenseStatus.setBackgroundResource(R.drawable.status_rejected_bg)
                    expenseStatus.setTextColor(Color.parseColor("#F44336"))
                }
            }

        }
    }

        override fun getItemCount(): Int = list.size

    }
