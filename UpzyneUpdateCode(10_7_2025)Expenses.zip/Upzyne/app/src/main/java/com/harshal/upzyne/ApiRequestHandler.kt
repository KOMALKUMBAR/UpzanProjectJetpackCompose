package com.harshal.upzyne

import android.content.Context
import android.util.Log
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object ApiRequestHandler {
    suspend fun <Res> makeSuspendApiCall(
        context: Context,
        apiCall: suspend () -> Res,
        onSuccess: (Res) -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            val response = apiCall()
            onSuccess(response)
        } catch (e: Exception) {
            val errorMessage = if (e is retrofit2.HttpException) {
                try {
                    val errorJson = e.response()?.errorBody()?.string()
                    JSONObject(errorJson ?: "").optString("error", "Unknown error")
                } catch (ex: Exception) {
                    "Unknown error"
                }
            } else {
                e.localizedMessage ?: "Unknown error occurred"
            }

            Log.e("ApiRequestHandler", "API call failed: $errorMessage", e)
            onError(errorMessage)
        }
    }
}