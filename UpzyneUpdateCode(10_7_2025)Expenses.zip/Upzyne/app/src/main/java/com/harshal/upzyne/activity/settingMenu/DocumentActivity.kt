// DocumentActivity.kt
package com.harshal.upzyne.activity.settingMenu

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.adapter.UploadedDocumentAdapter
import com.harshal.upzyne.databinding.ActivityDocumentBinding
import com.harshal.upzyne.model.ProgressRequestBody
import com.harshal.upzyne.model.SettingModel.DocumentData
import com.harshal.upzyne.model.SettingModel.DocumentHrTypesResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody

class DocumentActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDocumentBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private var selectedFileUri: Uri? = null
    private var selectedDocumentTypeName: String = ""
    private var documentList: List<DocumentHrTypesResponse.DocumentType> = listOf()
    private val uploadedDocumentList = mutableListOf<DocumentData>()
    private lateinit var adapter: UploadedDocumentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDocumentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        bearerToken = "Bearer " + (sharedPref.getString("auth_token", "") ?: "")
        val userFullName = sharedPref.getString("user_fullname", "") ?: ""
        binding.swipinTxt.text = "${userFullName.trim().split(" ").firstOrNull() ?: ""} - document"

        adapter = UploadedDocumentAdapter(uploadedDocumentList) { document ->
            val intent = Intent(this, DocumentPreviewActivity::class.java)
            intent.putExtra("document_url", document.documenturl)
            intent.putExtra("document_type", document.documenttypename)
            startActivity(intent)
        }

        binding.recyclerUploadedDocs.adapter = adapter
        binding.recyclerUploadedDocs.layoutManager = LinearLayoutManager(this)
        binding.recyclerUploadedDocs.adapter = adapter
        binding.imgArrowBack.setOnClickListener { finish() }

        fetchDocumentTypes()
        fetchUploadedDocuments()
        setupSpinnerListener()

        binding.btnBrowseFile.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_GET_CONTENT)
                intent.type = "*/*"
                startActivityForResult(intent, 1001)
            } catch (e: Exception) {
                Log.e("openstorage", "Exception: " + e.message)
                AppLogger.logAndToast(this, "EC046", "DocumentActivity", "btnBrowseFile", Exception())
            }
        }

        binding.btnSave.setOnClickListener {
            val position = binding.selectDocumentListview.selectedItemPosition
            if (position <= 0) {
                Toast.makeText(this, "Please select a document type", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (selectedFileUri == null) {
                Toast.makeText(this, "Please select a file to upload", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val documentTypeId = documentList[position - 1].documenttypeid
            uploadDocument(documentTypeId)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                selectedFileUri = uri
                val fileName = getFileName(uri)
                binding.tvSelectedFileName.text = "Selected: $fileName"
            }
        }
    }

    private fun fetchDocumentTypes() {
        lifecycleScope.launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    ApiClient.apiService.getDocumentHrTypes(bearerToken).execute()
                }
                if (response.isSuccessful && response.body() != null) {
                    documentList = response.body()!!.data.filter { it.isactive }
                    val names = listOf("Select Document") + documentList.map { it.documenttypename }
                    val spinnerAdapter = ArrayAdapter(this@DocumentActivity, android.R.layout.simple_spinner_item, names)
                    spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    binding.selectDocumentListview.adapter = spinnerAdapter
                } else {
                    Toast.makeText(this@DocumentActivity, "Failed to load document types: ${response.code()}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                AppLogger.logAndToast(this@DocumentActivity, "EC047", "DocumentActivity", "fetchDocumentTypes", Exception())
            }
        }
    }

    private fun setupSpinnerListener() {
        binding.selectDocumentListview.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedDocumentTypeName = if (position > 0) documentList[position - 1].documenttypename else ""
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedDocumentTypeName = ""
            }
        }
    }

    private fun uploadDocument(documentTypeId: Int) {
        binding.progressCardView.visibility = View.VISIBLE
        binding.layoutUploading.visibility = View.VISIBLE
        binding.progressUpload.progress = 0
        binding.txtUploadStatus.text = "Uploading... 0%"

        lifecycleScope.launch {
            try {
                val inputStream = contentResolver.openInputStream(selectedFileUri!!)
                val fileBytes = inputStream?.readBytes() ?: throw Exception("File read error")
                val fileName = getFileName(selectedFileUri!!)
                val fileBody = ProgressRequestBody(fileBytes, "application/octet-stream") { progress ->
                    runOnUiThread {
                        binding.progressUpload.progress = progress
                        val displayName = if (selectedDocumentTypeName.isNotEmpty()) selectedDocumentTypeName else "Document"
                        binding.txtUploadStatus.text = "$displayName Uploading... $progress%"
                    }
                }

                val multipartFile = MultipartBody.Part.createFormData("file", fileName, fileBody)
                val typeBody = documentTypeId.toString().toRequestBody("text/plain".toMediaTypeOrNull())
                val remarksBody = "Uploaded via app".toRequestBody("text/plain".toMediaTypeOrNull())

                val response = withContext(Dispatchers.IO) {
                    ApiClient.apiService.uploadDocument(bearerToken, multipartFile, typeBody, remarksBody).execute()
                }

                binding.progressCardView.visibility = View.GONE
                binding.layoutUploading.visibility = View.GONE

                if (response.isSuccessful && response.body() != null) {
                    selectedFileUri = null
                    binding.tvSelectedFileName.text = ""
                    showDialogAfterUpload()
                } else {
                    showDialog("Upload Failed", "Server error: ${response.code()}")
                }

            } catch (e: Exception) {
                binding.progressCardView.visibility = View.GONE
                binding.layoutUploading.visibility = View.GONE
                AppLogger.logAndToast(this@DocumentActivity, "EC048", "DocumentActivity", "uploadDocument", Exception())
                showDialog("Exception", e.message ?: "Unexpected error")
            }
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = "file"
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst()) {
                name = it.getString(index)
            }
        }
        return name
    }

    private fun showDialog(title: String, message: String) {
        runOnUiThread {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun showDialogAfterUpload() {
        runOnUiThread {
            val dialog = AlertDialog.Builder(this)
                .setTitle("Success")
                .setMessage("Document uploaded successfully.")
                .setCancelable(false)
                .setPositiveButton("OK") { _, _ -> fetchUploadedDocuments() }
                .setNegativeButton("Cancel", null)
                .create()

            dialog.show()
        }
    }

    private fun fetchUploadedDocuments() {
        lifecycleScope.launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    ApiClient.apiService.getUploadedDocuments(bearerToken).execute()
                }
                if (response.isSuccessful && response.body() != null) {
                    val list = response.body()!!.data
                    uploadedDocumentList.clear()
                    uploadedDocumentList.addAll(list.reversed())
                    adapter.notifyDataSetChanged()
                    binding.recyclerUploadedDocs.visibility = if (list.isNotEmpty()) View.VISIBLE else View.GONE
                    binding.recyclerUploadedDocs.scrollToPosition(0)
                } else {
                    Toast.makeText(this@DocumentActivity, "Failed to load uploaded documents: ${response.code()}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                AppLogger.logAndToast(this@DocumentActivity, "EC049", "DocumentActivity", "fetchUploadedDocuments", Exception())
            }
        }
    }
}
