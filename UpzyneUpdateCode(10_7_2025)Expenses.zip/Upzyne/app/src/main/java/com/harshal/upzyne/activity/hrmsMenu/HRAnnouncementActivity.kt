package com.harshal.upzyne.activity.hrmsMenu

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.adapter.AbsentColleagueAdapter
import com.harshal.upzyne.databinding.ActivityHrannouncementsBinding
import kotlinx.coroutines.launch

class HRAnnouncementActivity: AppCompatActivity() {
    private lateinit var binding: ActivityHrannouncementsBinding
    private lateinit var sharedPref: SharedPreferences
    lateinit var userFullName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHrannouncementsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fullname","").toString()
        binding.swipinTxt.text = "${userFullName.trim().split(" ").firstOrNull() ?: ""} - hr announcement & news"

        setThemeBackground(this, binding.LeaveCardview)
        binding.recyclerAbsentColleague.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        fetchAbsentMembers()

        binding.tvTraining.setOnClickListener {  }

        binding.tvTerms.setOnClickListener {
            val intent = Intent(this, TermsPolicyActivity::class.java)
            intent.putExtra("activityName", "terms & condition")
            startActivity(intent)
        }

        binding.tvPolicies.setOnClickListener {
            val intent = Intent(this, TermsPolicyActivity::class.java)
            intent.putExtra("activityName", "privacy policy")
            startActivity(intent)  }

        binding.tvHolidays.setOnClickListener { startActivity(Intent(this, HolidayActivity::class.java)) }

        binding.imgArrow.setOnClickListener {
            finish()
        }
    }

    private fun fetchAbsentMembers() {
        lifecycleScope.launch {
            try {
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@HRAnnouncementActivity,
                    apiCall = { ApiClient.apiService.getAbsentMember("Bearer ${sharedPref.getString("auth_token", "")}") },
                    onSuccess = { response ->
                        val absentMembersList = response.data
                        Log.d("AbsentMemberSuccess", absentMembersList.toString())

                        // Initialize adapter and set to RecyclerView
                        binding.recyclerAbsentColleague.adapter = sharedPref.getString("base_url", "")
                            ?.let { AbsentColleagueAdapter(it, absentMembersList) }
                    },
                    onError = { error ->
                        UtilsMethods.AppLogger.logAndToast(
                            this@HRAnnouncementActivity,
                            "EC042",
                            "HRAnnouncementActivity",
                            "fetchAbsentMembers",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                UtilsMethods.AppLogger.logAndToast(
                    this@HRAnnouncementActivity,
                    "EC042",
                    "HRAnnouncementActivity",
                    "fetchAbsentMembers",
                    e
                )
            }
        }
    }

}