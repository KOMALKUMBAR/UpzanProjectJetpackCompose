package com.harshal.upzyne.activity.expensesMenu

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.example.upsyneexpenses.fragment.AllExpensesFragment
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.formatAmount
import com.harshal.upzyne.adapter.expensesAdapters.ViewPagerAdapter
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityViewExpenseBinding
import com.harshal.upzyne.model.ExpensesModel
import kotlinx.coroutines.launch

class ViewExpenseActivity : AppCompatActivity() {

    private lateinit var binding: ActivityViewExpenseBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var viewPagerAdapter: ViewPagerAdapter
    private lateinit var userFullName: String
    private var fullExpenseList: List<ExpensesModel.ExpenseData> = listOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        binding = ActivityViewExpenseBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        viewPagerAdapter = ViewPagerAdapter(this)
        binding.viewPager.adapter = viewPagerAdapter
        val token = "Bearer ${sharedPref.getString("auth_token", "")}"
        userFullName = sharedPref.getString("user_fname", "").toString()
        val activityName = getString(R.string.total_expenses_label)
        binding.swipinTxt.text = "$userFullName - $activityName"
        //back button
        binding.imgArrowBack.setOnClickListener(){finish()}
        //floatingactionbutton
        binding.floatingactionbutton.setOnClickListener {
            val intent = Intent(this, SubmitexpenseActivity::class.java)
            startActivity(intent)
        }

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> getString(R.string.tab_all_expenses)
                1 -> getString(R.string.approved)
                2 -> getString(R.string.pending)
                else -> " "
            }
        }.attach()

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                when (tab.position) {
                    0 -> {
                        binding.totalExpenseCard.visibility = View.VISIBLE
                        binding.reviewText.visibility = View.GONE
                        binding.serchbar.visibility = View.VISIBLE
                    }
                    1, 2 -> {
                        binding.totalExpenseCard.visibility = View.GONE
                        binding.serchbar.visibility = View.GONE
                        binding.reviewText.visibility = View.VISIBLE
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        getTotalExpenses()

        lifecycleScope.launch {
            fetchAndStoreAllExpenses(token)
        }

        binding.serchbar.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val query = s.toString()
                if (query.length >= 2) {
                    performSearch(query)
                } else {
                    updateCurrentFragmentWithExpenses(fullExpenseList)
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun getTotalExpenses() {
        if (!checkNetworkAndShowMessage(this)) return
        lifecycleScope.launch {
            try {
                val token = "Bearer ${sharedPref.getString("auth_token", "")}"
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ViewExpenseActivity,
                    apiCall = { ApiClient.apiService.getToatalExpenses(token) },
                    onSuccess = { respons ->
                        val amount = respons.totalExpenses
                        binding.totalAmount.text = formatAmount(amount)
                    },
                    onError = {
                        UtilsMethods.toast(this@ViewExpenseActivity, getString(R.string.failed_to_load_data))
                    }
                )
            } catch (e: Exception) {
                UtilsMethods.AppLogger.logAndToast(
                    this@ViewExpenseActivity, "EC107", "ViewExpenseActivity", "getTotalExpenses", e
                )
            }
        }
    }

    private fun performSearch(query: String) {
        if (!checkNetworkAndShowMessage(this)) return
        val token = "Bearer ${sharedPref.getString("auth_token", "")}"
        lifecycleScope.launch {
            try {
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ViewExpenseActivity,
                    apiCall = {
                        ApiClient.apiService.searchExpenses(
                            token = token,
                            keys = getString(R.string.search_keys),
                            q = query
                        )
                    },
                    onSuccess = { response ->
                        val expenses = response.data
                        if (expenses.isNotEmpty()) {
                            updateCurrentFragmentWithExpenses(expenses)
                        } else {
                            filterFromLocal(query)
                        }
                    },
                    onError = {
                        filterFromLocal(query)
                    }
                )
            } catch (e: Exception) {
                UtilsMethods.AppLogger.logAndToast(
                    this@ViewExpenseActivity,
                    "EC104",
                    "ViewExpenseActivity",
                    "performSearch",
                    e
                )
            }
        }
    }

    private suspend fun fetchAndStoreAllExpenses(token: String) {
        try {
            ApiRequestHandler.makeSuspendApiCall(
                context = this@ViewExpenseActivity,
                apiCall = {
                    ApiClient.apiService.getAllIndividualExpenses(token)
                },
                onSuccess = { response ->
                    fullExpenseList = response.data
                    updateCurrentFragmentWithExpenses(fullExpenseList)
                },
                onError = {
                    UtilsMethods.toast(this@ViewExpenseActivity, getString(R.string.failed_to_load_expenses))
                }
            )
        } catch (e: Exception) {
            UtilsMethods.AppLogger.logAndToast(
                this@ViewExpenseActivity,
                "EC108",
                "ViewExpenseActivity",
                "fetchAndStoreAllExpenses",
                Exception()
            )
        }
    }

    private fun filterFromLocal(query: String) {
        val filtered = fullExpenseList.filter {
            it.memo.contains(query, ignoreCase = true) ||
                    it.categoryname.contains(query, ignoreCase = true) ||
                    it.amount.toString().contains(query, ignoreCase = true)
        }

        updateCurrentFragmentWithExpenses(filtered)

        if (filtered.isEmpty()) {
            UtilsMethods.toast(this, getString(R.string.no_matching_results))
        }
    }

    private fun updateCurrentFragmentWithExpenses(expenses: List<ExpensesModel.ExpenseData>) {
        val currentFragment = supportFragmentManager.findFragmentByTag("f${binding.viewPager.currentItem}")
        if (currentFragment is AllExpensesFragment) {
            currentFragment.updateExpensesList(expenses)
        }
    }
}
