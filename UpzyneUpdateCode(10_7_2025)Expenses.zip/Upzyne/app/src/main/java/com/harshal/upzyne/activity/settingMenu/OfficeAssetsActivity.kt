package com.harshal.upzyne.activity.settingMenu

import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivityOfficeAssetsBinding
import com.harshal.upzyne.model.SettingModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class OfficeAssetsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOfficeAssetsBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    private lateinit var userFullName: String

    private var assetList: List<SettingModel.AssetItem> = emptyList()
    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOfficeAssetsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        userFullName = sharedPref.getString("user_fullname", "").toString()
        bearerToken = "Bearer ${sharedPref.getString("auth_token", "")}"
        setThemeBackground(this, binding.llCard)

        binding.swipinTxt.text = "${userFullName.trim().split(" ").firstOrNull() ?: ""} - office assets"

        binding.imgArrow.setOnClickListener { finish() }

        fetchAllAssets()

        binding.btnNext.setOnClickListener {
            if (currentIndex < assetList.size - 1) {
                currentIndex++
                showAssetInfo(currentIndex)
                highlightButton(binding.btnNext)
            }
        }

        binding.btndone.setOnClickListener {
            if (currentIndex > 0) {
                currentIndex--
                showAssetInfo(currentIndex)
                highlightButton(binding.btndone)
            }
        }
    }

    private fun fetchAllAssets() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    ApiClient.apiService.getTeamAssets(bearerToken).execute()
                }

                if (response.isSuccessful && !response.body()?.data.isNullOrEmpty()) {
                    assetList = response.body()?.data ?: emptyList()
                    currentIndex = 0
                    showAssetInfo(currentIndex)
                } else {
                    Toast.makeText(this@OfficeAssetsActivity, "No assets found", Toast.LENGTH_SHORT)
                        .show()
                }
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@OfficeAssetsActivity,
                    "EC045",
                    "OfficeAssetsActivity",
                    "fetchAllAssets",
                    e
                )
            }
        }
    }

    private fun showAssetInfo(index: Int) {
        val asset = assetList.getOrNull(index)
        if (asset != null) {
            binding.etBrand.setText(asset.brandname)
            binding.etAssetName.setText(asset.assetname)
            binding.etBuyingDate.setText(asset.buyingdate)
            binding.etReceivedOn.setText(asset.receivedon)

            val imageUrl = "${sharedPref.getString("base_url", "")}${asset.imageurl.trimStart('/')}"
            Glide.with(this)
                .load(imageUrl)
                .error(R.drawable.noimage)
                .into(binding.imgAssetPreview)

            // Button visibility logic
            when (index) {
                0 -> {
                    binding.btndone.visibility = View.GONE
                    binding.btnNext.visibility = View.VISIBLE
                }

                assetList.size - 1 -> {
                    binding.btndone.visibility = View.VISIBLE
                    binding.btnNext.visibility = View.GONE
                }

                else -> {
                    binding.btndone.visibility = View.VISIBLE
                    binding.btnNext.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun highlightButton(lastClickedButton: AppCompatButton) {
        // Always keep both buttons highlighted
        binding.btnNext.background = ContextCompat.getDrawable(this, R.drawable.shape_color_btn)
        binding.btndone.background = ContextCompat.getDrawable(this, R.drawable.shape_color_btn)

        // Optional: Set text color (if needed)
        binding.btnNext.setTextColor(ContextCompat.getColor(this, R.color.white))
        binding.btndone.setTextColor(ContextCompat.getColor(this, R.color.white))
    }
  }

