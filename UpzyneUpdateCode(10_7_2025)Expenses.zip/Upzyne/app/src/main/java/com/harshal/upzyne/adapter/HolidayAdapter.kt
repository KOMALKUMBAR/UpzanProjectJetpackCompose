package com.harshal.upzyne.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.databinding.ItemHolidayBinding
import com.harshal.upzyne.model.HolidayData

class HolidayAdapter(private val holidayList: List<HolidayData>) :
    RecyclerView.Adapter<HolidayAdapter.HolidayViewHolder>() {

    // Define your list of colors
    private val colorList = listOf(
        Color.parseColor("#7E4EEA"),
        Color.parseColor("#E14531"),
        Color.parseColor("#F0A666"), // Removed space
        Color.parseColor("#8DC518"),
        Color.parseColor("#1CAEB2"),
        Color.parseColor("#1F639D"),
        Color.parseColor("#6640BD")
    )

    // custom color
    

    inner class HolidayViewHolder(val binding: ItemHolidayBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolidayViewHolder {
        val binding = ItemHolidayBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return HolidayViewHolder(binding)
    }

    override fun onBindViewHolder(holder: HolidayViewHolder, position: Int) {
        val item = holidayList[position]

        holder.binding.tvDate.text = item.holidaydate
        holder.binding.tvDay.text = item.weekday.lowercase()
        holder.binding.tvHolidayName.text = item.holidayname.lowercase()

        // Set random color from the list
        val randomColor = colorList.random()
        holder.binding.tvHolidayName.setTextColor(randomColor)
    }

    override fun getItemCount(): Int = holidayList.size
}
