package com.harshal.upzyne.model

class ExpensesModel {

    data class ApprovedExpense(
        val iconResId: Int,
        val title: String,
        val amount: String,
        val category: String,
        val status: String,
        val date: String,
    )


    data class Expense(
        val iconResId: Int,
        val title: String,
        val amount: String,
        val category: String,
        val status: String,
        val date: String,
    )


    data class PendingExpense(
        val avatarResId: Int,
        val title: String,
        val amount: String,
        val subtitle: String,
        val date: String,
        val iconResId: Int,
        val submitterName: String,
    )

    data class Category(
        val name: String,
        val categoryid: Int
    )

    data class ExpenseResponseModel(
        val data: List<ExpensesModel.ExpenseData>
    )

    data class ExpenseData(
        val currency: String,
        val date: String,
        val transactionid: Int,
        val memo: String,
        val amount: Double,
        val categoryname: String,
        val approvalstatus: String
    )

    data class ToatalExpensesResponseModel(
        val title: String,
        val subtitle: String,
        val totalExpenses: Double
    )
    data class GenericResponse(
        val data: String
    )
}


