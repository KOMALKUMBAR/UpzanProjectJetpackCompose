package com.harshal.upzyne.activity.settingMenu

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.UtilsMethods.togglePasswordVisibility
import com.harshal.upzyne.databinding.ActivityChangePasswordBinding
import com.harshal.upzyne.databinding.ActivityPasswordUpdateDialogBinding
import com.harshal.upzyne.model.SettingModel.ChangePasswordRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException

class ChangePasswordActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChangePasswordBinding
    private lateinit var sharedPref: SharedPreferences
    private val job = Job()
    private val coroutineScope = CoroutineScope(Dispatchers.Main + job)
    var isNewVisible = false
    var isConfirmVisible = false
    var isChangeVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChangePasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setThemeBackground(this, binding.rootLayout)
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)

        val userFullName = sharedPref.getString("user_fullname", "") ?: ""
        binding.swipinTxt.text = "${userFullName.trim().split(" ").firstOrNull() ?: ""} - change password"
        binding.imgArrowBack.setOnClickListener { finish() }
        binding.btnUpdatePassword.setOnClickListener { callChangePasswordApi() }

        binding.ivToggleNewPassword.setOnClickListener {
            isNewVisible = togglePasswordVisibility(binding.etNewPassword, binding.ivToggleNewPassword, isNewVisible)
        }

        binding.ivToggleConfirmPassword.setOnClickListener {
            isConfirmVisible = togglePasswordVisibility(binding.etConfirmPassword, binding.ivToggleConfirmPassword, isConfirmVisible)
        }

        binding.ivTogglePassword.setOnClickListener {
            isChangeVisible = togglePasswordVisibility(binding.etCurrentPassword, binding.ivTogglePassword, isChangeVisible)
        }
    }

    private fun callChangePasswordApi() {
        val oldPassword = binding.etCurrentPassword.text.toString().trim()
        val newPassword = binding.etNewPassword.text.toString().trim()
        val confirmPassword = binding.etConfirmPassword.text.toString().trim()

        if (oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
            return
        }

        if (newPassword != confirmPassword) {
            binding.etConfirmPassword.error = "Passwords do not match"
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
            return
        }

        val token = "Bearer ${sharedPref.getString("auth_token", "")}"

        val request = ChangePasswordRequest(
            oldPasswordHash = oldPassword,
            newPasswordHash = newPassword
        )

        coroutineScope.launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    ApiClient.apiService.changePassword(token, request).execute()
                }

                if (response.isSuccessful && response.body() != null) {
                    val body = response.body()!!

                    if (body.error.isNullOrEmpty()) {
                        showSuccessDialog()
                    } else {
                        if (body.error.contains("incorrect", ignoreCase = true) ||
                            body.error.contains("wrong", ignoreCase = true) ||
                            body.error.contains("invalid", ignoreCase = true)
                        ) {
                            binding.etCurrentPassword.error = "Incorrect current password"
                            Toast.makeText(
                                this@ChangePasswordActivity,
                                "Please enter the correct current password",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                this@ChangePasswordActivity,
                                body.error,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                } else {
                    Toast.makeText(this@ChangePasswordActivity, "Please enter the correct current password",
                        Toast.LENGTH_SHORT
                    ).show()
                }

            } catch (e: HttpException) {
                AppLogger.logAndToast(
                    this@ChangePasswordActivity,
                    "EC050",
                    "ChangePasswordActivity",
                    "callChangePasswordApi",
                    e
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@ChangePasswordActivity,
                    "EC051",
                    "ChangePasswordActivity",
                    "callChangePasswordApi",
                    e
                )
            }
        }
    }

    private fun showSuccessDialog() {
        val dialogBinding = ActivityPasswordUpdateDialogBinding.inflate(layoutInflater)
        val dialog = BottomSheetDialog(this)
        dialog.setContentView(dialogBinding.root)

        dialogBinding.btnYesupdate.setOnClickListener {
            dialog.dismiss()
            finish()
        }

        dialog.setCancelable(false)
        dialog.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
    }
}