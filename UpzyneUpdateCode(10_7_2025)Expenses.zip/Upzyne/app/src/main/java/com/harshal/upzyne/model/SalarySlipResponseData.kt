package com.harshal.upzyne.model

data class SalarySlipResponseData(
    val data: SalarySlipData
)

data class SalarySlipData(
    val pancard: String,
    val netpay: Double,
    val designation: String,
    val departmentname: String,
    val paidon: String,
    val leavetaken: Int,
    val bankaccountno: String,
    val totalworkdays: Int,
    val basicpay: Double,
    val leavededuction: Double,
    val attendancedays: Int,
    val employeename: String,
    val ifsccode: String,
    val medical_allowance: Double,
    val personal_allowance: Double,
    val total_deductions: Double,
    val transport_allowance: Double
)
