package com.harshal.upzyne.activity.expensesMenu

import android.app.DatePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.adapter.expensesAdapters.CategoryAdapter
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.ActivitySubmitexpenseBinding
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.text.SimpleDateFormat
import java.util.*

class SubmitexpenseActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySubmitexpenseBinding
    private lateinit var sharedPref: SharedPreferences

    private var selectedDate: String = ""
    private var selectedFileUri: Uri? = null
    private var selectedFileName: String = ""
    private var selectedCategoryId: Int = -1  // Default no category selected

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySubmitexpenseBinding.inflate(layoutInflater)
        setContentView(binding.root)

        WindowCompat.setDecorFitsSystemWindows(window, true)
        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)

        binding.imgArrow.setOnClickListener { finish() }

        binding.categoryrecyclerview.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        binding.btnBrowseFile.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "*/*"
            startActivityForResult(intent, 1001)
        }

        binding.btnSubmit.setOnClickListener {
            submitExpense()
        }

        fetchCategories()
        setupDatePicker()
    }

    private fun setupDatePicker() {
        binding.dateField.setOnClickListener {
            val calendar = Calendar.getInstance()
            val datePicker = DatePickerDialog(
                this,
                { _, year, month, day ->
                    calendar.set(year, month, day)
                    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                    selectedDate = sdf.format(calendar.time)
                    binding.dateField.setText(selectedDate)
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )

            datePicker.datePicker.minDate = System.currentTimeMillis() - 1000
            datePicker.setOnShowListener {
                datePicker.getButton(DialogInterface.BUTTON_POSITIVE)?.setTextColor(android.graphics.Color.BLACK)
                datePicker.getButton(DialogInterface.BUTTON_NEGATIVE)?.setTextColor(android.graphics.Color.BLACK)
            }
            datePicker.show()
        }
    }

    private fun fetchCategories() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@SubmitexpenseActivity,
                    apiCall = {
                        ApiClient.apiService.getCategories(
                            "Bearer ${sharedPref.getString("auth_token", "")}"
                        )
                    },
                    onSuccess = { categories ->
                        val adapter = CategoryAdapter(categories) { selectedId ->
                            selectedCategoryId = selectedId
                        }
                        binding.categoryrecyclerview.adapter = adapter
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@SubmitexpenseActivity,
                            "EC041",
                            "SubmitexpenseActivity",
                            "fetchCategories",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(this@SubmitexpenseActivity, "EC041", "SubmitexpenseActivity", "fetchCategories", e)
            }
        }
    }

    private fun submitExpense() {
        if (!checkNetworkAndShowMessage(this)) return
        if (selectedFileUri == null) {
            UtilsMethods.toast(this, "Please select a file.")
            return
        }

        val amount = binding.amountField.text.toString().toDoubleOrNull()
        val currency = "INR"
        val memo = binding.memoField.text.toString()

        if (amount == null || selectedDate.isEmpty() || selectedCategoryId == -1) {
            UtilsMethods.toast(this, "Please complete all fields.")
            return
        }

        uploadExpenseData(selectedCategoryId, amount, currency, selectedDate, memo, selectedFileUri!!)
    }

    private fun uploadExpenseData(
        categoryId: Int,
        amount: Double,
        currency: String,
        date: String,
        memo: String,
        fileUri: Uri
    ) {
        lifecycleScope.launch {
            try {
                val file = prepareFilePart(this@SubmitexpenseActivity, "file", fileUri)

                val json = """
                    {
                        "categoryId": $categoryId,
                        "amount": $amount,
                        "currency": "$currency",
                        "date": "$date",
                        "memo": "$memo"
                    }
                """.trimIndent()

                val jsonRequestBody = json.toRequestBody("application/json".toMediaTypeOrNull())

                val response = ApiClient.apiService.addExpense(
                    token = "Bearer ${sharedPref.getString("auth_token", "")}",
                    expenseData = jsonRequestBody,
                    file = file
                )

                if (response.isSuccessful) {
                    UtilsMethods.toast(this@SubmitexpenseActivity, "Expense added successfully.")
                    finish()
                } else {
                    AppLogger.logAndToast(this@SubmitexpenseActivity, "EC050", "SubmitexpenseActivity", "uploadExpenseData", Exception(response.message()))
                }
            } catch (e: Exception) {
                AppLogger.logAndToast(this@SubmitexpenseActivity, "EC050", "SubmitexpenseActivity", "uploadExpenseData", e)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK && data != null) {
            selectedFileUri = data.data
            selectedFileName = getFileName(this, selectedFileUri!!) ?: "Selected File"
            binding.selectedFileName.text = selectedFileName
            binding.selectedFileName.visibility = View.VISIBLE
        }
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        return if (cursor != null && cursor.moveToFirst()) {
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            cursor.getString(nameIndex).also { cursor.close() }
        } else uri.path?.substringAfterLast('/')
    }

    private fun prepareFilePart(context: Context, partName: String, fileUri: Uri): MultipartBody.Part {
        val contentResolver = context.contentResolver
        val inputStream = contentResolver.openInputStream(fileUri)!!
        val fileBytes = inputStream.readBytes()
        val requestFile = fileBytes.toRequestBody(contentResolver.getType(fileUri)?.toMediaTypeOrNull())
        return MultipartBody.Part.createFormData(partName, getFileName(context, fileUri), requestFile)
    }
}
