package com.harshal.upzyne.model

data class AttendanceData(
    val name: String,
    val totalworkinghours: String,
    val loginimage: String,
    val daytype: String,
    val logouttime: String,
    val logintime: String
)

data class AttendanceTodayResponse(
    val data: AttendanceData? = null
)
