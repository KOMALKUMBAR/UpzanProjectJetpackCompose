package com.harshal.upzyne.model

data class menu_item_data(
    val title: String,
    val subItems: List<String>,
    val iconResId: Int,
    var isExpanded: Boolean = false
)
