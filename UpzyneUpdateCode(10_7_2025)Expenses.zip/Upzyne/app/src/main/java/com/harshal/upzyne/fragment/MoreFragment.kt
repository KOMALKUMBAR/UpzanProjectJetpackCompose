package com.harshal.upzyne.fragment

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity.MODE_PRIVATE
import androidx.appcompat.app.AppCompatActivity.RESULT_OK
import androidx.core.view.WindowCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.harshal.upzyne.activity.LoginActivity
import com.harshal.upzyne.activity.hrmsMenu.MarkAttendanceActivity
import com.harshal.upzyne.R
import com.harshal.upzyne.activity.settingMenu.ThemeActivity
import com.harshal.upzyne.databinding.FragmentMoreBinding
import com.harshal.upzyne.adapter.menuAdapter
import com.harshal.upzyne.activity.hrmsMenu.AttendanceLogActivity
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.UtilsMethods
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.hideLoading
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.UtilsMethods.showLoading
import com.harshal.upzyne.activity.hrmsMenu.ApplicationsLeaveActivity
import com.harshal.upzyne.activity.hrmsMenu.ApplyLeaveActivity
import com.harshal.upzyne.activity.hrmsMenu.HRAnnouncementActivity
import com.harshal.upzyne.activity.hrmsMenu.SalariesActivity
import com.harshal.upzyne.activity.settingMenu.SettingPageActivity
import com.harshal.upzyne.activity.hrmsMenu.TeamContactsActivity
import com.harshal.upzyne.activity.expensesMenu.ViewExpenseActivity
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.databinding.DialogLogoutBinding
import com.harshal.upzyne.model.menu_item_data
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

class MoreFragment : Fragment() {
    private var _binding: FragmentMoreBinding? = null
    private val binding get() = _binding!!
    private lateinit var sharedPref: SharedPreferences
    private lateinit var baseUrl: String
    private var selectedFileUri: Uri? = null

    private val menuItems = listOf(
        /*menu_item_data("dashboard", emptyList(), R.drawable.dashboard),
        menu_item_data("leads", emptyList(), R.drawable.leads_ic),
        menu_item_data("training", emptyList(), R.drawable.training),
        menu_item_data("expenses", emptyList(), R.drawable.expenses),
        menu_item_data("AI insides", emptyList(), R.drawable.aiinsides),*/

                menu_item_data(
            "hrms", listOf(
                "mark attendance", "attendance logs", "apply for leave",
                "leave history & status", "pay slips", "team contacts", "hr holiday requests"
            ),
            R.drawable.hrms
        ),
        /*menu_item_data("notifications", emptyList(), R.drawable.ic_notification),
        menu_item_data("contact team", emptyList(), R.drawable.contact_team),*/
        menu_item_data("setting", emptyList(), R.drawable.settings_ic),
        menu_item_data("expenses", emptyList(), R.drawable.expenses),
        menu_item_data("logout", emptyList(), R.drawable.logout)

    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMoreBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        WindowCompat.setDecorFitsSystemWindows(
            requireActivity().window,
            true
        )  //for screen within the window

        sharedPref = requireContext().getSharedPreferences("app_prefs", MODE_PRIVATE)
        baseUrl = sharedPref.getString("base_url", "").toString()

        setThemeBackground(requireContext(), binding.recyclerView)

        getBasicProfile()

        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        val adapter = menuAdapter(
            menuItems,
            onSubItemClick = { parent, subItem ->
                when (subItem) {
                    //hrms
                    "mark attendance" -> startActivity(
                        Intent(
                            requireContext(),
                            MarkAttendanceActivity::class.java
                        )
                    )

                    "attendance logs" -> startActivity(
                        Intent(
                            requireContext(),
                            AttendanceLogActivity::class.java
                        )
                    )

                    "apply for leave" -> startActivity(
                        Intent(
                            requireContext(),
                            ApplyLeaveActivity::class.java
                        )
                    )

                    "leave history & status" -> startActivity(
                        Intent(
                            requireContext(),
                            ApplicationsLeaveActivity::class.java
                        )
                    )

                    "pay slips" -> startActivity(
                        Intent(
                            requireContext(),
                            SalariesActivity::class.java
                        )
                    )

                    "team contacts" -> startActivity(
                        Intent(
                            requireContext(),
                            TeamContactsActivity::class.java
                        )
                    )

                    "hr holiday requests" -> startActivity(
                        Intent(
                            requireContext(),
                            HRAnnouncementActivity::class.java
                        )
                    )
                    //setting
                    "themes" -> startActivity(Intent(requireContext(), ThemeActivity::class.java))

                    else -> Toast.makeText(requireContext(), "select menu", Toast.LENGTH_SHORT)
                        .show()
                }
            },
            onItemClick = { item ->
                when (item.title.lowercase()) {
                    "logout" -> {
                        val binding =
                            DialogLogoutBinding.inflate(LayoutInflater.from(requireContext()))

                        val alertDialog = MaterialAlertDialogBuilder(requireContext())
                            .setView(binding.root)
                            .create()

                        binding.btnYes.setOnClickListener {
                            with(sharedPref.edit()) {
                                putBoolean("is_logged_in", false)
                                apply()
                            }
                            val intent = Intent(requireContext(), LoginActivity::class.java)
                            startActivity(intent)
                            requireActivity().finish()
                            alertDialog.dismiss()
                        }

                        binding.btnCancel.setOnClickListener {
                            alertDialog.dismiss()
                        }

                        alertDialog.show()
                    }

                    "setting" -> {
                        val intent = Intent(requireContext(), SettingPageActivity::class.java)
                        startActivity(intent)
                    }

                    "expenses"->{
                         val intent =Intent(requireContext(),ViewExpenseActivity::class.java)
                        startActivity(intent)
                    }

                    else -> {
                        Toast.makeText(
                            requireContext(),
                            "Clicked: ${item.title}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        )
        binding.recyclerView.adapter = adapter
    }

    private fun getBasicProfile() {
        if (!checkNetworkAndShowMessage(requireContext())) return

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.basicInfo(
                    "Bearer ${
                        sharedPref.getString(
                            "auth_token",
                            ""
                        )
                    }"
                )

                ApiRequestHandler.makeSuspendApiCall(
                    context = requireContext(),
                    apiCall = { call },
                    onSuccess = { response ->
                        Log.d("ProfileSuccess", response.data.toString())
                        val profile = response.data
                        binding.profileName.text = profile.fullName
                        binding.profileDesc.text = profile.designation
                        binding.profileDepartment.text = profile.departmentName
                        binding.profileCode.text = profile.employeeId

                        val imageUrl = "${baseUrl + profile.profileUrl}?t=${System.currentTimeMillis()}"
                        Glide.with(this@MoreFragment)
                            .load(imageUrl)
                            .placeholder(R.drawable.profile)
                            .error(R.drawable.noimage)
                            .into(binding.profileImg)

                        with(sharedPref.edit()) {
                            putString("user_fname", profile.fullName.trim().split(" ").firstOrNull() ?: "")
                            putString("user_fullname", profile.fullName)
                            putString("user_email", profile.email)
                            putString("user_contact", profile.contactNumber)
                            apply()
                        }

                        binding.profileImg.setOnClickListener {
                            try {
                                val intent = Intent(Intent.ACTION_GET_CONTENT)
                                intent.type = "*/*"
                                startActivityForResult(intent, 1001)
                            } catch (e: Exception) {
                                Log.e("openstorage", "Exception: " + e.message)
                                AppLogger.logAndToast(
                                    requireContext(),
                                    "EC046",
                                    "DocumentActivity",
                                    "btnBrowseFile",
                                    Exception()
                                )
                            }
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            requireContext(),
                            "EC041",
                            "MoreFragment",
                            "getBasicProfile",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                UtilsMethods.AppLogger.logAndToast(
                    requireContext(),
                    "EC041",
                    "MoreFragment",
                    "getBasicProfile",
                    e
                )
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                selectedFileUri = uri
                uploadDocument(selectedFileUri!!)
            }
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = "file"
        val cursor = requireContext().contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && index != -1) {
                name = it.getString(index)
            }
        }
        return name
    }

    fun copyUriToTempFile(uri: Uri): File {
        val inputStream = context?.contentResolver?.openInputStream(uri)
            ?: throw IllegalArgumentException("Can't open input stream from URI")

        val fileName = getFileName(uri)
        val tempFile = File(requireContext().cacheDir, fileName)

        tempFile.outputStream().use { outputStream ->
            inputStream.copyTo(outputStream)
        }

        return tempFile
    }


    private fun uploadDocument(filePath:Uri) {
        lifecycleScope.launch {
            try {
                showLoading(requireContext())

                val file = copyUriToTempFile(filePath)
                val requestBody = file.asRequestBody("image/*".toMediaTypeOrNull())
                val multipart = MultipartBody.Part.createFormData("file", file.toString(), requestBody)

                Log.d("profileimage", "$file / $requestBody / $multipart")

                val response = withContext(Dispatchers.IO) {
                    ApiClient.apiService.uploadProfileImage(
                        "Bearer ${sharedPref.getString("auth_token", "")}",
                        multipart
                    ).execute()
                }

                if (response.isSuccessful && response.body() != null) {
                    selectedFileUri = null
                    getBasicProfile()
                } else {
                    Toast.makeText(requireContext(), "Failed to upload image: ${response.code()}", Toast.LENGTH_SHORT).show()
                }
                hideLoading()
            } catch (e: Exception) {
                Log.e("uploaderror", e.message.toString())
                /*AppLogger.logAndToast(
                    requireContext(),
                    "EC048",
                    "DocumentActivity",
                    "uploadDocument",
                    Exception()
                )*/
            }
        }
    }

    override fun onResume() {
        super.onResume()
        setThemeBackground(requireContext(), binding.recyclerView)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
