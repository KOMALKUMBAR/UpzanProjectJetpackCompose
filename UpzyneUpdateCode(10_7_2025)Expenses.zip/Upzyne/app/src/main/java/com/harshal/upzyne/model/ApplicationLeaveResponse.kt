package com.harshal.upzyne.model

data class ApplicationLeaveResponse(
    val data: List<LeaveApplication>
)
data class LeaveApplication(
    val dateto: String,
    val status: String,
    val remarks: String,
    val leaveperiod: String,
    val datefrom: String,
    val applicationdate: String,
    val leavetype: String
)