package com.harshal.upzyne.model

data class ThemeResponse(
    val backgrounds: List<Backgrounds>
)

data class Backgrounds(
    val name: String,
    val centerColor: String,
    val endColor: String,
    val startColor: String
)