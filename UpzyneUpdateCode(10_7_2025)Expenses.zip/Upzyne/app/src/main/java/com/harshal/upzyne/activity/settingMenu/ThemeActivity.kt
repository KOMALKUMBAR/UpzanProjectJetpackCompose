package com.harshal.upzyne.activity.settingMenu

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.harshal.upzyne.databinding.ActivityThemeBinding
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.UtilsMethods.saveGradientColors
import com.harshal.upzyne.UtilsMethods.setDynamicGradientBackground
import com.harshal.upzyne.checkNetworkAndShowMessage
import com.harshal.upzyne.model.Backgrounds
import kotlinx.coroutines.launch

class ThemeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityThemeBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String
    lateinit var userFullName: String
    private lateinit var themeList: List<Backgrounds>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityThemeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val token = sharedPref.getString("auth_token", "") ?: ""
        bearerToken = "Bearer $token"

        userFullName = sharedPref.getString("user_fullname", "").toString()
        binding.tvTitle.text = "${userFullName.trim().split(" ").firstOrNull() ?: ""} - themes"

        fetchThemes()

        binding.imgBack.setOnClickListener {
            finish()
        }

        binding.btnTheme1.setOnClickListener {
            val selectedBackground = themeList[0]
            saveTheme(selectedBackground)
        }
        binding.btnTheme2.setOnClickListener {
            val selectedBackground = themeList[1]
            saveTheme(selectedBackground)
        }
        binding.btnTheme3.setOnClickListener {
            val selectedBackground = themeList[2]
            saveTheme(selectedBackground)
        }
        binding.btnTheme4.setOnClickListener {
            val selectedBackground = themeList[3]
            saveTheme(selectedBackground)
        }
        binding.btnTheme5.setOnClickListener {
            val selectedBackground = themeList[4]
            saveTheme(selectedBackground)
        }
        binding.btnTheme6.setOnClickListener {
            val selectedBackground = themeList[5]
            saveTheme(selectedBackground)
        }
        binding.btnTheme7.setOnClickListener {
            val selectedBackground = themeList[6]
            saveTheme(selectedBackground)
        }
        binding.btnTheme8.setOnClickListener {
            val selectedBackground = themeList[7]
            saveTheme(selectedBackground)
        }
    }

    private fun saveTheme(selectedBackground: Backgrounds) {
        // Save the gradient colors
        saveGradientColors(
            this@ThemeActivity,
            selectedBackground.startColor,
            selectedBackground.centerColor,
            selectedBackground.endColor
        )
        Toast.makeText(this@ThemeActivity, "Theme saved successfully", Toast.LENGTH_SHORT).show()
    }

    private fun fetchThemes() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                val call = ApiClient.apiService.getThemes(bearerToken)

                ApiRequestHandler.makeSuspendApiCall(
                    context = this@ThemeActivity,
                    apiCall = { call },
                    onSuccess = { response ->
                        themeList = response.backgrounds

                        if (themeList.isNotEmpty()) {
                            binding.btnTheme1.setDynamicGradientBackground(
                                startColor = themeList[0].startColor,
                                centerColor = themeList[0].centerColor,
                                endColor = themeList[0].endColor,
                                cornerRadiusDp = 10f
                            )

                            binding.btnTheme2.setDynamicGradientBackground(
                                startColor = themeList[1].startColor,
                                centerColor = themeList[1].centerColor,
                                endColor = themeList[1].endColor,
                                cornerRadiusDp = 10f
                            )

                            binding.btnTheme3.setDynamicGradientBackground(
                                startColor = themeList[2].startColor,
                                centerColor = themeList[2].centerColor,
                                endColor = themeList[2].endColor,
                                cornerRadiusDp = 10f
                            )

                            binding.btnTheme4.setDynamicGradientBackground(
                                startColor = themeList[3].startColor,
                                centerColor = themeList[3].centerColor,
                                endColor = themeList[3].endColor,
                                cornerRadiusDp = 10f
                            )

                            binding.btnTheme5.setDynamicGradientBackground(
                                startColor = themeList[4].startColor,
                                centerColor = themeList[4].centerColor,
                                endColor = themeList[4].endColor,
                                cornerRadiusDp = 10f
                            )

                            binding.btnTheme6.setDynamicGradientBackground(
                                startColor = themeList[5].startColor,
                                centerColor = themeList[5].centerColor,
                                endColor = themeList[5].endColor,
                                cornerRadiusDp = 10f
                            )

                            binding.btnTheme7.setDynamicGradientBackground(
                                startColor = themeList[6].startColor,
                                centerColor = themeList[6].centerColor,
                                endColor = themeList[6].endColor,
                                cornerRadiusDp = 10f
                            )

                            binding.btnTheme8.setDynamicGradientBackground(
                                startColor = themeList[7].startColor,
                                centerColor = themeList[7].centerColor,
                                endColor = themeList[7].endColor,
                                cornerRadiusDp = 10f
                            )
                        } else {
                            Toast.makeText(
                                this@ThemeActivity,
                                "No themes found",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@ThemeActivity,
                            "EC046",
                            "ThemeActivity",
                            "fetchThemes",
                            Exception(error)
                        )
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@ThemeActivity,
                    "EC046",
                    "ThemeActivity",
                    "fetchThemes",
                    e
                )
            }
        }
    }
}