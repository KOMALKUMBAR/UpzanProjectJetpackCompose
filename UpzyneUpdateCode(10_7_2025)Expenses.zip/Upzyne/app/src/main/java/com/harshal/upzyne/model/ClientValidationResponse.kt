package com.harshal.upzyne.model

data class ClientValidationResponse(
    val data: ClientData
)

data class ClientData(
    val appId: Int,
    val clientId: String,
    val tenantId: Int,
    val isActive: Boolean,
    val productName: String,
    val validUpTo: String,
    val licenseStatus: String,
    val tenantName: String,
    val baseUrl: String
)