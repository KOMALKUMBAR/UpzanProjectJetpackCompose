package com.harshal.upzyne.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.harshal.upzyne.R
import com.harshal.upzyne.UtilsMethods.setThemeBackground
import com.harshal.upzyne.databinding.ItemHrabsentBinding
import com.harshal.upzyne.model.AbsentMember

class AbsentColleagueAdapter (private val baseUrl: String, private val list: List<AbsentMember>) :
    RecyclerView.Adapter<AbsentColleagueAdapter.ColleagueViewHolder>() {

    inner class ColleagueViewHolder(val binding: ItemHrabsentBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ColleagueViewHolder {
        val binding = ItemHrabsentBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ColleagueViewHolder(binding)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ColleagueViewHolder, position: Int) {
        setThemeBackground(holder.itemView.context, holder.binding.rootLayout)

        val item = list[position]
        Log.d("absentImage", baseUrl+item.profileurl)
         Glide.with(holder.itemView.context)
            .load(baseUrl+item.profileurl)
            .placeholder(R.drawable.profile) // optional
            .error(R.drawable.noimage)       // optional
            .into(holder.binding.imageProfile)
        //holder.binding.imageProfile.setImageResource(item.profileurl)
        holder.binding.textName.text = item.name
        holder.binding.textDate.text = item.leavedate
    }
}
