package com.example.upsyneexpenses.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.R
import com.harshal.upzyne.model.ExpensesModel

class AllExpensesAdapter(private val context: Context, private val list: List<ExpensesModel.ExpenseData>
) : RecyclerView.Adapter<AllExpensesAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtDate: TextView = view.findViewById(R.id.expenseDate)
        val txtMemo: TextView = view.findViewById(R.id.expenseTitle)
        val txtAmount: TextView = view.findViewById(R.id.  expenseAmount)
        val txtCategory: TextView = view.findViewById(R.id.expenseCategory)
        val txtStatus: TextView = view.findViewById(R.id.expenseStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_view_expense_card, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = list[position]
        holder.txtDate.text = item.date
        holder.txtMemo.text = item.memo
        holder.txtAmount.text = "${item.amount}"
        holder.txtCategory.text = item.categoryname
        holder.txtStatus.text = item.approvalstatus

        when(item.approvalstatus.lowercase()){
            "pending" -> {
                holder.txtStatus.setBackgroundResource(R.drawable.status_pending_bg)
                holder.txtStatus.setTextColor(context.getColor(R.color.orange)) // orange text
            }
            "approved" -> {
                holder.txtStatus.setBackgroundResource(R.drawable.shape_approved)
                holder.txtStatus.setTextColor(context.getColor(R.color.green)) // green text
            }
            "rejected" -> {
                holder.txtStatus.setBackgroundResource(R.drawable.status_rejected_bg)
                holder.txtStatus.setTextColor(context.getColor(R.color.red)) // red text
            }
            else -> {
                holder.txtStatus.setBackgroundResource(android.R.color.transparent)
                holder.txtStatus.setTextColor(context.getColor(R.color.black))
            }
        }
    }



}
