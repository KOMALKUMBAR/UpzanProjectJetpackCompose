package com.harshal.upzyne.model

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class CallReceiver : BroadcastReceiver() {

    companion object {
        private var lastCallTime: Long = 0L
        private const val MIN_TIME_BETWEEN_CALLS_MS = 3000 // 3 seconds
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        try {
            if (intent?.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED || context == null) return

            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            val phoneNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

            Log.d("CallReceiver", "State: $state, Number: $phoneNumber")

            if (state == TelephonyManager.EXTRA_STATE_RINGING && !phoneNumber.isNullOrBlank()) {
                val currentTime = System.currentTimeMillis()

                // Debounce multiple calls
                if (currentTime - lastCallTime < MIN_TIME_BETWEEN_CALLS_MS) return
                lastCallTime = currentTime

                if (Settings.canDrawOverlays(context)) {
                    val time = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())

                    val serviceIntent = Intent(context, FloatingWindowService::class.java).apply {
                        putExtra("phone", phoneNumber)
                        putExtra("time", time)
                        putExtra("is_incoming", true)
                    }

                    Log.d("CallReceiver", "Starting service with number: $phoneNumber at $time")
                    ContextCompat.startForegroundService(context, serviceIntent)
                } else {
                    Log.w("CallReceiver", "Overlay permission not granted")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
