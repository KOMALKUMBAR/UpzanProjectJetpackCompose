package com.harshal.upzyne.model

data class LoginResponse (
    val data: LoginData
)

data class LoginData(
    val token : String,
    val username: String
)