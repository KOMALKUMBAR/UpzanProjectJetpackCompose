package com.harshal.upzyne.activity.hrmsMenu

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.harshal.upzyne.ApiClient
import com.harshal.upzyne.ApiRequestHandler
import com.harshal.upzyne.UtilsMethods.AppLogger
import com.harshal.upzyne.adapter.SalariesAdapter
import com.harshal.upzyne.databinding.ActivitySalariesBinding
import com.harshal.upzyne.checkNetworkAndShowMessage
import kotlinx.coroutines.launch

class SalariesActivity:AppCompatActivity() {
    private lateinit var binding: ActivitySalariesBinding
    private lateinit var sharedPref: SharedPreferences
    private lateinit var bearerToken: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySalariesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val userFullName = sharedPref.getString("user_fullname", "")
        binding.swipinTxt.text = "${userFullName?.trim()?.split(" ")?.firstOrNull() ?: ""} - salary slip"
        val token = sharedPref.getString("auth_token", "") ?: ""
        bearerToken = "Bearer $token"

        binding.imgArrow.setOnClickListener {
            finish()
        }

        binding.recyclerSalaries.layoutManager = LinearLayoutManager(this)

        fetchSalaries()
    }

    private fun fetchSalaries() {
        if (!checkNetworkAndShowMessage(this)) return

        lifecycleScope.launch {
            try {
                ApiRequestHandler.makeSuspendApiCall(
                    context = this@SalariesActivity,
                    apiCall = {
                        ApiClient.apiService.getSalaries(bearerToken)
                    },
                    onSuccess = { response ->
                        val salaryList = response.data
                        Log.d("SalariesSuccess", salaryList.toString())

                        if (salaryList.isNullOrEmpty()) {
                            binding.emptyState.visibility = View.VISIBLE
                            binding.recyclerSalaries.visibility = View.GONE
                        } else {
                            binding.emptyState.visibility = View.GONE
                            binding.recyclerSalaries.visibility = View.VISIBLE

                            val salariesAdapter = SalariesAdapter(salaryList)
                            binding.recyclerSalaries.adapter = salariesAdapter
                        }
                    },
                    onError = { error ->
                        AppLogger.logAndToast(
                            this@SalariesActivity,
                            "EC025",
                            "SalariesActivity",
                            "fetchSalaries",
                            Exception(error)
                        )

                        binding.emptyState.visibility = View.VISIBLE
                        binding.recyclerSalaries.visibility = View.GONE
                    }
                )
            } catch (e: Exception) {
                AppLogger.logAndToast(
                    this@SalariesActivity,
                    "EC025",
                    "SalariesActivity",
                    "fetchSalaries",
                    e
                )
            }
        }
    }

}
