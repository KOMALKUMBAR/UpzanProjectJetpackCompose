package com.example.upsyneexpenses.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.upsyneexpenses.adapter.PendingExpensesAdapter
import com.harshal.upzyne.R
import com.harshal.upzyne.databinding.FragmentPendingExpensesBinding
import com.harshal.upzyne.model.ExpensesModel

class PendingExpensesFragment : Fragment() {

    private var _binding: FragmentPendingExpensesBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?, ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentPendingExpensesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val pendingItems = listOf(
            ExpensesModel.PendingExpense(
                R.drawable.buisnessmeal,
                "business meal",
                "₹2,400",
                "team dinner with client",
                "Oct 15, 2025",
                R.drawable.profile,
                "sarah chen"
            ),
            ExpensesModel.PendingExpense(
                R.drawable.desktop,
                "equipment",
                "₹12,400",
                "macbook pro m2",
                "Oct 14, 2025",
                R.drawable.profile,
                "michael park"
            ),
            ExpensesModel.PendingExpense(
                R.drawable.pendingtravel,
                "travel",
                "₹12,400",
                "flight to mumbai",
                "Oct 15, 2025",
                R.drawable.profile,
                "emma wilson"
            )
        )

        binding.PendingexpensesRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.PendingexpensesRecyclerView.adapter = PendingExpensesAdapter(pendingItems)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}


