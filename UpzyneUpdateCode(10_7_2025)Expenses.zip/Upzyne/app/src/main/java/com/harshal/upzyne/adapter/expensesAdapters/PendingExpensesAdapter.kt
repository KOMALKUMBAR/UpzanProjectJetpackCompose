package com.example.upsyneexpenses.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.harshal.upzyne.databinding.ItemViewPendingCardBinding
import com.harshal.upzyne.model.ExpensesModel


class PendingExpensesAdapter(private val  list: List<ExpensesModel.PendingExpense>): RecyclerView.Adapter<PendingExpensesAdapter.ViewHolder>(){

    class ViewHolder(val binding: ItemViewPendingCardBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemViewPendingCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = list[position]
        with(holder.binding) {

            buisnessIcon.setImageResource(item.avatarResId)
            pendingexpTitle.text = item.title
            pendingexpAmount.text = item.amount
            pendingexpSubtitle.text = item.subtitle
            pendingexpDate.text = item.date
            pendingexpCircluarImg.setImageResource(item.iconResId)
            pendingexpSubmitter.text = "submitted by ${item.submitterName}"

        }
    }
        override fun getItemCount(): Int = list.size

}
