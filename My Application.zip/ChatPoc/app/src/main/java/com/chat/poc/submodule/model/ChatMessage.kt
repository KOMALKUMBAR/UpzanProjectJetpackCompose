package com.chat.poc.submodule.model

data class ChatMessage(
    val message: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val timestamp: String = System.currentTimeMillis().toString()
)

data class NotificationData(
    val title: String,
     val message: String)

data class PushNotification(
    val data: NotificationData,
    val to: String
)
data class Message(
    val senderId: String = "",
    val message: String? = null
)
