package com.chat.poc.legacy

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chat.poc.R
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity: AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth
    private lateinit var messageAdapter: MessageAdapter
    private val messageList = mutableListOf<Message>()
    lateinit var recyclerViewMessages:RecyclerView
    lateinit var buttonSend:Button
    lateinit var editTextMessage:EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerViewMessages = findViewById(R.id.recyclerViewMessages)
        buttonSend = findViewById(R.id.buttonSend)
        editTextMessage = findViewById(R.id.editTextMessage)
        // Initialize Firebase
        FirebaseApp.initializeApp(this@MainActivity)
        database = FirebaseDatabase.getInstance().reference.child("messages")
        auth = FirebaseAuth.getInstance()

        // Sign in anonymously for demo purposes
        //signInAnonymously()

        setupRecyclerView()
        setupSendButton()
        loadMessages()
    }

    private fun signInAnonymously() {
        auth.signInAnonymously()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Signed in successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Authentication failed", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun setupRecyclerView() {
        messageAdapter = MessageAdapter(messageList, auth.currentUser?.uid ?: "")
        recyclerViewMessages.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = messageAdapter
        }
    }

    private fun setupSendButton() {
        buttonSend.setOnClickListener {
            val messageText = editTextMessage.text.toString().trim()
            if (messageText.isNotEmpty()) {
                sendMessage(messageText)
                editTextMessage.text?.clear()
            }
        }
    }

    private fun sendMessage(messageText: String) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            val messageId = database.push().key ?: return
            val timestamp = System.currentTimeMillis()

            val message = Message(
                id = messageId,
                text = messageText,
                senderId = currentUser.uid,
                senderName = "User ${currentUser.uid.take(6)}", // Simple username
                timestamp = timestamp
            )

            database.child(messageId).setValue(message)
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to send message", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun loadMessages() {
        database.orderByChild("timestamp").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                messageList.clear()
                for (messageSnapshot in snapshot.children) {
                    val message = messageSnapshot.getValue(Message::class.java)
                    message?.let { messageList.add(it) }
                }
                messageAdapter.notifyDataSetChanged()

                // Scroll to bottom to show latest message
                if (messageList.isNotEmpty()) {
                    recyclerViewMessages.scrollToPosition(messageList.size - 1)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainActivity, "Failed to load messages", Toast.LENGTH_SHORT).show()
            }
        })
    }
}

// Message data class
data class Message(
    val id: String = "",
    val text: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val timestamp: Long = 0
) {
    fun getFormattedTime(): String {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}