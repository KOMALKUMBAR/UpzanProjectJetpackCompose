package com.chat.poc.submodule

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.chat.poc.databinding.ActivityLoginBinding
import com.chat.poc.submodule.model.LoginUser
import com.google.firebase.database.FirebaseDatabase

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Check if already logged in
        val pref = getSharedPreferences("MyAppPref", MODE_PRIVATE)
        val savedUsername = pref.getString("first_name", null)
        if (!savedUsername.isNullOrEmpty()) {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
            return
        }

        binding.btnLogin.setOnClickListener {
            val username = binding.etUsername.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val userRef = FirebaseDatabase.getInstance().getReference("users").child(username)

            userRef.get().addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    // LOGIN
                    val savedPassword = snapshot.child("userpassword").value.toString()
                    if (password == savedPassword) {
                        saveUsernameToPref(username)
                        Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()
                        goToMainActivity()
                    } else {
                        Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    // REGISTER
                    val newUser = LoginUser(username, password)
                    userRef.setValue(newUser).addOnSuccessListener {
                        saveUsernameToPref(username)
                        Toast.makeText(this, "Registered and logged in", Toast.LENGTH_SHORT).show()
                        goToMainActivity()
                    }.addOnFailureListener {
                        Toast.makeText(this, "Registration failed: ${it.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }.addOnFailureListener {
                Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveUsernameToPref(username: String) {
        val sharedPref = getSharedPreferences("MyAppPref", MODE_PRIVATE)
        sharedPref.edit().putString("first_name", username).apply()
    }

    private fun goToMainActivity() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
