package com.chat.poc.submodule.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity.MODE_PRIVATE
import androidx.recyclerview.widget.RecyclerView
import com.chat.poc.databinding.ItemChatBinding
import com.chat.poc.legacy.MainActivity
import com.chat.poc.submodule.CommunicationActivity
import com.chat.poc.submodule.model.LoginUser

class HomeAdpter(
    private val context: Context,
    private val userList: List<LoginUser>
) : RecyclerView.Adapter<HomeAdpter.UserViewHolder>() {

    inner class UserViewHolder(val binding: ItemChatBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val binding = ItemChatBinding.inflate(LayoutInflater.from(context), parent, false)
        return UserViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = userList[position]
        holder.binding.chatName.text = user.username
        holder.itemView.setOnClickListener {
            val sharedPref = context.getSharedPreferences("MyAppPref", MODE_PRIVATE)
            val firstName = sharedPref.getString("first_name", "User") ?: "User"

            val intent = Intent(context, CommunicationActivity::class.java)
            intent.putExtra("sender", firstName)
            intent.putExtra("receiver", user.username)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return userList.size
    }
}
