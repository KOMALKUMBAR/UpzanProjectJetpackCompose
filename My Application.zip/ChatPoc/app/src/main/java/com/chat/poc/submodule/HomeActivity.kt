package com.chat.poc.submodule

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.chat.poc.ContactListActivity
import com.chat.poc.databinding.ActivityHomeBinding
import com.chat.poc.submodule.adapter.HomeAdpter
import com.chat.poc.submodule.model.LoginUser
import com.google.firebase.database.*

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var userAdapter: HomeAdpter
    private lateinit var userList: ArrayList<LoginUser>
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //komal
        binding.icBackArrow.setOnClickListener({finish()})
         binding.MainfabNewChat.setOnClickListener {
             val intent = Intent(this, ContactListActivity::class.java)
             startActivity(intent)
         }

        val sharedPref = getSharedPreferences("MyAppPref", MODE_PRIVATE)
        val firstName = sharedPref.getString("first_name", null)

        if (firstName == null) {
            // If no username found, redirect to login
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        binding.tvTitle.text = "$firstName - New Chat"



        database = FirebaseDatabase.getInstance().getReference("users")
        userList = ArrayList()
        userAdapter = HomeAdpter(this, userList)

        binding.chatListRecycler.layoutManager = LinearLayoutManager(this)
        binding.chatListRecycler.adapter = userAdapter

        fetchUsers(firstName)
    }

    private fun fetchUsers(currentUsername: String) {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                userList.clear()
                for (userSnap in snapshot.children) {
                    val user = userSnap.getValue(LoginUser::class.java)
                    if (user != null && user.username != currentUsername) {
                        userList.add(user)
                    }
                }
                userAdapter.notifyDataSetChanged()
                binding.noUsersText.visibility = if (userList.isEmpty()) View.VISIBLE else View.GONE
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d("TAG", "onCancelled: error:$error")
                // Handle error
            }
        })
    }
}
