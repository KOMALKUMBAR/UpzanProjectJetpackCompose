package com.chat.poc

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.chat.poc.databinding.ActivityContactListBinding
import com.chat.poc.submodule.LoginActivity
import com.chat.poc.submodule.adapter.HomeAdpter
import com.chat.poc.submodule.model.LoginUser
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
//komal
class ContactListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityContactListBinding
    private lateinit var userAdapter: HomeAdpter
    private lateinit var userList: ArrayList<LoginUser>
    private lateinit var database: DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //komal
        binding.icBackArrow.setOnClickListener({finish()})
        binding.recyclerViewvChats.setOnClickListener {
            val intent = Intent(this, ContactListActivity::class.java)
            startActivity(intent)
        }

        val sharedPref = getSharedPreferences("MyAppPref", MODE_PRIVATE)
        val firstName = sharedPref.getString("first_name", null)

        if (firstName == null) {
            // If no username found, redirect to login
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        binding.tvTitle.text = "$firstName - New Chat"



        database = FirebaseDatabase.getInstance().getReference("users")
        userList = ArrayList()
        userAdapter = HomeAdpter(this, userList)

        binding.recyclerViewvChats.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewvChats.adapter = userAdapter

        fetchUsers(firstName)
    }

    private fun fetchUsers(currentUsername: String) {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                userList.clear()
                for (userSnap in snapshot.children) {
                    val user = userSnap.getValue(LoginUser::class.java)
                    if (user != null && user.username != currentUsername) {
                        userList.add(user)
                    }
                }
                userAdapter.notifyDataSetChanged()
               // binding.noUsersText.visibility = if (userList.isEmpty()) View.VISIBLE else View.GONE
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d("TAG", "onCancelled: error:$error")
                // Handle error
            }
        })
    }
}

