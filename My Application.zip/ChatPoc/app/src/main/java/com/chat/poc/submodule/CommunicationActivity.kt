package com.chat.poc.submodule


import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.chat.poc.databinding.ActivityCommunicationBinding
import com.chat.poc.submodule.adapter.ChatAdapter
import com.chat.poc.submodule.model.Message
import com.chat.poc.submodule.model.NotificationData
import com.chat.poc.submodule.model.PushNotification
import com.google.firebase.database.*

class CommunicationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCommunicationBinding
    private lateinit var sender: String
    private lateinit var receiver: String
    private val messageList = mutableListOf<Message>()
    private lateinit var adapter: ChatAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCommunicationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sender = intent.getStringExtra("sender") ?: ""
        receiver = intent.getStringExtra("receiver") ?: ""

        val sharedPref = getSharedPreferences("MyAppPref", MODE_PRIVATE)
        val firstName = sharedPref.getString("first_name", "User") ?: "User"
        binding.title.text = firstName
        adapter = ChatAdapter(messageList, sender)
        binding.rvMessages.layoutManager = LinearLayoutManager(this)
        binding.rvMessages.adapter = adapter
        binding.backBtn.setOnClickListener { finish() }

        binding.etMessage.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val isTyping = !s.isNullOrEmpty()
                binding.sendIcon.visibility = if (isTyping) View.VISIBLE else View.GONE
                binding.attachIcon.visibility = if (isTyping) View.GONE else View.VISIBLE
                binding.micIcon.visibility = if (isTyping) View.GONE else View.VISIBLE
                binding.camer.visibility = if (isTyping) View.GONE else View.VISIBLE
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        val chatRef = FirebaseDatabase.getInstance().reference.child("chats").child(receiver + sender)

        // Fetch messages in real time
        chatRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                messageList.clear()
                snapshot.children.forEach {
                    val message = it.getValue(Message::class.java)
                    message?.let { msg -> messageList.add(msg) }
                }
                adapter.notifyDataSetChanged()
                binding.rvMessages.scrollToPosition(messageList.size - 1)
            }

            override fun onCancelled(error: DatabaseError) {}
        })

        // Send message
        binding.sendIcon.setOnClickListener {
            val text = binding.etMessage.text.toString()
            if (text.isNotEmpty()) {
                val msg = Message(sender, text)
                chatRef.push().setValue(msg)

                // Send push notification
                FirebaseDatabase.getInstance().reference.child("users").child(receiver)
                    .get().addOnSuccessListener {
                        val token = it.child("token").value.toString()
                        val pushNotification = PushNotification(
                            NotificationData("Message from $sender", text),
                            token
                        )
                        // RetrofitClient.instance.postNotification(pushNotification)
                    }

                binding.etMessage.setText("")
            }
        }
        // adapter = ChatAdapter(messageList, sender)
        //   binding.rvMessages.layoutManager = LinearLayoutManager(this)
        //     binding.rvMessages.adapter = adapter
    }
}
