package com.chat.poc.submodule.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.chat.poc.databinding.ItemReceivedMessageNewBinding
import com.chat.poc.databinding.ItemSentMessageNewBinding
import com.chat.poc.submodule.model.Message

class ChatAdapter(
    private val messages: List<Message>,
    private val currentUserId: String
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_SENT = 1
        private const val VIEW_TYPE_RECEIVED = 2
    }

    override fun getItemViewType(position: Int): Int {
        return if (messages[position].senderId == currentUserId) {
            VIEW_TYPE_SENT
        } else {
            VIEW_TYPE_RECEIVED
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_SENT) {
            val binding = ItemSentMessageNewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            SentMessageViewHolder(binding)
        } else {
            val binding = ItemReceivedMessageNewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            ReceivedMessageViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = messages[position]
        val msgText = message.message ?: ""

        when (holder) {
            is SentMessageViewHolder -> {
                holder.binding.txtMessage.text = msgText
                Log.d("ChatAdapter", "Binding message: ${message.message}")

            }
            is ReceivedMessageViewHolder -> {
                holder.binding.txtMessage.text = msgText
            }
        }
    }

    override fun getItemCount(): Int = messages.size

    inner class SentMessageViewHolder(val binding: ItemSentMessageNewBinding) : RecyclerView.ViewHolder(binding.root)
    inner class ReceivedMessageViewHolder(val binding: ItemReceivedMessageNewBinding) : RecyclerView.ViewHolder(binding.root)
}
