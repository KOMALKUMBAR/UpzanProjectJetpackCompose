package com.chat.poc.submodule.model

data class LoginUser( val username:String ="", val userpassword :String="")
